import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Sequence,Freeze,Img,staticFile,useCurrentFrame,useVideoConfig,delayRender,continueRender} from 'remotion';
import {Audio,Video} from '@remotion/media';
import {BUSINESS_NAME} from '../case';
import {C,ease,smooth,lerp,MaskedWords,CountUp,DepthPlane,DrawArrow,Brush,Reveal,Kicker,Title,Paper,Grid,Photo} from './library';
import timing from './timeline.json';

const Clip=({start=0,still=null,style={}})=>{const {fps}=useVideoConfig();const media=<Video src={staticFile('assets/DANYS.mp4')} trimBefore={start} muted volume={0} premountFor={fps} objectFit="cover" style={{width:'100%',height:'100%',...style}}/>;return still===null?<><Sequence durationInFrames={150-start} premountFor={fps}>{media}</Sequence><Sequence from={150-start} premountFor={fps}><Freeze frame={149-start}>{media}</Freeze></Sequence></>:<Freeze frame={still}>{media}</Freeze>;};
const Edge=({children,style={}})=><div style={{position:'relative',overflow:'hidden',borderRadius:28,border:'2px solid #FFFFFF75',boxShadow:'0 30px 75px #11132B26',height:'100%',...style}}>{children}</div>;
const Footer=({light=false})=><div style={{position:'absolute',left:76,right:76,bottom:136,display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:21,color:light?'#BBC8EE':C.muted}}><span style={{fontWeight:800,letterSpacing:-1,fontSize:30}}>Evoquex</span><span>CASE LOCAL / CLEVELÂNDIA</span></div>;

export const V7Hook=()=>{const f=useCurrentFrame();const arrive=ease(f,-10,27);const push=smooth(f,105,20);return <Paper color={C.ink}>
 <Grid color={C.cyan}/><div style={{position:'absolute',width:1000,height:1000,borderRadius:'50%',left:510+f*.4,top:690,border:'1px solid #8BF0E92B',scale:1+f*.0015}}/>
 <Kicker light>UM VÍDEO. UMA ESTRATÉGIA LOCAL.</Kicker>
 <div style={{position:'absolute',left:76,top:276,translate:`0 ${-push*130}px`,opacity:1-push}}>
  <div style={{fontSize:81,fontWeight:600,color:C.white,letterSpacing:-4}}>Um vídeo para</div>
  <div style={{position:'relative',marginTop:3}}><Brush x={-32} y={149} w={940} h={42} at={-4}/><div style={{position:'relative',paddingLeft:4}}><MaskedWords words={['sua empresa.','seu serviço.']} cues={[0,48]} size={129} color={C.cyan}/></div></div>
 </div>
 <div style={{position:'absolute',inset:0,translate:`0 ${-push*195}px`,scale:1+push*.08}}>
  <DepthPlane x={-100+(1-arrive)*-230} y={685} w={455} h={700} angle={-15} at={-12} style={{rotate:'-9deg',filter:'blur(1.4px)'}}><Edge><Clip still={104}/></Edge></DepthPlane>
  <DepthPlane x={275} y={650} w={560} h={790} angle={-3} at={-14} style={{rotate:`${lerp(8,-3,arrive)}deg`}}><Edge style={{border:'5px solid #F7F6F1'}}><Clip start={0}/></Edge></DepthPlane>
  <DepthPlane x={865-(1-arrive)*-190} y={740} w={420} h={610} angle={20} at={-7} style={{rotate:'9deg',filter:'blur(2px)'}}><Edge><Clip still={97}/></Edge></DepthPlane>
  <div style={{position:'absolute',left:106,top:1325,rotate:'-6deg',background:C.blue,color:C.white,border:'2px solid #FFFFFF50',padding:'18px 30px',borderRadius:14,fontSize:27,fontWeight:700,opacity:ease(f,16,12)}}>IMAGENS REAIS DA CAMPANHA</div>
 </div>
 <Title y={1510} size={83} color={C.white} at={6} style={{translate:`0 ${-push*110}px`}}>Como chegar a<br/><span style={{color:C.cyan}}>mais pessoas?</span></Title>
 <div style={{position:'absolute',right:68,top:1480,rotate:'95deg',opacity:1-push}}><DrawArrow w={195} h={110} at={21} color={C.cyan}/></div>
 </Paper>;};

export const V7Action=()=>{const f=useCurrentFrame();const camera=ease(f,38,25);return <Paper>
 <Grid/>
 <Kicker>01 / O QUE FIZEMOS</Kicker>
 <Title y={260} size={86} at={5}>Foi assim com a</Title>
 <Title y={364} size={99} color={C.blue} at={9}>{BUSINESS_NAME}</Title>
 <div style={{position:'absolute',left:76,top:514,width:928,height:2,background:'#11132B22'}}/>
 <div style={{position:'absolute',left:76,top:555,fontSize:37,fontWeight:600,color:C.muted,opacity:ease(f,15,12)}}>Produção do vídeo + divulgação.</div>
 <DepthPlane x={76} y={695} w={lerp(925,585,camera)} h={lerp(900,930,camera)} at={5} angle={-3} style={{rotate:`${lerp(2,-3,camera)}deg`}}><Edge><Clip start={0}/></Edge></DepthPlane>
 <div style={{position:'absolute',left:710,top:780,width:310,translate:`${(1-camera)*370}px 0`,opacity:camera}}>
  <div style={{fontSize:24,color:C.blue,letterSpacing:2,fontWeight:800}}>PRODUÇÃO</div><div style={{fontSize:47,lineHeight:1.16,fontWeight:800,letterSpacing:-2,marginTop:20}}>Vídeo criado<br/>pela Evoquex.</div>
  <div style={{width:260,height:2,background:'#11132B20',margin:'52px 0'}}/>
  <div style={{fontSize:24,color:C.blue,letterSpacing:2,fontWeight:800}}>DIVULGAÇÃO</div><div style={{fontSize:43,lineHeight:1.15,fontWeight:800,letterSpacing:-2,marginTop:20}}>Anúncios no</div>
  <div style={{marginTop:25,padding:'15px 20px',borderRadius:15,background:C.blue,color:C.white,fontSize:35,fontWeight:700,rotate:'-3deg'}}>Instagram</div>
  <div style={{marginTop:16,padding:'15px 20px',borderRadius:15,background:C.ink,color:C.white,fontSize:35,fontWeight:700,rotate:'2deg'}}>Facebook</div>
 </div>
 <Brush x={90} y={1580} w={540} h={90} at={70} color={C.cyan}/>
 <div style={{position:'absolute',left:150,top:1603,fontSize:27,fontWeight:800,rotate:'-3deg',opacity:ease(f,72,10)}}>DO CONTEÚDO AO ANÚNCIO.</div>
 <Footer/>
 </Paper>;};

export const V7Local=()=>{const f=useCurrentFrame();const orbit=ease(f,10,85);return <Paper color={C.blue}>
 <Grid color={C.white}/><Kicker light>02 / QUEM QUERÍAMOS ALCANÇAR</Kicker>
 <Title y={270} size={112} color={C.white} at={5}>Anúncios só em</Title>
 <Title y={406} size={132} color={C.cyan} at={10}>Clevelândia.</Title>
 <DepthPlane x={54} y={705} w={972} h={745} at={6} angle={lerp(-8,5,orbit)} style={{rotate:`${lerp(-5,2,orbit)}deg`}}><Edge><Photo style={{scale:1.08+orbit*.09,translate:`${-orbit*14}px ${orbit*6}px`}}/><AbsoluteFill style={{background:'linear-gradient(0deg,#11132B8C,transparent 70%)'}}/><svg viewBox="0 0 972 745" style={{position:'absolute',inset:0,width:'100%',height:'100%'}}><ellipse cx={530} cy={450} rx={70+orbit*68} ry={35+orbit*34} stroke={C.cyan} strokeWidth={3} fill="none" strokeDasharray="10 8" strokeDashoffset={-f*1.6}/><ellipse cx={530} cy={450} rx={185+orbit*40} ry={90+orbit*20} stroke={C.white} strokeWidth={2} opacity={.5} fill="none"/><circle cx={530} cy={450} r={14} fill={C.cyan} stroke={C.white} strokeWidth={5}/><path d="M530 425V280H710" fill="none" stroke={C.white} strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={1-ease(f,25,20)}/></svg><div style={{position:'absolute',left:635,top:208,padding:'16px 22px',borderRadius:50,fontSize:26,fontWeight:800,background:C.white,color:C.blue,opacity:ease(f,40,10)}}>CLEVELÂNDIA / PR</div></Edge></DepthPlane>
 <div style={{position:'absolute',left:80,top:1520,width:920,display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:32,color:C.white,fontWeight:700,opacity:ease(f,42,15)}}><span>Vídeo</span><span style={{color:C.cyan}}>→</span><span>Anúncios</span><span style={{color:C.cyan}}>→</span><span>Público local</span></div>
 <div style={{position:'absolute',left:80,top:1603,fontSize:30,color:'#D2DCFF',opacity:ease(f,60,12)}}>Divulgação direcionada para a cidade.</div>
 <Footer light/>
 </Paper>;};

export const V7Proof=()=>{const f=useCurrentFrame();const document=ease(f,14,28);return <Paper>
 <Grid/>
 <Kicker>03 / RESULTADOS DOCUMENTADOS</Kicker>
 <Title y={260} size={104} at={4}>O que a campanha<br/><span style={{color:C.blue}}>mostrou.</span></Title>
 <DepthPlane x={lerp(250,688,document)} y={lerp(640,540,document)} w={lerp(590,430,document)} h={lerp(1052,767,document)} angle={12} at={-4} style={{rotate:`${lerp(-4,12,document)}deg`,opacity:1-document*.60}}><Edge><Photo src="assets/resultados.jpg"/></Edge></DepthPlane>
 <div style={{position:'absolute',left:76,top:710,width:928,height:390,borderRadius:29,background:C.ink,padding:'30px 42px',boxShadow:'0 25px 55px #11132B20',translate:`${(1-ease(f,18,18))*-1080}px 0`}}><CountUp value={timing.metrics.reach} at={27} duration={30}/><div style={{fontSize:43,fontWeight:700,color:C.cyan,letterSpacing:-1.4,marginTop:8}}>pessoas alcançadas</div><div style={{fontSize:26,color:'#BEC9E1',marginTop:13}}>Quantas pessoas receberam o anúncio.</div></div>
 <div style={{position:'absolute',left:76,top:1132,width:928,height:390,borderRadius:29,background:C.cyan,padding:'30px 42px',boxShadow:'0 25px 55px #11132B20',translate:`${(1-ease(f,66,18))*1080}px 0`}}><CountUp value={timing.metrics.impressions} at={75} duration={30} color={C.ink}/><div style={{fontSize:43,fontWeight:800,color:C.blue,letterSpacing:-1.4,marginTop:8}}>impressões</div><div style={{fontSize:26,color:C.ink,marginTop:13}}>Quantas vezes o anúncio apareceu.</div></div>
 <div style={{position:'absolute',left:82,top:1550,width:900,fontSize:30,color:C.muted,lineHeight:1.45,opacity:ease(f,110,12)}}>Registro original da campanha.<br/>Alcance e impressões são medidas diferentes.</div>
 <Footer/>
 </Paper>;};

export const V7Strategy=()=>{const f=useCurrentFrame();const shift=ease(f,59,21);return <Paper color={C.ink}>
 <Grid color={C.cyan}/><Kicker light>04 / E PARA A SUA EMPRESA OU SERVIÇO?</Kicker>
 <Title y={280} size={106} color={C.white} at={4}>Começa com<br/><span style={{color:C.cyan}}>duas perguntas.</span></Title>
 <DepthPlane x={76} y={690-30*shift} w={928} h={355} angle={lerp(-9,-1,shift)} at={12} style={{rotate:`${lerp(-4,1,shift)}deg`}}><div style={{height:'100%',borderRadius:30,background:C.paper,padding:'36px 42px',boxShadow:'0 30px 80px #0005'}}><div style={{fontSize:26,fontWeight:800,color:C.blue,letterSpacing:2}}>01 / A MENSAGEM</div><div style={{fontSize:79,fontWeight:800,lineHeight:1.05,letterSpacing:-4,marginTop:25}}>O que você<br/>quer divulgar?</div></div></DepthPlane>
 <DepthPlane x={76} y={1135} w={928} h={355} angle={-2} at={64} style={{rotate:'-2deg'}}><div style={{height:'100%',borderRadius:30,background:C.cyan,padding:'36px 42px',boxShadow:'0 30px 80px #0005'}}><div style={{fontSize:26,fontWeight:800,color:C.blue,letterSpacing:2}}>02 / O PÚBLICO</div><div style={{fontSize:79,fontWeight:800,lineHeight:1.05,letterSpacing:-4,marginTop:25}}>Quem você<br/>quer alcançar?</div></div></DepthPlane>
 <DrawArrow x={840} y={1000} w={140} h={130} rotate={85} at={47} color={C.cyan}/>
 <div style={{position:'absolute',left:80,top:1580,color:C.white,fontSize:37,letterSpacing:-1,opacity:ease(f,105,12)}}>É por aí que começamos.</div><Footer light/>
 </Paper>;};

export const V7Contact=()=>{const f=useCurrentFrame();return <Paper color={C.blue}>
 <Grid color={C.white}/><Kicker light>UMA IDEIA PARA O SEU NEGÓCIO.</Kicker>
 <Title y={280} size={117} color={C.white} at={3}>Quer fazer<br/>algo assim?</Title>
 <DepthPlane x={300} y={700} w={380} h={555} angle={-13} at={2} style={{rotate:'-13deg',opacity:.65,filter:'blur(2px)'}}><Edge><Clip still={105}/></Edge></DepthPlane>
 <DepthPlane x={710} y={860} w={390} h={380} angle={16} at={10} style={{rotate:'12deg',opacity:.6,filter:'blur(1.8px)'}}><Edge><Photo/></Edge></DepthPlane>
 <div style={{position:'absolute',left:76,top:822,width:928,height:425,borderRadius:45,background:C.cyan,padding:'48px 50px',boxShadow:'0 28px 80px #11132B40',translate:`0 ${(1-ease(f,25,18))*300}px`,scale:lerp(.92,1,ease(f,25,18)),opacity:ease(f,25,12)}}><div style={{fontSize:100,fontWeight:800,lineHeight:1.09,letterSpacing:-5}}>Conversa<br/>com a gente.</div><svg width={105} height={76} style={{position:'absolute',left:60,top:420}}><path d="M0 0H100L15 75Z" fill={C.cyan}/></svg></div>
 <Brush x={67} y={1529} w={585} h={40} at={52} color={C.cyan} rotate={-2}/>
 <div style={{position:'absolute',left:96,top:1426,fontSize:81,fontWeight:800,letterSpacing:-5,color:C.white,opacity:ease(f,54,12)}}>Evoquex</div>
 <div style={{position:'absolute',left:80,top:1600,fontSize:27,color:'#D8E1FF',opacity:ease(f,64,12)}}>Produção de vídeo + divulgação com anúncios.</div>
 <Footer light/>
 </Paper>;};

export const EvoquexLibrary=()=>{const {fps}=useVideoConfig();const [fontHandle]=useState(()=>delayRender('Loading local Manrope'));useEffect(()=>{document.fonts.ready.then(()=>continueRender(fontHandle));},[fontHandle]);return <AbsoluteFill style={{background:C.ink}}>
 {["brush.png",...Array.from({length:18},(_,i)=>`ink-masks/${String(i).padStart(2,'0')}.png`)].map(file=><Img key={file} src={staticFile(`library-v7/${file}`)} style={{position:'absolute',width:1,height:1,opacity:0,pointerEvents:'none'}}/>)}
 <Sequence name="01 — Sua empresa / seu serviço" from={0} durationInFrames={149} premountFor={fps}><V7Hook/></Sequence>
 <Sequence name="02 — Produção e anúncios / Danny’s Presentes" from={135} durationInFrames={194} premountFor={fps}><Reveal kind="slit" length={12}><V7Action/></Reveal></Sequence>
 <Sequence name="03 — Anúncios somente para Clevelândia" from={315} durationInFrames={164} premountFor={fps}><Reveal kind="ink" length={14}><V7Local/></Reveal></Sequence>
 <Sequence name="04 — Print real / alcance e impressões" from={465} durationInFrames={222} premountFor={fps}><Reveal kind="side" length={10}><V7Proof/></Reveal></Sequence>
 <Sequence name="05 — Mensagem e público" from={675} durationInFrames={194} premountFor={fps}><Reveal kind="slit" length={12}><V7Strategy/></Reveal></Sequence>
 <Sequence name="06 — Convite natural" from={855} durationInFrames={180} premountFor={fps}><Reveal kind="ink" length={14}><V7Contact/></Reveal></Sequence>
 <Audio name="Trilha e efeitos V7 — sem locução provisória artificial" src={staticFile(timing.sound_file)} premountFor={fps}/>
 </AbsoluteFill>;};
