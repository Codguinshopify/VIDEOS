/* HyperFrames registry adaptations, source pinned in resources/hyperframes.
 * Apache-2.0; modified for React, pt-BR and frame-indexed Remotion rendering.
 * No GSAP autoplay, CSS animations, wall clock or external CDN at render time.
 */
import React from 'react';
import {AbsoluteFill,Easing,Img,interpolate,staticFile,useCurrentFrame} from 'remotion';

export const C={ink:'#11132B',blue:'#2449FF',paper:'#F7F6F1',cyan:'#8BF0E9',white:'#FFFFFF',muted:'#667086'};
export const clamp=(x)=>Math.min(1,Math.max(0,x));
export const ease=(f,at=0,d=15)=>interpolate(f,[at,at+d],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(.16,1,.3,1)});
export const smooth=(f,at=0,d=12)=>interpolate(f,[at,at+d],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(.76,0,.24,1)});
export const lerp=(a,b,p)=>a+(b-a)*p;

// kinetic-type-swap: every alternative occupies the same grid cell; fixed width
// prevents reflow. GSAP seek rows are replaced by pure frame-derived transforms.
export const MaskedWords=({words,cues,size=124,color=C.cyan})=>{const f=useCurrentFrame();return <div data-library="kinetic-type-swap" style={{display:'inline-grid',overflow:'hidden',fontSize:size,fontWeight:800,lineHeight:1.25,letterSpacing:-size*.057,color}}>{words.map((word,i)=>{const into=i===0?1:ease(f,cues[i],11);const out=i===words.length-1?0:smooth(f,cues[i+1],11);return <span key={word} style={{gridArea:'1 / 1',width:'max-content',translate:`0 ${lerp(110,0,into)-out*115}%`,opacity:into*(1-out),filter:`blur(${(1-into+out)*4}px)`}}>{word}</span>;})}</div>};

// count-up: sine.inOut integer interpolation, tabular glyphs and landing pulse.
export const CountUp=({value,at=0,duration=30,size=205,color=C.white})=>{const f=useCurrentFrame();const p=clamp((f-at)/duration);const t=(1-Math.cos(Math.PI*p))/2;const pulse=Math.sin(clamp((f-at-duration)/10)*Math.PI)*.035;return <div data-library="count-up" style={{fontSize:size,fontWeight:800,lineHeight:1.08,letterSpacing:-size*.065,color,fontVariantNumeric:'tabular-nums',scale:1+pulse,transformOrigin:'0 60%',whiteSpace:'nowrap'}}>{Math.round(value*t).toLocaleString('pt-BR')}</div>};

// camera-rig-depth-stack: retain the perspective/rotateX/rotateY/translateZ
// contract; frame-driven focus and authored camera poses replace CSS variables.
export const DepthPlane=({children,at=0,x=0,y=0,w=600,h=800,angle=-8,z=0,style={}})=>{const f=useCurrentFrame();const p=ease(f,at,24);return <div data-library="camera-rig-depth-stack" style={{position:'absolute',left:x,top:y,width:w,height:h,transform:`perspective(1600px) rotateY(${lerp(-20,angle,p)}deg) rotateX(${lerp(12,-2,p)}deg) translateZ(${lerp(-80,z,p)}px)`,translate:`0 ${(1-p)*115}px`,opacity:p,filter:`blur(${(1-p)*7}px)`,transformStyle:'preserve-3d',...style}}>{children}</div>};

// hw-arrow: adapted deterministic path construction and draw-on, without the
// optional handwriting font or runtime DOM mutation from the upstream snippet.
const hash=(n,seed=3)=>{const x=Math.sin(n*127.1+seed*311.7)*43758.5453;return (x-Math.floor(x))*2-1;};
export const DrawArrow=({x=0,y=0,w=360,h=180,at=0,color=C.blue,rotate=0})=>{const f=useCurrentFrame();const x0=4+hash(1)*3,y0=h*.72+hash(2)*4,x1=w-10+hash(3)*4,y1=h*.3+hash(4)*4,cx1=w*.35+hash(5)*10,cy1=h*.995+hash(6)*8,cx2=w*.7+hash(7)*10,cy2=h*.85+hash(8)*8;const a=Math.atan2(y1-cy2,x1-cx2);return <svg data-library="hw-arrow" viewBox={`0 0 ${w} ${h}`} style={{position:'absolute',left:x,top:y,width:w,height:h,overflow:'visible',rotate:`${rotate}deg`}}><path d={`M${x0} ${y0}C${cx1} ${cy1} ${cx2} ${cy2} ${x1} ${y1}`} stroke={color} strokeWidth={5} fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1-ease(f,at,20)}/><path d={`M${x1+Math.cos(a+Math.PI-.5)*28} ${y1+Math.sin(a+Math.PI-.5)*28}L${x1} ${y1}L${x1+Math.cos(a+Math.PI+.5)*28} ${y1+Math.sin(a+Math.PI+.5)*28}`} stroke={color} strokeWidth={5} strokeLinecap="round" fill="none" opacity={ease(f,at+16,5)}/></svg>};

export const Brush=({x=0,y=0,w=1000,h=280,color=C.cyan,at=0,rotate=-3})=>{const f=useCurrentFrame();return <div data-pack="Brush 2.png" style={{position:'absolute',left:x,top:y,width:w,height:h,background:color,maskImage:`url("${staticFile('library-v7/brush.png')}")`,maskSize:'100% 100%',maskRepeat:'no-repeat',clipPath:`inset(0 ${(1-ease(f,at,14))*100}% 0 0)`,rotate:`${rotate}deg`}}/>};

export const Reveal=({children,kind='ink',length=14})=>{const f=useCurrentFrame();let style={};if(kind==='ink'&&f<length)style={maskImage:`url("${staticFile(`library-v7/ink-masks/${String(Math.min(17,Math.floor(f/(length-1)*17))).padStart(2,'0')}.png`)}")`,maskSize:'100% 100%',maskRepeat:'no-repeat'};else if(kind==='slit')style={clipPath:`inset(${(1-smooth(f,0,length))*50}% 0)`};else if(kind==='side')style={clipPath:`inset(0 ${(1-smooth(f,0,length))*100}% 0 0)`};return <AbsoluteFill style={style}>{children}</AbsoluteFill>};

export const Kicker=({children,light=false,y=155})=><div style={{position:'absolute',left:76,top:y,fontSize:23,fontWeight:700,letterSpacing:3.2,color:light?'#B9C5E9':C.muted}}>{children}</div>;
export const Title=({children,x=76,y=280,size=108,color=C.ink,at=0,style={}})=>{const f=useCurrentFrame();const p=ease(f,at,16);return <div style={{position:'absolute',left:x,top:y,fontSize:size,fontWeight:800,lineHeight:1.04,letterSpacing:-size*.06,color,translate:`0 ${(1-p)*85}px`,opacity:p,filter:`blur(${(1-p)*5}px)`,...style}}>{children}</div>};
export const Paper=({children,color=C.paper})=><AbsoluteFill style={{background:color,fontFamily:'Manrope, sans-serif',color:C.ink,overflow:'hidden'}}>{children}</AbsoluteFill>;
export const Grid=({color=C.blue})=>{const f=useCurrentFrame();return <AbsoluteFill style={{opacity:.07,backgroundImage:`linear-gradient(${color} 1px,transparent 1px),linear-gradient(90deg,${color} 1px,transparent 1px)`,backgroundSize:'120px 120px',backgroundPosition:`${f*.12}px ${f*.08}px`}}/>};
export const Photo=({src='assets/clevelandia.jpg',style={}})=><Img src={staticFile(src)} style={{width:'100%',height:'100%',objectFit:'cover',...style}}/>;
