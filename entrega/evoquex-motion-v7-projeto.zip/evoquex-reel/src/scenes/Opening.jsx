import React from 'react';
import {BUSINESS_NAME} from '../case';
import {AbsoluteFill, Interactive, interpolate, useCurrentFrame} from 'remotion';
import {AccentLine, CampaignFilm, C, clamp, Headline, Label, Rise, Stage} from '../design';

const Opening = () => {
  const f = useCurrentFrame();
  return <Stage enter={false}>
    <CampaignFilm volume={interpolate(f, [105, 120], [.9, 0], clamp)} style={{scale: interpolate(f, [0, 132], [1, 1.025], clamp)}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg,rgba(2,11,23,.8) 0%,rgba(2,11,23,.58) 26%,rgba(2,11,23,.06) 44%,transparent 76%,rgba(2,11,23,.46) 100%)'}} />
    <div style={{position: 'absolute', left: 90, top: 200}}><Label style={{color: C.white, fontSize: 27}}>{BUSINESS_NAME} · CLEVELÂNDIA</Label></div>
    <div style={{position: 'absolute', top: 355, left: 88, width: 904}}>
      <AccentLine delay={8} style={{marginBottom: 38}} />
      <Headline>
        <Rise delay={4}>Você chegou</Rise>
        <Rise delay={9}>a ver esse vídeo</Rise>
        <Rise delay={14} style={{color: C.cyan}}>em Clevelândia?</Rise>
      </Headline>
    </div>
  </Stage>;
};

export const OpeningScene = Interactive.withSchema({Component: Opening, componentName: '<OpeningScene>', schema: {}, wrapInSequence: true});
