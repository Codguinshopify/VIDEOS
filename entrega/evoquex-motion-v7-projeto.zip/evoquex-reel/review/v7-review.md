# V7 — revisão da edição com HyperFrames e parte 1

Estado: prévia visual e sonora; locução natural pendente. Esta entrega não usa a
voz rejeitada nem afirma uma substituição vocal inexistente.

O roteiro mais objetivo foi aplicado à composição: empresa/serviço, produção do
vídeo pela Evoquex, anúncios no Instagram e Facebook, direcionamento somente a
Clevelândia, resultados documentados e convite. A cidade e a autoria do vídeo
foram confirmadas pelo usuário. Não há alegação sobre não seguidores, vendas,
receita, retorno financeiro ou visualizações.

Biblioteca adaptada: kinetic-type-swap, count-up, camera-rig-depth-stack e
hw-arrow, com fontes originais, licença e commit preservados. Tempo e estado são
funções do frame no Remotion. Não foi instalado o motor HyperFrames ou qualquer
dependência JS adicional. Há preload explícito das máscaras CSS para futuras
renderizações e cenas isoladas registradas no Studio.

Parte 1: Brush 2.png e Ink_1.mp4 reais, recuperados integralmente. O primeiro é
usado nos sublinhados texturizados; o segundo gera os recortes orgânicos entre
produção/cidade e estratégia/CTA. Nenhum AEP foi executado. A análise do pack
continua parcial; não foi necessário baixar as outras partes para esta prévia.

Correções após inspeção da primeira versão: texto do hook passou a ter contraste
independente da textura; pincelada como sublinhado em vez de cobrir letras;
molduras passaram a conter os planos de vídeo; altura dos cartões numéricos
ampliada para evitar cortar as explicações; palavra Evoquex preservada inteira
no CTA. Retirada passagem azul sem conteúdo antes da primeira cena. Três
ocorrências antigas de Dany’s nos componentes V1/V2 também foram corrigidas para
a constante canônica Danny’s Presentes. Exports anteriores preservados.

A prévia 540 × 960 foi inspecionada em 69 amostras de duração, 31 quadros da
abertura, 35 amostras de passagens, 31 estados internos e seis telas pequenas.
A versão Full HD recebeu a mesma extração de revisão e conferência dos pontos
corrigidos. As folhas e a comparação V6/V7 estão nesta pasta.

Áudio: novo arranjo autoral de 120 BPM, com 22 eventos sonoros gerados e
sincronizados às entradas/mudanças/assentamentos. Original do anúncio silenciado.
Não há sobreposição de vozes. A interface não permite escuta subjetiva; não é
alegada aprovação humana de timbre, mixagem ou narração.

Verificação do MP4: decodificação integral de imagem/áudio passou. Os três
originais mantêm SHA-256. Arquivo de 34.517000 s, 1080 × 1920, 1035 frames,
30 fps, H.264/yuv420p/BT.709 e AAC estéreo a 48 kHz.
LUFS integrado: -16.57; pico verdadeiro: -1.65 dBTP;
zero amostras com clipping. Correlação com o WAV master: 0.999852.
SHA-256 do MP4: 4c34da06f723e081ccdd3a7d3f3f15d4a3014a666c1d5847e0833b71a17b6b59.

Limites materiais: filmagem disponível de 5,06 s e fotografia aérea de 600 × 337;
movimentos originais incluem trechos desfocados. Os planos reutilizam esse
conteúdo real, sem inventar imagens ou dados. A voz natural, avaliação auditiva e
aprovação criativa pelo usuário permanecem pendentes.

Pacote extraído em diretório independente e seis quadros da composição renderizados
com as dependências fixadas já instaladas, sem baixar o pack original. Fontes,
master, pincelada e timeline conferem por SHA-256 com o projeto editado.
