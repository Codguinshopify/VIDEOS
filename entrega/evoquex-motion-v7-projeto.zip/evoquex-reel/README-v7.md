# Evoquex — V7 / biblioteca HyperFrames + pack real

Prévia visual e sonora, 34,5 segundos, 1080 × 1920, 30 fps.
Composição principal: **EvoquexLibrary**. Seis cenas editáveis em Motion-V7.
A V6 e todas as composições anteriores permanecem disponíveis, sem sobrescrever
os exports anteriores. Não foram instaladas dependências JavaScript novas.

## O que mudou

- Narrativa: pergunta sobre empresa/serviço → produção do vídeo pela Evoquex →
  anúncios no Instagram/Facebook → direcionamento somente para Clevelândia →
  provas da campanha → duas perguntas para planejar a divulgação → convite.
- Hook com três planos de imagens reais, perspectiva, foco, troca mascarada
  entre “sua empresa” e “seu serviço” e pincelada do pack desde o início.
- Vídeo original transforma-se de plano amplo em composição dividida com as
  ações de produção e divulgação; cidade entra por uma revelação de tinta.
- Registro original em profundidade, contadores que assentam nos valores
  comprovados e cartões com definições de alcance/impressões.
- Perguntas em planos com perspectiva, seta desenhada e CTA integrado a um
  balão com imagens atrás e tipografia à frente.
- Música autoral rearranjada em 120 BPM e 22 eventos sonoros reais sincronizados.
  WAV master e stems de música/efeitos em public/audio-v7.

## Recursos efetivamente usados

`src/motion-v7/library.jsx` adapta quatro componentes do catálogo HyperFrames:
kinetic-type-swap, count-up, camera-rig-depth-stack e hw-arrow. Os originais,
commit fixo, SHA-256, licença Apache-2.0 e nota das modificações estão em
resources/hyperframes. A animação foi convertida para funções do frame do
Remotion; não se depende de GSAP em autoplay ou CDNs durante a renderização.

Da primeira parte do RAR, foram usados **Brush 2.png e Ink_1.mp4**, recuperados
integralmente. A pincelada vira textura de sublinhado. O vídeo de tinta modula
18 máscaras PNG com transparência, usadas nas passagens de cidade e CTA.
Fontes e hashes em public/library-v7/SOURCES.json. Este é um inventário parcial;
os projetos AEP não foram executados nem convertidos. A licença do pack fornecido
pelo usuário não foi verificada independentemente para redistribuição comercial.

## Informações e voz

Grafia canônica: **Danny’s Presentes**, src/case.jsx. Dados reais: **13.064 pessoas
alcançadas e 20.981 impressões**. Sem vendas, retorno financeiro, visualizações,
curva temporal ou público não seguidor inventados. A localização da campanha e
a produção do vídeo pela Evoquex foram confirmadas pelo usuário.

O roteiro aprovado está em src/motion-v7/timeline.json. A narrativa é comunicada
visualmente nesta prévia. **Não há nova locução.** A voz rejeitada não é usada;
o original está silenciado. Não houve compra ou uso de serviço pago.
A preferência atual é voz feminina e avaliação de ElevenLabs gratuito; notas
históricas sobre plano comercial nos documentos antigos estão superadas.
A presente etapa não realizou uma nova validação da integração ElevenLabs.

Não é alegada audição subjetiva: a revisão combina inspeção de frames reais,
decodificação integral, níveis de áudio e correlação com o mix. A avaliação
auditiva pelo usuário e a locução natural continuam pendentes.

## Trabalhar no projeto

Mesmo lockfile: Remotion 4.0.535, React 19.3.1. Node 24, Chromium e FFmpeg no
ambiente em nuvem. Use o checkout existente; não é necessário criar worktrees.

```sh
npm ci --no-audit --no-fund
npm run studio
npm run draft
npm run render
npm run validate-v7
npm run review-v7
```

Render: out/evoquex-motion-v7-previa.mp4. O comando render-final bloqueia a
exportação como versão narrada enquanto a locução estiver pendente.
Os comandos usam /usr/bin/chromium; ajuste esse caminho em outras máquinas.

Os recursos e o áudio já estão no pacote; não é necessário baixá-los de novo.
`scripts/prepare-library-v7.py` pode reconstruir as máscaras usando os originais
retidos. Requer Python, Pillow, NumPy e FFmpeg. Para recompor o áudio:
`npm run audio-v7`, com libfluidsynth e o banco GeneralUser GS de SHA fixo no cache;
origem e licença instrumental em audio-sources/GeneralUser-GS-LICENSE.txt.

## Arquivos de revisão

review/v7-validation.json: metadados, hash, integridade dos originais, áudio.
review/v7-preview-*.jpg: duração, abertura, passagens e estados internos.
review/v7-preview-phone-*.png: legibilidade em tela pequena.
review/v7-comparison.jpg: seis momentos da V6 e da V7.
review/v7-review.md: correções e limites da revisão.
