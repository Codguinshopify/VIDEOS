# HyperFrames registry adaptations — V7

Source: HeyGen HyperFrames, commit 08ee1bd5ad59987a7f2525222683e24ca30971f9, Apache-2.0.
See LICENSE and source-manifest.json. Original snippets retained alongside this notice.

Modified code is src/motion-v7/library.jsx:
- kinetic-type-swap: shared grid cell and rolling masked words; React/frame timing,
  local Manrope and pt-BR text. Removed CDN/GSAP/runtime variable loader.
- count-up: sine.inOut integer count and landing pulse; frame function, pt-BR
  number formatting, faster arrival and exact values from timeline.json.
- camera-rig-depth-stack: perspective, rotateX/Y, translateZ; frame-derived camera
  and focus plus real campaign images. No backdrop-filter dependency.
- hw-arrow: deterministic seeded curve geometry, tangent-aligned arrowhead and
  path draw-on. No optional Caveat font, spray effect or DOM mutation.

The React scenes are original to this project; this is not an automatic importer
or a claim that every catalog item is compatible. No HyperFrames runtime installed.
