# Evoquex — V3 refinada / entrega V4

Reel de 26 segundos, 1080 × 1920, 30 fps. Este refinamento utiliza os mesmos componentes e preserva a direção visual e musical aprovada da V3. As composições V1 e V2 permanecem disponíveis para comparação.

## Execução visual

O anúncio original abre em tela cheia e se transforma em um recorte em perspectiva. A fotografia real de Clevelândia assume o plano principal, com marcação projetada sobre a praça. O print é enquadrado por indicador e conectado por linhas de chamada aos números em tipografia maior. Máscaras revelam apenas os caracteres finais das métricas, sem contadores que exibam valores inventados.

A sequência das impressões muda para azul; a conexão comercial usa uma rede vetorial conceitual de distribuição, tipografia em planos e um estabelecimento desenhado. Esse estabelecimento origina a forma do CTA. As transições revelam a próxima composição sobre a anterior, sem flashes de telas vazias. Todas as animações são calculadas por frame, com curvas de aceleração e acomodação por molas. Não há CSS keyframes ou animações dependentes do relógio.

A rede e os personagens são elementos conceituais autorais, não uma representação de usuários reais ou de dados geográficos. Não há interface falsa, mensagem fictícia de cliente ou logotipo inventado. Evoquex aparece em texto.

## Dados e materiais

- **13.064 pessoas alcançadas**: documento fornecido, coluna Alcance.
- **20.981 impressões**: documento fornecido, coluna Impressões.

Não foi fornecida comprovação de 20 mil visualizações. A versão refinada usa a nomenclatura documentada, sem converter impressões em visualizações.

Os arquivos DANYS.mp4, clevelandia.jpg e resultados.jpg conservam os bytes originais, conferidos por SHA-256. Os recortes e as marcações são feitos em Remotion. O anúncio disponível tem 5,06 segundos; ele aparece na abertura e volta em cortes posteriores. A fotografia da cidade tem 600 × 337 pixels, o que limita ampliações muito próximas.

## Música e efeitos

Composição nova em 108 BPM com piano elétrico, baixo e bateria, renderizados pelo FluidSynth com GeneralUser GS. A licença do banco permite criação musical privada e comercial e está preservada em audio-sources/. Não são usados demos MIDI, gravações de terceiros nem a trilha da V2.

O áudio original aparece na abertura, com música atenuada. Swishes, marcações de papel e acentos de revelação acompanham eventos específicos. O WAV final public/assets/evoquex-refinado.wav contém a mixagem completa e permite reproduzir o MP4 sem baixar instrumentos ou acessar serviços externos.

## Reproduzir a renderização

Ambiente utilizado: Node 24.19.0, Remotion 4.0.535, React 19.3.1, Chromium 154 e FFmpeg 7.1.5. Dependências JavaScript permanecem nas versões do lockfile; nenhuma biblioteca JavaScript nova foi instalada neste refinamento.

```sh
export npm_config_cache=/workspace/.cache/npm
export XDG_CONFIG_HOME=/workspace/.cache/xdg-config
export XDG_CACHE_HOME=/workspace/.cache/xdg-cache
npm ci --no-audit --no-fund
npm run studio
```

No ambiente preparado, npm ci --offline --no-audit --no-fund também usa o cache disponível. Os scripts apontam para /usr/bin/chromium; ajuste esse argumento em outras máquinas. Use o checkout existente; não é necessário criar worktrees.

```sh
npm run draft
npm run render
python scripts/validate-output.py out/evoquex-motion-v4.mp4
python scripts/review-video-v3.py out/evoquex-motion-v4.mp4
python scripts/create-delivery.py --v4
```

A composição principal é **EvoquexPremium**. O draft tem 540 × 960; o render final usa H.264, yuv420p, BT.709 com faixa de vídeo e AAC estéreo. As cenas também estão registradas separadamente no Studio, na pasta Motion-V3. Os comandos render-v1, render-v2 e draft-v2 preservam as versões anteriores.

A revisão por imagens requer Python e Pillow. A regeneração opcional da música requer Python, NumPy, FFmpeg e libfluidsynth: npm run audio-refinado. O script baixa o banco de instrumentos de um commit fixo e verifica SHA-256. Isso não é necessário para renderizar o vídeo, pois a mixagem pronta está incluída.

## Sequência

| Tempo | Construção |
| --- | --- |
| 0–3,8 s | Anúncio real e abertura por máscaras tipográficas; enquadramento vira recorte |
| 3,8–6,4 s | Fotografia real, perspectiva e trajetória ligada à praça |
| 6,4–10,2 s | Recorte do documento, extração gráfica de 13.064 e comprovação |
| 10,2–14 s | 20.981 impressões, composição azul e continuidade documental |
| 14–19,6 s | Oportunidade, tipografia com profundidade e distribuição vetorial |
| 19,6–26 s | Transformação em CTA, pergunta e chamada comercial legíveis |

## Arquivos e revisão

src/motion-v3/ contém os componentes reutilizáveis, as seis cenas e a composição principal. ordem-producao-v3.md guarda o pedido recebido; analise-producao-v3.md registra a auditoria e as técnicas definidas antes da edição. Os materiais, as fontes Manrope/Open Sans e suas licenças estão incluídos. O vídeo de referência não é dependência do projeto e não está no pacote.

review/ contém validação do MP4, medições de áudio, amostras de toda a duração, quadros de transições e telas em 360 × 640. O script de validação verifica 780 frames, resolução, frequência, codecs, cor e decodificação integral de imagem e som.

Limitação de revisão: a interface do agente não oferece reprodução sonora. A revisão visual usa sequências de frames e a sonora usa análise técnica integral de níveis, picos e decodificação. Não foi feita uma audição subjetiva, e a análise técnica não a substitui.

## Refinamento implementado

Hook com texto, máscara, contorno, movimento de câmera e acento sonoro desde o frame zero. Revelações entre cenas de 9–12 frames, preservando as diferentes geometrias e a sobreposição contínua. Entradas de texto/dígitos e transformação do CTA antecipadas; leitura dos indicadores e da chamada mantida. Nome correto Danny’s Presentes em todos os textos renderizados e labels do projeto. Nome canônico em src/case.jsx; nomes de arquivos de mídia são históricos e não aparecem como nome da empresa.

A trilha da V3 permanece como base; a mixagem refinada tem efeitos e fades sincronizados aos novos tempos. Para regenerar: npm run audio-refinado. O WAV pronto acompanha o projeto. revisao-refinamento-v4.md descreve a auditoria e as alterações pontuais.

A V3 original e seu código-fonte continuam disponíveis na entrega anterior. A composição EvoquexPremium neste pacote corresponde ao refinamento de 26 s. Para gerar a comparação de ritmo, mantenha o MP4 V3 em out/evoquex-motion-v3.mp4 e execute python scripts/compare-refinement.py. Esse arquivo anterior não é necessário para renderizar a versão nova.
