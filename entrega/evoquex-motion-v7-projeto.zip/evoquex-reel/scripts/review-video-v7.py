"""Inspect every section, all transitions and every opening frame of the MP4."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,sys
ROOT=Path(__file__).resolve().parent.parent
video=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v7-previa.mp4')
tag='v7-draft' if 'draft' in video.name else 'v7-preview'
folder=ROOT/'review'/tag;folder.mkdir(exist_ok=True)
def run(*args):subprocess.run(['ffmpeg','-v','error','-y',*map(str,args)],check=True)
def sheets(items,name,cols=6,per=24):
 for start in range(0,len(items),per):
  chunk=items[start:start+per];canvas=Image.new('RGB',(216*cols,412*((len(chunk)+cols-1)//cols)),'#E0E6EE');d=ImageDraw.Draw(canvas)
  for i,(p,label) in enumerate(chunk):
   x=i%cols*216;y=i//cols*412;canvas.paste(Image.open(p).convert('RGB'),(x,y));d.text((x+6,y+391),label,fill='#11132B')
  canvas.save(ROOT/'review'/f'{tag}-{name}-{start//per+1:02d}.jpg',quality=94)
run('-i',video,'-vf','fps=2,scale=216:384',folder/'full-%03d.png')
full=sorted(folder.glob('full-*.png'));sheets([(p,f'{(i+.5)/2:.2f}s') for i,p in enumerate(full)],'full')
run('-i',video,'-frames:v','31','-vf','scale=216:384',folder/'hook-%03d.png')
hook=sorted(folder.glob('hook-*.png'));sheets([(p,f'Opening frame {i}') for i,p in enumerate(hook)],'hook',per=24)
def extract(f,name):
 p=folder/f'{name}-{f:04d}.png';run('-ss',f/30,'-i',video,'-frames:v','1','-vf','scale=216:384',p);return p
cuts=[]
for at in [135,315,465,675,855]:
 for delta in [-1,0,3,6,9,12,15]:
  f=at+delta;cuts.append((extract(f,'cut'),f'Cut {at} +{delta}'))
sheets(cuts,'cuts',cols=7,per=28)
states=[]
for f in [0,8,48,53,60,110,160,180,220,310,340,360,450,485,510,525,550,570,600,660,690,715,745,770,820,865,885,900,925,975,1034]:
 states.append((extract(f,'state'),f'State {f}'))
sheets(states,'states')
for name,f in [('hook',65),('production',250),('city',400),('proof',610),('strategy',800),('cta',1000)]:
 run('-ss',f/30,'-i',video,'-frames:v','1','-vf','scale=360:640',ROOT/'review'/f'{tag}-phone-{name}.png')
if tag=='v7-preview':
 old=ROOT/'out/evoquex-motion-v6-previa.mp4';before=[45,205,140,550,735,870];after=[65,250,400,610,800,1000]
 im=Image.new('RGB',(6*270,2*504),'#E0E6EE');d=ImageDraw.Draw(im)
 for row,(src,frames) in enumerate([(old,before),(video,after)]):
  for i,f in enumerate(frames):
   p=folder/f'comparison-{row}-{i}.png';run('-ss',f/30,'-i',src,'-frames:v','1','-vf','scale=270:480',p);im.paste(Image.open(p).convert('RGB'),(i*270,row*504));d.text((i*270+6,row*504+484),'V6 anterior' if row==0 else 'V7 biblioteca + pack',fill='#11132B')
 im.save(ROOT/'review/v7-comparison.jpg',quality=95)
report={'video':video.name,'full_duration_samples':len(full),'opening_frames':len(hook),'transition_samples':len(cuts),'internal_states':len(states),'phone_checks':6,'subjective_audio_playback_available':False}
(ROOT/'review'/f'{tag}-sampling.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
