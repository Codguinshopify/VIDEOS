"""Prepare real user-pack resources and preserve pinned HyperFrames sources."""
from pathlib import Path
import subprocess,shutil,json,hashlib,io
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent.parent
PACK=Path('/workspace/pack-lfs-validacao/amostras')
REPO=Path('/workspace/referencias-tecnicas/hyperframes')
REV='08ee1bd5ad59987a7f2525222683e24ca30971f9'
out=ROOT/'public/library-v7';out.mkdir(parents=True,exist_ok=True)
sources=ROOT/'resources/hyperframes';sources.mkdir(parents=True,exist_ok=True)
items=['kinetic-type-swap','count-up','camera-rig-depth-stack','hw-arrow']
records=[]
for name in items:
    path=f'registry/components/{name}/{name}.html'
    data=subprocess.check_output(['git','show',f'{REV}:{path}'],cwd=REPO) if (REPO/'.git').exists() else (sources/f'{name}.html').read_bytes()
    (sources/f'{name}.html').write_bytes(data)
    records.append({'name':name,'source':f'https://github.com/heygen-com/hyperframes/blob/{REV}/{path}','sha256':hashlib.sha256(data).hexdigest()})
if (REPO/'.git').exists():
    (sources/'LICENSE').write_bytes(subprocess.check_output(['git','show',f'{REV}:LICENSE'],cwd=REPO))
(sources/'ADAPTATIONS.md').write_text('''# HyperFrames registry adaptations — V7

Source: HeyGen HyperFrames, commit '''+REV+''', Apache-2.0.
See LICENSE and source-manifest.json. Original snippets retained alongside this notice.

Modified code is src/motion-v7/library.jsx:
- kinetic-type-swap: shared grid cell and rolling masked words; React/frame timing,
  local Manrope and pt-BR text. Removed CDN/GSAP/runtime variable loader.
- count-up: sine.inOut integer count and landing pulse; frame function, pt-BR
  number formatting, faster arrival and exact values from timeline.json.
- camera-rig-depth-stack: perspective, rotateX/Y, translateZ; frame-derived camera
  and focus plus real campaign images. No backdrop-filter dependency.
- hw-arrow: deterministic seeded curve geometry, tangent-aligned arrowhead and
  path draw-on. No optional Caveat font, spray effect or DOM mutation.

The React scenes are original to this project; this is not an automatic importer
or a claim that every catalog item is compatible. No HyperFrames runtime installed.
''')
(sources/'source-manifest.json').write_text(json.dumps({'commit':REV,'license':'Apache-2.0','items':records},indent=2)+'\n')
for src,name in [('Brush 2.png','brush.png'),('Ink_1.mp4','ink-source.mp4')]:
    if (PACK/src).is_file():
        shutil.copyfile(PACK/src,out/name)
    assert (out/name).is_file(), f'Missing retained source: {name}'
maskdir=out/'ink-masks';maskdir.mkdir(exist_ok=True)
y,x=np.mgrid[0:960,0:540];x=x/539;y=y/959
for index in range(18):
    # Actual moving ink from the supplied pack modulates a diagonal reveal front.
    t=.25+index*.37
    data=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(out/'ink-source.mp4'),'-frames:v','1','-vf','scale=540:960','-f','image2pipe','-vcodec','png','-threads','1','pipe:1'])
    ink=np.asarray(Image.open(io.BytesIO(data)).convert('L'),dtype=np.float32)/255
    p=index/17;p=p*p*(3-2*p)
    field=.53*x+.21*y+.26*ink
    alpha=np.clip((p*1.16-.08-field)/.09,0,1)
    if index==0:alpha[:]=0
    if index==17:alpha[:]=1
    rgba=np.ones((960,540,4),dtype=np.uint8)*255;rgba[:,:,3]=(alpha*255).astype(np.uint8)
    Image.fromarray(rgba).save(maskdir/f'{index:02d}.png',optimize=True)
(out/'SOURCES.json').write_text(json.dumps({'pack':'6000+Motion Graphics Pack V5.1-002','origin':'Complete files recovered from first uploaded RAR volume; full pack not extracted.','files':[{'source':'Atom After Effects/_footage/'+('Brush 2.png' if name=='brush.png' else 'Ink/Ink_1.mp4'),'local':name,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in ['brush.png','ink-source.mp4']],'derived':'18 alpha PNG masks; ink modulates a diagonal reveal; endpoint masks explicit.','license_status':'User-supplied pack; redistribution/commercial license not independently verified. No AEP executed.'},indent=2)+'\n')
print('Prepared 18 deterministic ink masks, brush texture and 4 pinned registry sources.')
