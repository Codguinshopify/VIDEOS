import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const frames = process.argv.slice(2).map(Number);
if (!frames.length) frames.push(0,8,30,53,65,95,130,150,180,220,280,325,360,420,470,490,525,570,600,645,685,720,770,820,860,895,925,975,1025);
const output = path.resolve('review/v7-stills');
fs.mkdirSync(output,{recursive:true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.jsx')});
const browser = await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl,id:'EvoquexLibrary',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
  for (const frame of frames) {
    await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,scale:.5,imageFormat:'png',output:path.join(output,`${String(frame).padStart(4,'0')}.png`)});
    console.log(`Reviewed frame ${frame}`);
  }
} finally { await browser.close({silent:true}); }
