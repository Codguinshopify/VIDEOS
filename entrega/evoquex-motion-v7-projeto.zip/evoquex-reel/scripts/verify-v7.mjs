import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'..');
const timing=JSON.parse(fs.readFileSync(path.join(root,'src/motion-v7/timeline.json'),'utf8'));
if(process.argv.includes('--require-voice'))throw new Error('Locução natural V7 pendente. Esta composição exporta a prévia visual/sonora; não simule uma versão narrada.');
const items=['assets/DANYS.mp4','assets/clevelandia.jpg','assets/resultados.jpg','library-v7/brush.png',timing.sound_file];
for(const item of items){
 const file=path.join(root,'public',item);
 if(!fs.existsSync(file))throw new Error(`Missing real media: ${item}`);
 const r=spawnSync('ffprobe',['-v','error','-show_format','-of','json',file],{encoding:'utf8'});
 if(r.status!==0)throw new Error(`Invalid media: ${item}`);
}
for(let i=0;i<18;i++)if(!fs.existsSync(path.join(root,'public/library-v7/ink-masks',`${String(i).padStart(2,'0')}.png`)))throw new Error(`Missing ink mask ${i}`);
if(timing.business!=='Danny’s Presentes'||timing.metrics.reach!==13064||timing.metrics.impressions!==20981)throw new Error('Unexpected business or campaign data');
if(timing.chapters.reduce((n,c)=>n+c.frames,0)!==timing.total_frames)throw new Error('Timeline duration mismatch');
console.log('V7: real assets, masks, mix and campaign data verified. Natural narration remains pending.');
