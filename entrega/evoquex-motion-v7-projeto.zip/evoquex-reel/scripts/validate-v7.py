"""Validate real video/audio, media preservation and active V7 assets."""
from pathlib import Path
import subprocess,json,hashlib,re,sys
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
video=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v7-previa.mp4')
timing=json.loads((ROOT/'src/motion-v7/timeline.json').read_text())
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='30/1'
assert (v['width'],v['height'])==(1080,1920) and int(v['nb_frames'])==timing['total_frames']
assert abs(float(probe['format']['duration'])-34.5)<.1
assert a['codec_name']=='aac' and int(a['sample_rate'])==48000 and a['channels']==2
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(video),'-f','null','-'],check=True,capture_output=True)
originals=json.loads((ROOT/'review/original-media-integrity.json').read_text())
for name,record in originals.items():assert hashlib.sha256((ROOT/'public/assets'/name).read_bytes()).hexdigest()==record['sha256']
for name in ['brush.png','ink-source.mp4',*[f'ink-masks/{i:02d}.png' for i in range(18)]]:assert (ROOT/'public/library-v7'/name).is_file()
assert timing['metrics']=={'reach':13064,'impressions':20981} and timing['business']=='Danny’s Presentes'
active=(ROOT/'src/motion-v7/Reel.jsx').read_text()+(ROOT/'src/motion-v7/library.jsx').read_text()
assert 'pf_dora' not in active and 'Kokoro' not in active and "volume={0}" in active
assert not re.search(r'Dany[’\x27]s|Dannys',active,re.I)
def pcm(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-f','f32le','-ar','48000','-ac','2','pipe:1']),dtype='<f4').reshape(-1,2)
encoded=pcm(video);source=pcm(ROOT/'public'/timing['sound_file']);n=min(len(encoded),len(source));corr=float(np.corrcoef(encoded[:n].reshape(-1),source[:n].reshape(-1))[0,1]);assert corr>.98
peak=float(np.max(np.abs(encoded)));clipping=int(np.sum(np.abs(encoded)>=1));assert clipping==0
p=subprocess.run(['ffmpeg','-hide_banner','-i',str(video),'-af','loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
measurement=json.loads(re.findall(r'\{[^{}]*"input_i"[^{}]*\}',p.stderr,re.S)[-1]);assert float(measurement['input_tp'])<0
report={'file':video.name,'bytes':video.stat().st_size,'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'duration':probe['format']['duration'],'frames':v['nb_frames'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'video_codec':v['codec_name'],'color_space':v.get('color_space'),'audio_codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'full_decode_passed':True,'original_media_sha256_preserved':True,'audio_source_correlation':corr,'sample_peak':peak,'clipped_samples':clipping,'loudness':measurement,'voice_present':False,'subjective_listening_performed':False,'metrics':timing['metrics'],'business':timing['business']}
(ROOT/'review/v7-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
