"""Create a portable V7 source package, excluding caches and credentials."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
ROOT=Path(__file__).resolve().parent.parent
output=ROOT/'out/evoquex-motion-v7-projeto.zip'
files=set()
for folder in ['src','public','scripts','resources','audio-sources']:
 files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.update(p for p in ROOT.glob('*.md') if p.is_file())
files.update(ROOT/n for n in ['package.json','package-lock.json','.gitignore'])
for pat in ['v7-*.json','v7-*.md','v7-preview-*.jpg','v7-preview-phone-*.png','v7-comparison.jpg','original-media-integrity.json']:
 files.update((ROOT/'review').glob(pat))
files.discard(ROOT/'review/v7-package-validation.json')
with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):
  assert not p.name.startswith('.env')
  z.write(p,'evoquex-reel/'+p.relative_to(ROOT).as_posix())
with ZipFile(output) as z:
 assert z.testzip() is None
 required=['src/motion-v7/Reel.jsx','src/motion-v7/library.jsx','src/motion-v7/timeline.json','public/library-v7/brush.png','public/library-v7/ink-masks/17.png','public/audio-v7/direcao-mix.wav','resources/hyperframes/LICENSE','package-lock.json']
 for p in required:assert z.read('evoquex-reel/'+p)==(ROOT/p).read_bytes()
 assert not any('/node_modules/' in p or '/.env' in p or '/.git/' in p for p in z.namelist())
report={'file':output.name,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'file_count':len(files),'crc_verified':True,'required_source_files_verified':True,'dependencies_and_secrets_excluded':True}
(ROOT/'review/v7-package-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
