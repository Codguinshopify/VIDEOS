"""Validate the delivered MP4 metadata and decode its full video/audio streams."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
video = root / (sys.argv[1] if len(sys.argv) > 1 else 'out/evoquex-clevelandia.mp4')
refined = 'motion-v4' in video.name
expected_frames = 780 if refined else 840
expected_seconds = expected_frames / 30
probe = subprocess.run([
    'ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format',
    '-of', 'json', str(video),
], check=True, capture_output=True, text=True)
data = json.loads(probe.stdout)
picture = next(stream for stream in data['streams'] if stream['codec_type'] == 'video')
sound = next(stream for stream in data['streams'] if stream['codec_type'] == 'audio')
assert picture['codec_name'] == 'h264', picture
assert picture['pix_fmt'] == 'yuv420p', picture
assert picture['color_space'] == 'bt709' and picture['color_range'] == 'tv', picture
assert (picture['width'], picture['height']) == (1080, 1920), picture
assert picture['r_frame_rate'] == '30/1', picture
assert int(picture['nb_read_frames']) == expected_frames, picture
assert abs(float(data['format']['duration']) - expected_seconds) < 0.1, data['format']
assert sound['codec_name'] == 'aac' and sound['channels'] == 2, sound
subprocess.run(['ffmpeg', '-v', 'error', '-i', str(video), '-f', 'null', '-'], check=True)
status = json.loads((root / 'src/assets.json').read_text())
assert all(status.values()), status
report = {
    'file': video.name,
    'duration_seconds': float(data['format']['duration']),
    'resolution': [picture['width'], picture['height']],
    'fps': 30,
    'frames': int(picture['nb_read_frames']),
    'video_codec': picture['codec_name'],
    'pixel_format': picture['pix_fmt'],
    'color_space': picture['color_space'],
    'color_range': picture['color_range'],
    'audio_codec': sound['codec_name'],
    'audio_channels': sound['channels'],
    'audio_sample_rate': int(sound['sample_rate']),
    'size_bytes': video.stat().st_size,
    'sha256': hashlib.sha256(video.read_bytes()).hexdigest(),
    'full_decode_passed': True,
    'all_original_assets_present': True,
}
report_name = 'motion-v4-validation.json' if refined else 'motion-v3-validation.json' if 'motion-v3' in video.name else 'motion-v2-validation.json' if 'motion-v2' in video.name else 'final-validation.json'
(root / 'review' / report_name).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
