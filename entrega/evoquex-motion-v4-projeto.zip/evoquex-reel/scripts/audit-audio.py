"""Decode the exported audio, check levels and verify the intended synchronized mix."""
from pathlib import Path
import json
import re
import subprocess
import sys
import wave
import numpy as np

root=Path(__file__).resolve().parent.parent
video=root/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v4.mp4')
refined='motion-v4' in video.name
tag='motion-v4' if refined else 'motion-v3'
mix=root/'public/assets'/('evoquex-refinado.wav' if refined else 'evoquex-premium.wav')
p=subprocess.run(['ffmpeg','-v','info','-i',str(video),'-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
levels=json.loads(re.findall(r'\{[\s\S]*?\}',p.stderr)[-1])
(root/'review'/f'{tag}-audio-analysis.json').write_text(json.dumps(levels,indent=2)+'\n')
p=subprocess.run(['ffmpeg','-v','error','-i',str(video),'-vn','-ar','48000','-ac','2','-f','f32le','-'],capture_output=True,check=True)
a=np.frombuffer(p.stdout,dtype='<f4').reshape(-1,2)
with wave.open(str(mix),'rb') as w:
    b=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)/32768
n=min(len(a),len(b))
correlation=float(np.sum(a[:n]*b[:n])/np.sqrt(np.sum(a[:n]**2)*np.sum(b[:n]**2)))
assert correlation>.95,correlation
assert np.all(np.isfinite(a))
cuts=[0,3.35,6.4,10.2,14,19.6,26] if refined else [0,3.35,6.6,10.6,14.6,20.8,28]
segments=[]
for left,right in zip(cuts,cuts[1:]):
    x=a[round(left*48000):round(right*48000)]
    segments.append({'start':left,'end':right,'rms_dbfs':round(float(20*np.log10(np.sqrt(np.mean(x*x))+1e-12)),2),'sample_peak_dbfs':round(float(20*np.log10(np.max(np.abs(x))+1e-12)),2)})
report={'analyzed_file':video.name,'sample_rate':48000,'channels':2,'decoded_duration_seconds':len(a)/48000,'clipped_samples':int(np.count_nonzero(np.abs(a)>=1)),'integrated_lufs':float(levels['input_i']),'true_peak_dbtp':float(levels['input_tp']),'segments':segments,'correlation_with_intended_mix_at_zero_delay':correlation,'full_audio_decode_passed':True,'subjective_listening_available':False}
assert report['clipped_samples']==0
(root/'review'/f'{tag}-audio-integrity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
