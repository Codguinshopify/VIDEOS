import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const frames = process.argv.slice(2).map(Number);
if (!frames.length) frames.push(0,1,3,6,12,24,45,90,114,130,192,205,250,290,306,320,365,405,420,438,480,550,588,605,635,710,775);
const output = path.resolve('review/v4-stills');
fs.mkdirSync(output,{recursive:true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.jsx')});
const browser = await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl,id:'EvoquexPremium',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
  for (const frame of frames) {
    await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,scale:.5,imageFormat:'png',output:path.join(output,`${String(frame).padStart(4,'0')}.png`)});
    console.log(`Reviewed frame ${frame}`);
  }
} finally { await browser.close({silent:true}); }
