import React from 'react';
import {AbsoluteFill, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {C, glide, tween} from './system';
import {Recognition} from './Recognition';
import {Local} from './Local';
import {Reach, Impressions} from './Proof';
import {Opportunity} from './Opportunity';
import {Contact} from './Contact';

const Reveal = ({children, kind}) => {
  const f = useCurrentFrame();
  const p = tween(f, [0, kind === 'story' ? 9 : kind === 'cta' ? 12 : 10], [0, 1], glide);
  const mask = kind === 'proof' ? `circle(${p * 145}% at 60% 58%)` : kind === 'impressions' ? `ellipse(${p * 160}% ${p * 110}% at 16% 73%)` : kind === 'story' ? `polygon(0 ${100 - p * 200}%,100% ${145 - p * 200}%,100% 100%,0 100%)` : `circle(${p * 150}% at 77% 70%)`;
  return <AbsoluteFill style={{clipPath: mask}}>{children}</AbsoluteFill>;
};

export const EvoquexPremium = () => {
  const f = useCurrentFrame(), {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: C.paper}}>
    <Sequence name="Reconhecimento — máscara do anúncio" from={0} durationInFrames={3.8 * fps} premountFor={fps}><Recognition/></Sequence>
    <Sequence name="Contexto — fotografia e trajetória local" from={3.8 * fps} durationInFrames={2.6 * fps + 10} premountFor={fps}><Local/></Sequence>
    <Sequence name="Prova — extração de 13.064 pessoas" from={6.4 * fps} durationInFrames={3.8 * fps + 10} premountFor={fps}><Reveal kind="proof"><Reach/></Reveal></Sequence>
    <Sequence name="Distribuição — 20.981 impressões" from={10.2 * fps} durationInFrames={3.8 * fps + 9} premountFor={fps}><Reveal kind="impressions"><Impressions/></Reveal></Sequence>
    <Sequence name="Oportunidade — da campanha à empresa" from={14 * fps} durationInFrames={5.6 * fps + 12} premountFor={fps}><Reveal kind="story"><Opportunity/></Reveal></Sequence>
    <Sequence name="Conversão — chamada da Evoquex" from={19.6 * fps} durationInFrames={6.4 * fps} premountFor={fps}><Reveal kind="cta"><Contact/></Reveal></Sequence>
    <Audio name="Mix refinado — acentos do hook e transições sincronizadas" src={staticFile('assets/evoquex-refinado.wav')} premountFor={fps}/>
  </AbsoluteFill>;
};
