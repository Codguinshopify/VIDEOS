import React from 'react';
import {Sequence, useCurrentFrame, useVideoConfig} from 'remotion';
import {Base, C, CityPlane, Corners, FilmPlane, MaskLine, Path, PlayToken, tween} from './system';
import {BUSINESS_SHORT} from '../case';

export const Local = () => {
  const f = useCurrentFrame(), {fps} = useVideoConfig();
  const p = tween(f, [0, 23], [0, 1]);
  const cityX = 420 - 356 * p, cityY = 950 - 210 * p, cityW = 750 + 200 * p;
  return <Base>
    <div style={{position: 'absolute', left: 94, top: 185 - tween(f, [0, 14], [0, 700]), width: 910, opacity: tween(f, [0, 11], [1, 0])}}><MaskLine size={90} at={-107}>Você chegou</MaskLine><MaskLine size={90} at={-97}>a ver esse vídeo</MaskLine><MaskLine size={82} at={-72} color={C.blue}>em Clevelândia?</MaskLine></div>
    <div style={{position: 'absolute', left: 94, top: 300, width: 910}}><MaskLine size={91} at={6}>Da {BUSINESS_SHORT}</MaskLine><MaskLine size={91} at={11} color={C.blue}>para Clevelândia.</MaskLine></div>
    <div style={{position: 'absolute', width: 670, height: 670, left: 510, top: 900, borderRadius: '50%', background: '#E0E9FF', scale: 1 + .12 * p, opacity: 1 - p * .6}} />
    <FilmPlane x={96 - 480 * p} y={650 + 70 * p} width={490 - 180 * p} rotate={-7 - 13 * p} yaw={-10} opacity={1 - p} start={3.8 * fps} />
    <CityPlane x={cityX} y={cityY} width={cityW} rotate={9 - 12 * p} yaw={12 * p} progress={tween(f, [18, 39], [0, 1])} focus />
    <Path d="M540 1450C760 1510 1000 1430 950 1200" progress={tween(f, [-12, 10], [0, 1])} opacity={1 - p} />
    <Path d="M96 1460C240 1500 250 1300 404 1270S680 1250 650 1090" progress={tween(f, [18, 38], [0, 1])} width={5}/>
    <PlayToken x={490 - 446 * p} y={1400 + 10 * p} size={106 - 20 * p} progress={1} rotate={-7 + 7 * p}/>
    <div style={{position: 'absolute', left: 96, top: 1525, opacity: tween(f, [29, 43], [0, 1])}}><div style={{fontSize: 43, fontWeight: 800, letterSpacing: -1.5}}>Clevelândia, PR</div><div style={{fontSize: 27, color: C.muted, marginTop: 12}}>Uma campanha. Contexto local.</div></div>
    <div style={{position: 'absolute', left: 730, top: 655, fontSize: 24, color: C.muted, opacity: tween(f, [32, 44], [0, 1]), letterSpacing: 1.5}}>ALCANCE LOCAL</div>
  </Base>;
};
