# Revisão final — refinamento V4

## Escopo preservado

Refinamento dos mesmos componentes da V3 aprovada: seis cenas, mesma identidade, materiais, planos, vetores e direção musical. Nenhuma dependência adicional instalada. A V3 original permanece arquivada com seu MP4 e fonte.

## Prévia e correção

Foi renderizada uma prévia completa de 26 s. A primeira inspeção de stills do hook mostrou a primeira frase cortada no frame zero; sua acomodação foi ajustada, mantendo movimento de escala e posição. A prévia posterior e o MP4 final começam com “Você chegou” legível, filmagem em recorte angular, contorno parcialmente traçado e linha já visível. As amostras f0, f1, f2, f3, f6, f9, f12, f18, f24, f30 e f45 confirmam evolução visual desde o começo.

Foram comparados o hook e as passagens equivalentes da V3 com a versão refinada. As máscaras passaram de 18 para 9–12 frames, a troca do anúncio para a cidade de 37 para 23 frames e a entrada do CTA foi antecipada. Não houve aceleração global da filmagem ou da voz. Os movimentos preservam curvas e acomodação; as máscaras mantêm geometrias diferentes.

## Inspeção do MP4 final

52 amostras distribuídas pela duração, 35 quadros junto às cinco mudanças de cena, 11 quadros do hook e quatro telas em 360 × 640 foram examinados. As composições das métricas e do CTA permanecem legíveis; os textos de leitura não apresentam cortes após a acomodação. As letras parcialmente recortadas durante suas entradas pertencem às máscaras, não a um erro de layout.

A grafia “Danny’s Presentes” foi conferida no rodapé real do MP4, e “Da Danny’s” na cena local. Todos os textos/labels autorais utilizam src/case.jsx. Não há grafia antiga em JSX. Nomes de arquivos de mídia são históricos, e briefings recebidos têm aviso de correção; não são usados como texto renderizado.

13.064 pessoas alcançadas e 20.981 impressões foram preservados e comparados às regiões do documento original. Nenhuma visualização, venda ou depoimento foi acrescentado. Os gráficos de distribuição são conceituais.

## Som e integridade

Mantida a base musical da V3. Efeitos, duração e fades foram sincronizados aos cortes novos; o hook tem impacto curto e sweep, e a fala original permanece na abertura. O WAV tem áudio ativo nos primeiros 1/30 s. No MP4, a correlação com a mixagem refinada no mesmo instante é 0.999941, indicando correspondência temporal com a trilha pretendida.

Áudio AAC estéreo 48 kHz: -17.39 LUFS, -1.5 dBTP, 0 amostras clipadas. Imagem e som foram decodificados por inteiro sem erros. A interface não oferece escuta: a revisão sonora é técnica, sem alegar audição subjetiva ou reprodução audiovisual humana.

MP4: 780 frames, 1080 × 1920, 30 fps, H.264/yuv420p/BT.709, 26 s de imagem e 26.005 s no contêiner. SHA-256: 128c145025d1ad74d8c74d039e5c22759c8275f055bc50d9670c32cf9e453917. Os três materiais originais conservam seus hashes e bytes.

## Reprodução da entrega

O ZIP foi extraído em pasta limpa. npm ci --offline instalou 253 pacotes pelo lockfile, o preflight confirmou as mídias e o Chromium renderizou os frames 0, 165, 260 e 720 da composição EvoquexPremium. Os 51 arquivos de runtime, mídia e scripts foram comparados byte a byte com o projeto validado. A atualização posterior do pacote acrescenta somente documentação de revisão, sem mudar esses arquivos.
