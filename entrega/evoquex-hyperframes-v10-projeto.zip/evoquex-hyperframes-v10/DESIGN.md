# Evoquex V10 — Mensagem em movimento

## Concept and authority
The new 44.65s Park/Shard Cloud reference is the primary design authority. V9 is
factual/source context only. The shared lens is the narrative thread: a circle becomes
a message pill, an aperture, a distribution plane, evidence and finally an invitation.
No V7/V8/V9 layout, typography treatment, photo collage, marquee, tile-wave or headers.
The render stays HyperFrames 0.8.162, native HTML/GSAP 3.14.2, 1080×1920/30fps/33s.

## Palette
#FDFEFF — canvas, nearly white. #EEF4FC — soft pale-blue surface and local fog.
#355CE8 — saturated statement blue. #7BA9DF — secondary light strokes, never body text.
#17191F — ink and one brief high-contrast punctuation. #526B9A — readable supporting copy.
Local radial light and pearlescent rings are allowed by the supplied reference; no
full-frame dark linear gradient. All photographic colors remain original.

## Typography and density
DM Sans variable, local WOFF2/OFL: friendly speaking voice at 450 and compact emphatic
700–800, 82–108px headlines, 46–58px descriptions, 30–34px evidence labels. Time and
central scale create hierarchy, not huge edge-to-edge posters. Numerals tabular.
One focal statement, one main graphic and at most two supporting labels per pose.
No top masthead, numbered sections, permanent footer, fake UI or tiny disclaimers.

## Motion
One synchronous paused root timeline. Six continuous movements, not six slides:
0–4.5 message / 4.5–9.5 production / 9.5–14.5 local distribution /
14.5–22 evidence / 22–27 message+audience / 27–33 invitation.
Micro-changes 0.7–1.4s where speech would change meaning; holds 1.8–2.5s for proof.
The lens persists above scene boundaries. SVG ellipse geometry, camera-plane rotation,
MotionPath packets, masked word replacement, SVG path morph, focus/blur and shared
physical anchors connect ideas. No random collection of catalog transitions.
Motion starts at frame zero. Easing follows weight: power3/4 for word changes,
sine for continuous lens drift, back.out(1.05) only on small settling gestures.

## Actual assets and constraints
Evoquex produced Danny’s Presentes video and targeted only Clevelândia. Instagram /
Facebook confirmed. 13.064 people reached; 20.981 impressions. No views, ROI or sales.
Footage is shown once for context/proof, not looped through the whole piece. Screenshot
is real. City photo is only 600×337; limit its size, do not invent geographic coverage.
The partial user pack exposes mostly AEP files; extracted brush/ink footage is valid
but unsuitable for this clean glass direction, so it is not forced into the piece.
Use licensed Lucide SVG sources before manual icon construction. No AEP runtime claim.
No rejected voice, no voice API credentials and no paid service. Current output has
music and resynchronized existing effects; voice remains an explicitly pending asset.

## What NOT to Do
No V9 filmstrip, photo-glyph headline, orbiting text chips, cyan metric poster or mosaic.
No generic repeated fade-in layout. No invented chart, completion percentage, quote or
message interface. No copying reference media/audio or its SaaS claims. No comparative
video or sheet delivered to the user: deliver only the edited video.
