# Roteiro e direção V10

Ajuste proposto antes da implementação: a mensagem e a distribuição conduzem a peça;
o case é prova pontual. As duas métricas não ocupam o centro da narrativa inteira.

Roteiro de locução preparado, NÃO gravado: “Para divulgar sua empresa, começamos pela
mensagem. Transformamos essa ideia em vídeo e levamos o anúncio para o público da sua
cidade. Foi assim com a Danny’s Presentes, em Clevelândia. Os registros mostram pessoas
alcançadas e exibições do anúncio. Para seu negócio ou serviço, o caminho começa com
duas escolhas: o que dizer e com quem falar. Quer fazer algo assim? Conversa com a gente.”
A locução feminina natural está pendente. Esta versão se sustenta também por texto em
tela, música e efeitos reais; não se finge sincronização com voz inexistente.

| Tempo | Texto essencial | Movimento e função |
|---|---|---|
| 0–4,5 | Sua empresa. Seu serviço. Uma mensagem. | Lente clara concentra atenção; palavras substituídas dentro dela; círculo comprime em cápsula e vira abertura do vídeo. |
| 4,5–9,5 | A ideia vira vídeo. Danny’s Presentes. Produzido pela Evoquex. | Ícone de câmera se desenha; quadro real único revelado pela lente, plano inclina e se prepara para distribuir. |
| 9,5–14,5 | E chega ao público da sua cidade. Instagram + Facebook. Só em Clevelândia. | Mesmo plano vira ligação entre canais; pequenos pacotes percorrem curvas; alvo se fecha na cidade e não simula um mapa de alcance. |
| 14,5–22 | 13.064 pessoas alcançadas. 20.981 exibições do anúncio. | Captura documenta; dados trocam dentro da lente e ficam ambos legíveis no final. Sem gráfico de vendas ou proporção inventada. |
| 22–27 | O que dizer? Com quem falar? | Círculo se divide em duas cápsulas, texto acompanha o encaixe; as duas decisões se conectam. |
| 27–33 | Quer fazer algo assim? Conversa com a gente. Evoquex. | Cápsulas se unem em convite; marca resolve por foco e letras, com pausa final limpa. |
