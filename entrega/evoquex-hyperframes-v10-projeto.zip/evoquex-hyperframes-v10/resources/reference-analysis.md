# Análise concreta da referência e da V9

Referência: Park/Shard Cloud, 44,652 s, 576×1024/30fps. Inspeção de 89 quadros a 2fps
abrangendo toda a duração e detalhes subsegundo. Áudio transcrito por Whisper base e
RMS; não houve escuta subjetiva. O áudio da referência não será reutilizado.

0–1,9s: palavras compactas no centro, lente difusa e entrada de telefone com texto
condensado atrás. A escala principal é concentrada, com grandes margens brancas.
2,1–4,8s: disco preto expande, texto vira bloco/cápsula; palavras são substituídas
na mesma área. O objeto de uma composição se torna a base da seguinte.
5–9,3s: linha/gráfico, marca facetada, lente translúcida e nuvem: motivos reaparecem
com funções novas. Nada exige reproduzir os números fictícios do exemplo.
9,5–12,5s: linhas elípticas em perspectiva, pequenos nós e tipografia conduzem o olhar.
12,7–17,5s: escuro pontua UI real; retorno ao branco; palavra/plataforma ocupa a lente
e o arco desenha o destaque de métricas. Mudanças internas são mais curtas que a cena.
17,5–21,2s: domínio/CDN/backups substituem conteúdo dentro de círculos; azul pontua.
21,5–28,8s: elementos e palavras se conectam, lente modifica proporções, + vira cápsula.
29–34,5s: telefone real pontual, aros, ícone monetário e corte escuro contrastante.
35–44,65s: marca resolve e permanece; respiro maior que o restante.

A V9 foi inspecionada no MP4 e nas folhas de quadros exportados, além dos fontes.
Limitações: seis telas longas, enquadramento sempre quase frontal, títulos grandes
no topo, vídeo repetido no hook/filmstrip e efeitos que acabam antes de o próximo
argumento começar. A mudança de fundo não é continuidade de objeto. Trilha e tempos
herdados preservavam a lógica antiga, e não uma nova frase audiovisual.

Execução V10: lente compartilhada em SVG acima das divisões; morph geométrico de
elipse/cápsula, palavras mascaradas, câmera e canais com SVG Lucide traçado, pacotes
em curvas GSAP MotionPath, selo play→check por paths compatíveis do catálogo e foco
na marca. Tipografia DM Sans, branco e azul menos saturado com luz localizada. A
filmagem aparece uma vez; dados servem de prova. No máximo duas camadas narrativas
concorrem com o objeto principal. Fontes e dependências de render são reaproveitados;
nenhuma biblioteca de runtime adicional é necessária.
