/* Evoquex V10: one shared lens, authored object continuity, no old V9 scene
 * layout or catalog-transition roulette. All motion is absolute and seekable.
 * Catalog source mechanics and Lucide geometry are retained under resources/.
 */
gsap.registerPlugin(MotionPathPlugin);
const tl=window.__timelines['evoquex-hf-v10'];
const shapeIds=['#lens-bloom','#lens-body','#lens-hairline','#lens-arc'];
function lens(at,{cx=540,cy=960,rx=330,ry=330},duration=.7,ease='power3.inOut'){
 shapeIds.forEach((id,i)=>tl.to(id,{attr:{cx,cy,rx:rx+(i===2?13:i===3?26:0),ry:ry+(i===2?13:i===3?26:0)},duration,ease},at));
}
function partner(at,{cx=540,cy=1120,rx=390,ry=95},duration=.7){
 tl.to('#partner-body',{attr:{cx,cy,rx,ry},duration,ease:'power3.inOut'},at);
 tl.to('#partner-line',{attr:{cx,cy,rx:rx+10,ry:ry+8},duration,ease:'power3.inOut'},at);
}
// Focus/crossfade occurs during the handoff, never on an emptied outgoing frame.
function handoff(from,to,at){
 tl.to(from,{opacity:0,filter:'blur(7px)',duration:.38,ease:'power2.inOut'},at);
 tl.fromTo(to,{opacity:0,filter:'blur(7px)'},{opacity:1,filter:'blur(0px)',duration:.45,ease:'power2.out',immediateRender:false},at+.09);
}
function draw(selector,at,stagger=0){
 document.querySelectorAll(selector).forEach(e=>{e.setAttribute('pathLength','1');e.style.strokeDasharray='1';e.style.strokeDashoffset='1';});
 tl.to(selector,{strokeDashoffset:0,stagger,duration:.7,ease:'power2.inOut'},at);
}
// The opening artwork is already present and moving on frame zero.
tl.from('#lens-main',{scale:.8,rotation:-8,svgOrigin:'540 960',duration:.8,ease:'power3.out'},0);
tl.to('#lens-arc',{strokeDashoffset:-1650,duration:4.4,ease:'sine.inOut'},0);
tl.from('.small-intro',{y:38,scale:.94,duration:.55,ease:'power3.out'},0);
tl.from('#word-company',{yPercent:25,scale:.94,filter:'blur(4px)',duration:.6,ease:'expo.out'},0);
tl.from('.brand-tiny',{opacity:.3,y:15,duration:.65,ease:'power2.out'},0);
tl.from('#message-note',{y:25,opacity:0,duration:.4,ease:'power2.out'},.35);
tl.from('.message-spark',{scale:.5,rotation:-90,opacity:0,duration:.5,ease:'back.out(1.05)'},.3);
tl.to('.fog-one',{x:80,y:-55,scale:1.1,duration:15.5,ease:'sine.inOut'},0);
tl.to('.fog-two',{x:-70,y:70,scale:1.15,duration:16,ease:'sine.inOut'},0);
tl.to('#word-track',{y:-135,duration:.35,ease:'power3.inOut'},1.1);
tl.to('#word-track',{y:-270,duration:.35,ease:'power3.inOut'},2.2);
tl.set('.small-intro',{textContent:'Começamos com'},2.2);
lens(2.95,{cy:916,rx:450,ry:94},.65);
tl.to('.message-spark',{rotation:90,scale:.75,duration:.5,ease:'power3.inOut'},3.45);

// The same lens becomes the filming plane. Footage appears only here, once.
handoff('#message','#production',4.15);
lens(4.15,{cy:1000,rx:340,ry:415},.85,'power4.inOut');
tl.to('#lens-arc',{opacity:.25,strokeDashoffset:-2100,duration:.65,ease:'power2.out'},4.15);
tl.from('#production h1',{y:50,scale:.95,opacity:0,duration:.6,ease:'power3.out'},4.4);
draw('.camera-drawing path,.camera-drawing circle,.camera-drawing rect',4.12,.04);
tl.from('.camera-drawing',{scale:.7,rotationY:-18,duration:.65,ease:'power3.out'},4.12);
tl.fromTo('.film-plane',{scale:.12,rotationY:38,rotation:-8,opacity:0},{scale:1,rotationY:-7,rotation:2,opacity:1,duration:.75,ease:'power4.out',immediateRender:false},4.55);
tl.to('.film-plane',{rotationY:5,rotation:-2,y:-7,duration:3.3,ease:'sine.inOut'},5.7);
tl.from('.case-name',{y:28,opacity:0,duration:.5,ease:'power2.out'},5.2);
tl.from('.production-credit',{y:24,opacity:0,duration:.45,ease:'power2.out'},5.4);

// The filming plane collapses into a distribution packet as the curved paths
// grow from its center. MotionPath recipe adapted from arc-motion-path.
handoff('#production','#distribution',9.45);
tl.to('.film-plane',{scale:.19,rotationY:52,rotation:16,x:50,y:95,duration:.45,ease:'power3.inOut'},9.4);
lens(9.45,{cy:1000,rx:440,ry:175},.8);
tl.to('#lens-main',{rotation:-13,svgOrigin:'540 1000',duration:.8,ease:'power3.inOut'},9.45);
tl.to('#lens-arc',{opacity:.7,strokeDashoffset:-3000,duration:2.4,ease:'sine.inOut'},10);
tl.from('#distribution h2',{y:40,opacity:0,duration:.6,ease:'power3.out'},9.8);
tl.from('.channel',{scale:.65,rotationX:25,y:35,opacity:0,stagger:.17,duration:.55,ease:'back.out(1.05)'},10.05);
draw('.routes path',9.9,.1);
['a','b','c'].forEach((n,i)=>{
 tl.set('#packet-'+n,{opacity:1},10.4+i*.15);
 tl.to('#packet-'+n,{motionPath:{path:'#route-'+n,align:'#route-'+n,alignOrigin:[.5,.5]},duration:1.1+i*.1,ease:'sine.inOut',repeat:1,repeatDelay:.08},10.4+i*.15);
 tl.to('#packet-'+n,{opacity:0,duration:.12,ease:'power2.out'},12.85+i*.08);
});
tl.from('.local-node',{scale:.4,rotation:-25,opacity:0,duration:.55,ease:'power3.out'},10.25);
draw('.local-node path,.local-node circle',10.4,.04);
tl.from('.local-name',{y:42,opacity:0,filter:'blur(6px)',duration:.6,ease:'power3.out'},11.8);
tl.from('.city-glimpse',{rotationY:50,rotation:15,scale:.65,x:80,opacity:0,duration:.7,ease:'power3.out'},12.15);
tl.from('.distribution-note',{y:25,opacity:0,duration:.45,ease:'power2.out'},12.5);

// Documented proof. A play silhouette becomes a check using the matching
// 16-vertex paths in the HyperFrames icon-morph-beat catalog component.
handoff('#distribution','#evidence',14.45);
lens(14.45,{cy:868,rx:360,ry:330},.75);
tl.to('#lens-main',{rotation:0,svgOrigin:'540 868',duration:.75,ease:'power3.inOut'},14.45);
tl.to('#lens-arc',{opacity:.55,strokeDashoffset:-4400,duration:4.8,ease:'sine.inOut'},14.8);
tl.from('.evidence-intro',{y:35,opacity:0,duration:.55,ease:'power3.out'},14.7);
tl.from('.evidence-brand',{y:24,opacity:0,duration:.45,ease:'power2.out'},14.9);
tl.from('.source-doc',{y:70,scale:.75,rotation:6,opacity:0,duration:.65,ease:'power3.out'},14.8);
tl.from('.proof-copy',{x:30,opacity:0,duration:.5,ease:'power2.out'},15.05);
tl.to('#status-shape',{attr:{d:'M 16 50 L 20 46 L 24 42 L 34 52 L 44 62 L 52 54 L 60 46 L 68 38 L 76 30 L 80 34 L 84 38 L 74 48 L 64 58 L 54 68 L 44 78 L 34 68 Z'},duration:.55,ease:'power3.out'},15.1);
tl.to('.proof-stamp',{scale:1.08,duration:.12,ease:'power3.out'},15.65);
tl.to('.proof-stamp',{scale:1,duration:.18,ease:'power2.out'},15.77);
function count(id,value,at,duration){
 tl.set(id,{textContent:'0'},14.45);
 const frames=Math.round(duration*30);
 for(let f=0;f<=frames;f++){const e=(1-Math.cos(Math.PI*f/frames))/2;tl.set(id,{textContent:Math.round(value*e).toLocaleString('pt-BR')},at+f/30);}
}
tl.fromTo('#reach-mode',{opacity:0,y:45},{opacity:1,y:0,duration:.5,ease:'power3.out',immediateRender:false},14.9);
count('#reach-number',13064,15,.7);
tl.to('#reach-mode',{yPercent:-105,y:0,opacity:0,filter:'blur(4px)',duration:.4,ease:'power3.inOut'},17.85);
tl.fromTo('#impressions-mode',{opacity:0,yPercent:105,y:0,filter:'blur(4px)'},{opacity:1,yPercent:0,y:0,filter:'blur(0px)',duration:.45,ease:'power3.out',immediateRender:false},17.95);
count('#impressions-number',20981,18.15,.75);
tl.from('.metric-meaning',{y:25,opacity:0,duration:.5,ease:'power2.out'},18.4);
// The lens splits so the final state clarifies the two distinct measurements.
tl.to('#impressions-mode',{scale:.62,x:230,duration:.65,ease:'power3.inOut'},20.05);
tl.set('#impressions-mode .metric-label',{textContent:'impressões'},20.05);
tl.to('#impressions-mode .metric-term',{opacity:0,duration:.15,ease:'power2.out'},20.05);
tl.fromTo('#reach-mode',{x:-230,y:0,yPercent:0,scale:.62,opacity:0,filter:'blur(4px)'},{opacity:1,filter:'blur(0px)',duration:.3,ease:'power3.out',immediateRender:false},20.48);
lens(20.05,{cx:310,cy:868,rx:215,ry:215},.65);
partner(20.05,{cx:770,cy:868,rx:215,ry:215},.65);
tl.to('#lens-partner',{opacity:1,duration:.4,ease:'power2.out'},20.1);
tl.to('#lens-arc',{opacity:.18,duration:.4,ease:'power2.out'},20.05);

// Those two proof circles become the two strategic questions. No cards,
// chapter labels, stock swipe or resetting the visual world.
handoff('#evidence','#strategy',22);
lens(22,{cx:540,cy:801,rx:425,ry:125},.8);
partner(22,{cx:540,cy:1131,rx:425,ry:125},.8);
tl.from('.strategy-intro',{y:25,opacity:0,duration:.5,ease:'power2.out'},22.2);
tl.from('#strategy h2',{y:40,scale:.94,opacity:0,duration:.55,ease:'power3.out'},22.3);
tl.fromTo('#question-message',{y:50,opacity:0},{y:0,opacity:1,duration:.55,ease:'power3.out',immediateRender:false},22.75);
draw('#question-message path',22.8,.04);
tl.fromTo('#question-audience',{y:50,opacity:0},{y:0,opacity:1,duration:.55,ease:'power3.out',immediateRender:false},24);
draw('#question-audience path,#question-audience circle',24,.04);
draw('.question-connector path',23.45);
tl.from('.strategy-join',{y:35,scale:.9,opacity:0,duration:.5,ease:'power3.out'},25.1);
tl.to('.strategy-join',{backgroundColor:'#17191F',color:'#FDFEFF',duration:.4,ease:'power3.out'},25.45);

// Both decision capsules merge into the human invitation. The wordmark
// resolves through the same focus discipline as the reference (not tiles).
handoff('#strategy','#invitation',27);
lens(27,{cx:540,cy:1000,rx:390,ry:330},.8);
partner(27,{cx:540,cy:1000,rx:390,ry:330},.8);
tl.to('#lens-partner',{opacity:0,duration:.6,ease:'power2.inOut'},27.25);
tl.to('#lens-arc',{opacity:.5,strokeDashoffset:-6000,duration:4.5,ease:'sine.inOut'},27.2);
tl.from('.end-wordmark span',{y:25,rotationX:40,opacity:0,filter:'blur(8px)',stagger:.06,duration:.6,ease:'power3.out'},27.5);
tl.from('#invitation h2',{y:40,opacity:0,filter:'blur(6px)',duration:.65,ease:'power3.out'},28.05);
tl.from('.cta-pill',{scaleX:.1,scaleY:.6,opacity:0,duration:.65,ease:'power4.out'},28.65);
tl.from('.cta-pill span',{y:20,opacity:0,duration:.4,ease:'power2.out'},29);
tl.from('.cta-pill .icon',{x:-25,y:25,opacity:0,duration:.5,ease:'power3.out'},29.2);
tl.to('.cta-pill .icon',{x:9,y:-9,duration:.45,ease:'sine.inOut',yoyo:true,repeat:1},30.25);
tl.from('.end-note',{y:25,opacity:0,duration:.5,ease:'power2.out'},29.55);
tl.to('.fog-one',{x:-20,y:10,scale:1.03,duration:15.5,ease:'sine.inOut'},15.5);
tl.to('.fog-two',{x:20,y:0,scale:1.02,duration:16,ease:'sine.inOut'},16);
window.EVOQUEX_AUDIT={engine:'HyperFrames 0.8.162',version:'V10',duration:33,case:'Danny’s Presentes',reach:13064,impressions:20981,originalAudioGain:0,voice:false,originalFootagePlaybackCount:1,referenceAudioUsed:false};
tl.seek(0);
