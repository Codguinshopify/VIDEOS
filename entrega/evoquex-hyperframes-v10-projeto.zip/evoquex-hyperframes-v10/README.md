# Evoquex V10 — Mensagem em movimento

Nova direção criativa no HyperFrames, baseada na linguagem do vídeo Park/Shard Cloud
fornecido pelo usuário. V9 foi usada apenas como fonte factual e infraestrutura.
Nenhuma de suas composições, transições de catálogo, paleta ciano, Manrope, mosaico,
filmstrip ou textos fotográficos foi conservada. Consulte DESIGN.md e STORYBOARD.md.

33 segundos, 1080×1920, 30fps. Motor HyperFrames 0.8.162, GSAP 3.14.2 e MotionPathPlugin
já incluído no pacote GSAP. DM Sans variável licenciada OFL e SVGs Lucide 0.468.0/ISC
armazenados localmente; nenhuma dependência nova de runtime. O vídeo real aparece uma
única vez. O áudio da referência não é utilizado.

```sh
npm ci
npm run dev
npm run check
npm run render
```

Node 22+, FFmpeg e Chromium são necessários. O wrapper scripts/hf.mjs usa Chromium do
sistema quando disponível e mantém caches graváveis no próprio projeto. O Studio abre
em http://localhost:3002/#project/evoquex-hyperframes-v10 (use a porta informada pelo
comando). Encerre com `node scripts/hf.mjs preview --stop` após a revisão.

## Conteúdo e limites

Danny’s Presentes. A Evoquex produziu o vídeo e divulgou com anúncios Instagram/Facebook
somente para Clevelândia. 13.064 pessoas alcançadas e 20.981 impressões. Sem vendas,
retorno financeiro ou visualizações inventadas. A lente e os percursos representam a
explicação visual, sem simular mapa de alcance, porcentagem de crescimento ou dashboard.

Não há nova locução: o acesso ElevenLabs está indisponível neste ambiente. A voz
rejeitada não foi usada e nenhum plano pago foi contratado. O roteiro de voz está
preparado no storyboard para futura gravação. Esta versão usa texto em tela, música e
efeitos reais remontados dos stems anteriores. Áudio original do vídeo mudo. A análise
sonora é técnica; não há escuta subjetiva nesta interface.

A fotografia aérea é 600×337 e aparece pequena para respeitar sua resolução. Filmagem
original curta/por vezes desfocada preservada. O pack parcial tem sobretudo AEPs, sem
runtime compatível; os inks/pincéis extraídos não foram forçados nesta direção limpa.
Nenhum projeto After Effects foi executado. As bibliotecas de vetores foram utilizadas
antes de tentar redesenhar ícones manualmente.

## Entrega

Somente o vídeo editado ao usuário. Não criar comparativos ou montagens lado a lado.
Fontes e relatórios ficam preservados para continuidade e reprodução. Não incluir o
vídeo de referência, seus frames ou seu áudio na publicação do projeto.
