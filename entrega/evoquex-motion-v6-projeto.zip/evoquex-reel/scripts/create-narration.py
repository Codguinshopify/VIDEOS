"""Real Brazilian Portuguese neural narration, generated before animation timing."""
from pathlib import Path
import hashlib
import json
import os
import importlib.metadata
import numpy as np
import soundfile as sf
import onnxruntime as ort
from kokoro_onnx import Kokoro

ROOT=Path(__file__).resolve().parent.parent
models=Path(os.environ.get('EVOQUEX_VOICE_MODELS','/workspace/.voice-models'))
expected={'kokoro-v1.0.onnx':'beb0d1848dee9a49da392cc3df26958d46cfa35d321edf434f52949153f0df3a','voices-v1.0.bin':'bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d'}
for name,sha in expected.items():assert hashlib.sha256((models/name).read_bytes()).hexdigest()==sha
ort.disable_telemetry_events()
k=Kokoro(str(models/'kokoro-v1.0.onnx'),str(models/'voices-v1.0.bin'))
assert 'pf_dora' in k.voices
phrases=[
 ('hook','Você chegou a ver esse vídeo em Clevelândia?'),
 ('local','Era a divulgação da Danny’s Presentes.'),
 ('reach','Foram treze mil e sessenta e quatro pessoas alcançadas.'),
 ('impressions','E vinte mil, novecentas e oitenta e uma impressões.'),
 ('opportunity','Sua empresa também pode alcançar mais pessoas, com divulgação estratégica.'),
 ('cta','Vamos trabalhar a divulgação da sua empresa? Fale com a Evoquex.'),
]
out=ROOT/'public/voiceover';out.mkdir(exist_ok=True)
segments=[]
cursor=0
for index,(name,text) in enumerate(phrases):
 # Pronunciation alias only; canonical written business name stays unchanged.
 spoken=text.replace('Danny’s','Dânis')
 samples,sr=k.create(spoken,voice='pf_dora',speed=1.08,lang='pt-br')
 assert sr==24000 and np.all(np.isfinite(samples)) and len(samples)>sr
 path=out/f'{name}.wav';sf.write(path,samples,sr,subtype='PCM_16')
 duration=len(samples)/sr
 # Space for the visual transformation, reading and the final CTA.
 pause=.45 if name in ['reach','impressions'] else .3 if name!='cta' else 1.4
 minima={'hook':102,'local':96,'reach':132,'impressions':123,'opportunity':150,'cta':171}
 frames=max(minima[name],int(np.ceil((duration+pause)*30)))
 segments.append({'id':name,'text':text,'tts_input':spoken,'voice':'pf_dora','language':'pt-BR','sample_rate':sr,'file':'voiceover/'+path.name,'audio_seconds':round(duration,5),'from':cursor,'frames':frames})
 cursor+=frames
 print(name,round(duration,3),'s; scene',frames,'frames',flush=True)
timeline={'fps':30,'total_frames':cursor,'total_seconds':cursor/30,'segments':segments}
(ROOT/'src/narration-timing.json').write_text(json.dumps(timeline,indent=2,ensure_ascii=False)+'\n')
(ROOT/'audio-sources/voice/narration-script.json').write_text(json.dumps(timeline,indent=2,ensure_ascii=False)+'\n')
(ROOT/'audio-sources/voice/provenance.json').write_text(json.dumps({'engine':'kokoro-onnx','engine_version':importlib.metadata.version('kokoro-onnx'),'engine_license':'MIT','model':'Kokoro-82M v1.0','model_license':'Apache-2.0','voice':'pf_dora','language':'Brazilian Portuguese','model_distribution':'https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1','model_sha256':expected,'speed':1.08,'real_audio_generated':True,'subjective_listening_available':False},indent=2)+'\n')
print('Narration produced. Planned duration:',cursor/30,'seconds',flush=True)
