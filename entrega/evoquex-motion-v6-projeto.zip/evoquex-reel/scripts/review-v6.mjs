import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const frames = process.argv.slice(2).map(Number);
if (!frames.length) frames.push(0,1,12,30,45,70,84,110,150,174,205,239,250,280,310,350,380,405,450,490,520,560,590,610,645,680,715,750,785,815,850,895);
const output = path.resolve('review/v6-stills');
fs.mkdirSync(output,{recursive:true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.jsx')});
const browser = await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl,id:'EvoquexRebuilt',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
  for (const frame of frames) {
    await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,scale:.5,imageFormat:'png',output:path.join(output,`${String(frame).padStart(4,'0')}.png`)});
    console.log(`Reviewed frame ${frame}`);
  }
} finally { await browser.close({silent:true}); }
