"""Compare corresponding editorial moments of V4 and narrated V5."""
from pathlib import Path
import subprocess
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parent.parent
folder=root/'review/v5-comparison';folder.mkdir(exist_ok=True)
scenes=[('Hook',.8,.8),('Contexto',5.1,5.1),('Alcance',9.3,9.5),('Impressões',13.4,14.4),('Oportunidade',17.8,18.7),('CTA',24.5,24.2)]
canvas=Image.new('RGB',(6*270,2*510),'#DFE5EF');draw=ImageDraw.Draw(canvas)
for row,version in enumerate([4,5]):
    for column,(label,t4,t5) in enumerate(scenes):
        p=folder/f'v{version}-{column}.png'
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t4 if version==4 else t5),'-i',str(root/f'out/evoquex-motion-v{version}.mp4'),'-frames:v','1','-vf','scale=270:480',str(p)],check=True)
        canvas.paste(Image.open(p).convert('RGB'),(column*270,row*510))
        draw.text((column*270+9,row*510+487),f'V{version} · {label}',fill='#132138')
canvas.save(root/'review/v5-final-comparison.jpg',quality=94)
