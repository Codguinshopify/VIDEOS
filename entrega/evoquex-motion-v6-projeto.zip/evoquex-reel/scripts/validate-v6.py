"""Validate V6 actual media and sound, distinguishing preview from final voice completion."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,wave
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
video=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v6-previa.mp4')
timing=json.loads((ROOT/'src/motion-v6/timeline.json').read_text());events=json.loads((ROOT/'review/v6-audio-events.json').read_text())
probe=json.loads(subprocess.run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)],check=True,capture_output=True,text=True).stdout)
v=next(s for s in probe['streams'] if s['codec_type']=='video');sound=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
assert (v['width'],v['height'])==(1080,1920) and v['r_frame_rate']=='30/1'
assert v['color_space']=='bt709' and v['color_range']=='tv'
assert int(v['nb_read_frames'])==timing['total_frames']
assert abs(float(probe['format']['duration'])-timing['total_frames']/30)<.1
assert sound['codec_name']=='aac' and sound['channels']==2 and int(sound['sample_rate'])==48000
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
for name,info in json.loads((ROOT/'review/original-media-integrity.json').read_text()).items():
 assert hashlib.sha256((ROOT/'public/assets'/name).read_bytes()).hexdigest()==info['sha256']
p=subprocess.run(['ffmpeg','-v','info','-i',str(video),'-vn','-af','loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
levels=json.loads(re.findall(r'\{[\s\S]*?\}',p.stderr)[-1])
a=np.frombuffer(subprocess.run(['ffmpeg','-v','error','-i',str(video),'-vn','-ar','48000','-ac','2','-f','f32le','-'],capture_output=True,check=True).stdout,dtype='<f4').reshape(-1,2)
with wave.open(str(ROOT/'public'/timing['sound_file']),'rb') as w:b=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)/32768
n=min(len(a),len(b));corr=float(np.sum(a[:n]*b[:n])/np.sqrt(np.sum(a[:n]**2)*np.sum(b[:n]**2)))
assert corr>.97 and np.all(np.isfinite(a)) and np.count_nonzero(np.abs(a)>=1)==0
assert float(levels['input_tp'])<-1
narrated=timing['voice_status'].startswith('generated_elevenlabs')
assert events['real_new_narration_present']==narrated
assert not events['rejected_voice_used'] and events['original_ad_audio_gain']==0
report={'file':video.name,'frames':int(v['nb_read_frames']),'duration_seconds':float(probe['format']['duration']),'resolution':[1080,1920],'fps':30,'video_codec':'h264','pixel_format':'yuv420p','color_space':'bt709','color_range':'tv','audio_codec':'aac','audio_channels':2,'audio_sample_rate':48000,'integrated_lufs':float(levels['input_i']),'true_peak_dbtp':float(levels['input_tp']),'clipped_samples':0,'correlation_with_actual_mix_at_zero_delay':corr,'full_video_audio_decode_passed':True,'original_media_hashes_match':True,'new_narration_present':narrated,'rejected_voice_used':False,'subjective_audition_available':False,'final_approval_complete':False,'status':'narrated_pending_human_auditory_review' if narrated else 'visual_sound_preview_pending_ElevenLabs_credential_and_narration','size_bytes':video.stat().st_size,'sha256':hashlib.sha256(video.read_bytes()).hexdigest()}
(ROOT/'review/v6-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
