import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const frames = process.argv.slice(2).map(Number);
if (!frames.length) frames.push(0,1,6,12,24,45,75,101,102,145,197,210,250,310,330,360,420,453,480,560,602,630,680,730,770);
const output = path.resolve('review/v5-stills');
fs.mkdirSync(output,{recursive:true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.jsx')});
const browser = await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl,id:'EvoquexPremium',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
  for (const frame of frames) {
    await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,scale:.5,imageFormat:'png',output:path.join(output,`${String(frame).padStart(4,'0')}.png`)});
    console.log(`Reviewed frame ${frame}`);
  }
} finally { await browser.close({silent:true}); }
