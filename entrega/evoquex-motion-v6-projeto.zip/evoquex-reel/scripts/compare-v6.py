"""Compare corresponding moments of the prior design and the rebuilt direction."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess
ROOT=Path(__file__).resolve().parent.parent
cases=[('Hook',1.5,1.5),('Marca',5.1,6.9),('Alcance',9.5,11),('Impressões',14.4,15.4),('Métricas',18.5,18.2),('Convite',24.2,29.7)]
folder=ROOT/'review/v6-comparison';folder.mkdir(exist_ok=True)
sheet=Image.new('RGB',(270*6,510*2),'#DFE5EF');draw=ImageDraw.Draw(sheet)
for row,version in enumerate([5,6]):
 for col,(name,old,new) in enumerate(cases):
  file=ROOT/('out/evoquex-motion-v5.mp4' if version==5 else 'out/evoquex-motion-v6-previa.mp4')
  p=folder/f'{version}-{col}.png'
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str(old if version==5 else new),'-i',str(file),'-frames:v','1','-vf','scale=270:480',str(p)],check=True)
  sheet.paste(Image.open(p).convert('RGB'),(col*270,row*510));draw.text((col*270+6,row*510+488),f'V{version} · {name}',fill='#13233A')
sheet.save(ROOT/'review/v6-comparison.jpg',quality=94)
