"""Compare corresponding events, without globally speeding up the original."""
from pathlib import Path
from PIL import Image, ImageDraw
import subprocess
import sys

root=Path(__file__).resolve().parent.parent
new=root/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v4.mp4')
old=root/'out/evoquex-motion-v3.mp4'
tag='v4-draft' if 'draft' in new.name else 'v4-final'
folder=root/'review'/f'{tag}-comparison';folder.mkdir(exist_ok=True)
def frame(video,f,label):
    p=folder/f'{label}-{f:04d}.png'
    subprocess.run(['ffmpeg','-v','error','-y','-ss',str(f/30),'-i',str(video),'-frames:v','1','-vf','scale=216:384',str(p)],check=True)
    return Image.open(p).convert('RGB')
hook=Image.new('RGB',(216*4,414*2),'#DCE1E8');d=ImageDraw.Draw(hook)
for i,f in enumerate([0,3,12,30]):
    for row,(video,name) in enumerate([(old,'V3'),(new,'Refinada')]):
        x=i*216;y=row*414;hook.paste(frame(video,f,name),(x,y));d.text((x+7,y+390),f'{name} f{f} / {f/30:.2f}s',fill='black')
hook.save(root/'review'/f'{tag}-comparison-hook.jpg',quality=93)
sheet=Image.new('RGB',(216*8,414*3),'#DCE1E8');d=ImageDraw.Draw(sheet)
for row,(before,after) in enumerate([(198,192),(438,420),(624,588)]):
    for j,offset in enumerate([0,6,10,18]):
        for pair,(video,cut,name) in enumerate([(old,before,'V3'),(new,after,'Refinada')]):
            x=(2*j+pair)*216;y=row*414
            sheet.paste(frame(video,cut+offset,name),(x,y));d.text((x+7,y+390),f'{name} corte +{offset}f',fill='black')
sheet.save(root/'review'/f'{tag}-comparison-transitions.jpg',quality=93)
print('Compared frame-zero hook and three corresponding transition neighborhoods.')
