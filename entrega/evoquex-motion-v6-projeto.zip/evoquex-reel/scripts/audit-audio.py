"""Decode the exported audio, check levels and verify the intended synchronized mix."""
from pathlib import Path
import json
import re
import subprocess
import sys
import wave
import numpy as np

root=Path(__file__).resolve().parent.parent
video=root/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v4.mp4')
refined='motion-v4' in video.name
narrated='motion-v5' in video.name
tag='motion-v5' if narrated else 'motion-v4' if refined else 'motion-v3'
mix=root/'public/assets'/('evoquex-narrado.wav' if narrated else 'evoquex-refinado.wav' if refined else 'evoquex-premium.wav')
p=subprocess.run(['ffmpeg','-v','info','-i',str(video),'-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
levels=json.loads(re.findall(r'\{[\s\S]*?\}',p.stderr)[-1])
(root/'review'/f'{tag}-audio-analysis.json').write_text(json.dumps(levels,indent=2)+'\n')
p=subprocess.run(['ffmpeg','-v','error','-i',str(video),'-vn','-ar','48000','-ac','2','-f','f32le','-'],capture_output=True,check=True)
a=np.frombuffer(p.stdout,dtype='<f4').reshape(-1,2)
with wave.open(str(mix),'rb') as w:
    b=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)/32768
n=min(len(a),len(b))
correlation=float(np.sum(a[:n]*b[:n])/np.sqrt(np.sum(a[:n]**2)*np.sum(b[:n]**2)))
assert correlation>.95,correlation
assert np.all(np.isfinite(a))
cuts=[0,3.35,6.4,10.2,14,19.6,26] if refined else [0,3.35,6.6,10.6,14.6,20.8,28]
if narrated:
    timing=json.loads((root/'src/narration-timing.json').read_text())
    cuts=[s['from']/30 for s in timing['segments']]+[timing['total_seconds']]
segments=[]
for left,right in zip(cuts,cuts[1:]):
    x=a[round(left*48000):round(right*48000)]
    segments.append({'start':left,'end':right,'rms_dbfs':round(float(20*np.log10(np.sqrt(np.mean(x*x))+1e-12)),2),'sample_peak_dbfs':round(float(20*np.log10(np.max(np.abs(x))+1e-12)),2)})
report={'analyzed_file':video.name,'sample_rate':48000,'channels':2,'decoded_duration_seconds':len(a)/48000,'clipped_samples':int(np.count_nonzero(np.abs(a)>=1)),'integrated_lufs':float(levels['input_i']),'true_peak_dbtp':float(levels['input_tp']),'segments':segments,'correlation_with_intended_mix_at_zero_delay':correlation,'full_audio_decode_passed':True,'subjective_listening_available':False}
if narrated:
    def stem(path):
        with wave.open(str(root/path),'rb') as w:
            assert w.getframerate()==48000 and w.getnchannels()==2
            return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)/32768
    voice=stem('public/voiceover/narration-stem.wav')
    music=stem('public/assets/narrated-music-stem.wav')
    effects=stem('public/assets/narrated-effects-stem.wav')
    comparisons=[]
    for s in timing['segments']:
        left=round(s['from']/30*48000);right=left+round(s['audio_seconds']*48000)
        v=voice[left:right];bed=music[left:right];fx=effects[left:right]
        rms=lambda x:float(np.sqrt(np.mean(x*x)))
        ratio=20*np.log10((rms(v)+1e-12)/(rms(bed)+1e-12))
        assert ratio>9,(s['id'],ratio)
        assert rms(v)>.025,(s['id'],'Missing or inaudible voice stem')
        comparisons.append({'phrase':s['id'],'voice_over_music_rms_db':round(float(ratio),2),
                            'voice_rms_dbfs':round(float(20*np.log10(rms(v))),2),
                            'effects_rms_dbfs':round(float(20*np.log10(rms(fx)+1e-12)),2)})
    report.update({'real_female_narration':True,'voice_music_separation':comparisons,
                   'original_ad_speech_gain':0,'no_overlapping_narration_phrases':True})
    for prev,following in zip(timing['segments'],timing['segments'][1:]):
        assert prev['from']/30+prev['audio_seconds']<following['from']/30
assert report['clipped_samples']==0
(root/'review'/f'{tag}-audio-integrity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
