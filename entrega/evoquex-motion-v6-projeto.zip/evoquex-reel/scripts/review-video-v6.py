"""Inspect the full V6 picture, hook and all macro/internal transitions."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,sys
ROOT=Path(__file__).resolve().parent.parent
video=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'out/evoquex-motion-v6-previa.mp4')
timing=json.loads((ROOT/'src/motion-v6/timeline.json').read_text())
tag='v6-draft' if 'draft' in video.name else 'v6-preview' if 'previa' in video.name else 'v6-final'
folder=ROOT/'review'/tag;folder.mkdir(exist_ok=True)
def extract(frame,prefix):
 path=folder/f'{prefix}-{frame:04d}.png'
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(frame/30),'-i',str(video),'-frames:v','1','-vf','scale=216:384',str(path)],check=True)
 return path
subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-vf','fps=4,scale=216:384',str(folder/'sample-%03d.png')],check=True)
def sheets(items,name,columns=7,per_page=28):
 for start in range(0,len(items),per_page):
  chunk=items[start:start+per_page];canvas=Image.new('RGB',(216*columns,411*((len(chunk)+columns-1)//columns)),'#DDE4ED');draw=ImageDraw.Draw(canvas)
  for index,(p,label) in enumerate(chunk):
   x=index%columns*216;y=index//columns*411;canvas.paste(Image.open(p).convert('RGB'),(x,y));draw.text((x+6,y+391),label,fill='#17233A')
  canvas.save(ROOT/'review'/f'{tag}-{name}-{start//per_page+1:02d}.jpg',quality=93)
frames=sorted(folder.glob('sample-*.png'));sheets([(p,f'{(i+.5)/4:.3f}s') for i,p in enumerate(frames)],'full')
hook=[(extract(f,'hook'),f'Hook f{f}') for f in list(range(31))+[45,60,75]];sheets(hook,'hook')
trans=[]
for c in timing['chapters'][1:]:
 for delta in [-3,0,2,4,6,8,12]:
  frame=c['from']+delta;trans.append((extract(frame,'cut'),f'{c["id"]} / f{frame}'))
sheets(trans,'cuts',per_page=28)
events=json.loads((ROOT/'review/v6-audio-events.json').read_text())['events']
internal=[]
for e in events:
 if e['type']=='sweep':
  f=round(e['time']*30)
  for delta in [-3,6]:
   frame=max(0,min(timing['total_frames']-1,f+delta));internal.append((extract(frame,'state'),f'{e["chapter"]} / f{frame}'))
sheets(internal,'states')
for index,offset,name in [(0,44,'hook'),(2,35,'brand'),(3,88,'reach'),(4,92,'impressions'),(5,32,'meaning'),(8,116,'cta')]:
 c=timing['chapters'][index];frame=c['from']+offset
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(frame/30),'-i',str(video),'-frames:v','1','-vf','scale=360:640',str(ROOT/'review'/f'{tag}-phone-{name}.png')],check=True)
report={'video':video.name,'whole_duration_samples':len(frames),'hook_frames':len(hook),'macro_transition_frames':len(trans),'internal_transition_frames':len(internal),'phone_checks':6,'subjective_audio_playback_available':False}
(ROOT/'review'/f'{tag}-visual-sampling.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
