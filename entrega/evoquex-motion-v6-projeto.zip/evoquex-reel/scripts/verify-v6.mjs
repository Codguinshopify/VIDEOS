import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'..');
const timing=JSON.parse(fs.readFileSync(path.join(root,'src/motion-v6/timeline.json'),'utf8'));
const generated=timing.voice_status.startsWith('generated_elevenlabs');
if(process.argv.includes('--require-voice')&&!generated)throw new Error('Locução natural ainda pendente. Exporte apenas prévia de direção; a voz rejeitada não é fallback.');
const files=['assets/DANYS.mp4','assets/clevelandia.jpg','assets/resultados.jpg',timing.sound_file];
if(generated)files.push(...timing.chapters.map(c=>c.voice_file));
for(const file of files){const p=path.join(root,'public',file);if(!fs.existsSync(p))throw new Error('Mídia real ausente: '+file);const result=spawnSync('ffprobe',['-v','error','-show_format','-of','json',p],{encoding:'utf8'});if(result.status!==0)throw new Error('Mídia inválida: '+file);}
console.log(`V6: materiais e mix reais válidos; locução ElevenLabs presente: ${generated}.`);
