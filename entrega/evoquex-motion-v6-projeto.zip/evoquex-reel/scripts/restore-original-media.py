"""Recover missing original uploads from verified retained delivery packages.
Never overwrite an existing file. Only exact, hash-checked asset names are read.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
expected=json.loads((ROOT/'review/original-media-integrity.json').read_text())
archives=sorted((ROOT/'out').glob('*-projeto.zip'),reverse=True)+sorted((ROOT.parent/'entrega').glob('*-projeto.zip'),reverse=True)
for name,record in expected.items():
 target=ROOT/'public/assets'/name
 if target.exists():
  assert hashlib.sha256(target.read_bytes()).hexdigest()==record['sha256'],f'Existing original changed: {name}. Inspect; do not overwrite.'
  continue
 restored=False
 for package in archives:
  with ZipFile(package) as archive:
   key='evoquex-reel/public/assets/'+name
   if key not in archive.namelist():continue
   content=archive.read(key)
   assert hashlib.sha256(content).hexdigest()==record['sha256'],f'Archive media differs: {package.name}/{name}'
   target.parent.mkdir(exist_ok=True);target.write_bytes(content);restored=True;break
 if not restored:raise SystemExit(f'Original missing and no verified retained package found: {name}')
 print('Restored exact original:',name)
print('Original media hashes verified.')
