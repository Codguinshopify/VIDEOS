import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = {video: 'DANYS.mp4', city: 'clevelandia.jpg', results: 'resultados.jpg', sound: 'evoquex-original.wav'};
if (process.argv.includes('--v2')) files.sound = 'evoquex-motion.wav';
if (process.argv.includes('--v3')) files.sound = 'evoquex-premium.wav';
if (process.argv.includes('--v4')) files.sound = 'evoquex-refinado.wav';
if (process.argv.includes('--v5')) {
  files.sound = 'evoquex-narrado.wav';
  const timing = JSON.parse(fs.readFileSync(path.join(root,'src/narration-timing.json'),'utf8'));
  for (const seg of timing.segments) {
    const file=path.join(root,'public',seg.file);
    if (!fs.existsSync(file)) throw new Error(`Narração real ausente: ${seg.file}`);
    const probe=spawnSync('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file],{encoding:'utf8'});
    if (probe.status!==0) throw new Error(`WAV inválido: ${seg.file}`);
    const info=JSON.parse(probe.stdout), audio=info.streams.find(s=>s.codec_type==='audio');
    if (!audio || audio.codec_name!=='pcm_s16le' || Math.abs(Number(info.format.duration)-seg.audio_seconds)>.02)
      throw new Error(`Duração ou formato divergente da narração: ${seg.file}`);
  }
}
const status = {};
const metadata = {};
for (const [key, name] of Object.entries(files)) {
  const file = path.join(root, 'public/assets', name);
  status[key] = fs.existsSync(file) && fs.statSync(file).size > 0;
  if (!status[key]) continue;
  const probe = spawnSync('ffprobe', ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', file], {encoding: 'utf8'});
  if (probe.status !== 0) throw new Error(`Arquivo de mídia inválido: ${name}\n${probe.stderr}`);
  metadata[key] = JSON.parse(probe.stdout);
}
fs.writeFileSync(path.join(root, 'src/assets.json'), JSON.stringify(status, null, 2) + '\n');
if (status.video) {
  const stream = metadata.video.streams.find((s) => s.codec_type === 'video');
  if (!stream || Number(metadata.video.format.duration) < 5) throw new Error('É necessário um vídeo original válido com pelo menos 5 segundos para os cortes atuais.');
}
const missing = Object.entries(files).filter(([key]) => !status[key]).map(([, name]) => name);
if (missing.length) {
  console.error('Materiais ainda indisponíveis: ' + missing.join(', '));
  if (!process.argv.includes('--allow-missing')) {
    console.error('Exportação final bloqueada: a peça deve usar os materiais reais, sem substituições.');
    process.exitCode = 1;
  }
} else {
  console.log('Todos os materiais foram encontrados e validados.');
  fs.writeFileSync(path.join(root, 'review/media-metadata.json'), JSON.stringify(metadata, null, 2) + '\n');
}
