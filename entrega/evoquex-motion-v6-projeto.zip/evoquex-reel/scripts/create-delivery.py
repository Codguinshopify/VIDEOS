"""Package the Remotion source and original media without dependency/build caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys

root = Path(__file__).resolve().parent.parent
v2 = '--v2' in sys.argv
v3 = '--v3' in sys.argv
v4 = '--v4' in sys.argv
v5 = '--v5' in sys.argv
v6 = '--v6' in sys.argv
output = root / ('out/evoquex-motion-v6-projeto.zip' if v6 else 'out/evoquex-motion-v5-projeto.zip' if v5 else 'out/evoquex-motion-v4-projeto.zip' if v4 else 'out/evoquex-motion-v3-projeto.zip' if v3 else 'out/evoquex-motion-v2-projeto.zip' if v2 else 'out/evoquex-source.zip')
files = [root / name for name in ['package.json', 'package-lock.json', 'README.md', 'briefing.md', '.gitignore']]
if v2 or v3 or v4 or v5 or v6:
    files.extend(root / name for name in ['briefing-reedicao.md', 'referencia-motion.md'])
if v3 or v4 or v5 or v6:
    files.extend(root / name for name in ['ordem-producao-v3.md', 'analise-producao-v3.md', 'README-v2.md'])
    files.extend(path for path in (root / 'audio-sources').rglob('*') if path.is_file())
if v4 or v5 or v6:
    files.extend(root / name for name in ['revisao-refinamento-v4.md','README-v3.md'])
if v5:
    files.extend(root / name for name in ['analise-referencia-park.md','README-v4.md'])
if v6:
    files.extend(root/name for name in ['direcao-criativa-v6.md','README-v5.md','analise-referencia-park.md'])
for folder in ['src', 'public', 'scripts']:
    files.extend(path for path in (root / folder).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
review_files = ['motion-v2-validation.json', 'original-media-integrity.json', 'media-metadata.json', 'motion-v2-audio-analysis.json', 'motion-v2-final-sheet-01.jpg', 'motion-v2-final-sheet-02.jpg', 'motion-v2-phone-metric.png', 'motion-v2-phone-cta.png'] if v2 else ['final-validation.json', 'original-media-integrity.json', 'media-metadata.json', 'audio-analysis.json', 'final-video-contact-sheet.jpg', 'final-phone-proof.png', 'final-phone-cta.png']
if v3:
    review_files = ['motion-v3-validation.json','original-media-integrity.json','media-metadata.json','motion-v3-audio-analysis.json','motion-v3-audio-integrity.json','motion-v3-design-resources.json','motion-v3-review.md','v3-final-full-01.jpg','v3-final-full-02.jpg','v3-final-transitions-01.jpg','v3-final-transitions-02.jpg','v3-final-phone-reach.png','v3-final-phone-impressions.png','v3-final-phone-opportunity.png','v3-final-phone-cta.png']
if v4:
    review_files = ['motion-v4-validation.json','original-media-integrity.json','media-metadata.json','motion-v4-audio-analysis.json','motion-v4-audio-integrity.json','motion-v4-review.md','v4-final-full-01.jpg','v4-final-full-02.jpg','v4-final-transitions-01.jpg','v4-final-transitions-02.jpg','v4-final-hook-01.jpg','v4-final-phone-reach.png','v4-final-phone-impressions.png','v4-final-phone-opportunity.png','v4-final-phone-cta.png','v4-final-comparison-hook.jpg','v4-final-comparison-transitions.jpg']
if v5:
    review_files=['original-media-integrity.json','media-metadata.json','motion-v5-validation.json','motion-v5-audio-analysis.json','motion-v5-audio-integrity.json','motion-v5-review.md','narration-asr.json','v5-final-narration-asr.json','narration-mix-automation.json','source-reproduction-v5.json','v5-final-full-01.jpg','v5-final-full-02.jpg','v5-final-transitions-01.jpg','v5-final-transitions-02.jpg','v5-final-hook-01.jpg','v5-final-phone-reach.png','v5-final-phone-impressions.png','v5-final-phone-opportunity.png','v5-final-phone-cta.png','v5-final-comparison.jpg']
if v6:
    review_files=['original-media-integrity.json','media-metadata.json','v6-validation.json','v6-review.md','v6-audio-events.json','v6-preview-visual-sampling.json','v6-source-reproduction.json','v6-comparison.jpg']
    review_files += [p.name for p in (root/'review').glob('v6-preview-*.jpg')]
    review_files += [p.name for p in (root/'review').glob('v6-preview-phone-*.png')]
for name in review_files:
    path = root / 'review' / name
    if path.exists():
        files.append(path)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        archive.write(path, 'evoquex-reel/' + path.relative_to(root).as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None
    for name in ['DANYS.mp4', 'clevelandia.jpg', 'resultados.jpg']:
        assert archive.read('evoquex-reel/public/assets/' + name) == (root / 'public/assets' / name).read_bytes()
print(f'Source package verified: {output.name} — {output.stat().st_size} bytes')
