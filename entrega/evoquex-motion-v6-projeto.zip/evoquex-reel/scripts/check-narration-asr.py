"""Independent multilingual Whisper recognition of real generated/mixed audio."""
from pathlib import Path
import json
import subprocess
import sys
import numpy as np
import sherpa_onnx

root=Path(__file__).resolve().parent.parent
model=Path('/workspace/.voice-models/sherpa-onnx-whisper-base')
recognizer=sherpa_onnx.OfflineRecognizer.from_whisper(
    encoder=str(model/'base-encoder.onnx'),decoder=str(model/'base-decoder.onnx'),
    tokens=str(model/'base-tokens.txt'),language='pt',task='transcribe',num_threads=2)
timeline=json.loads((root/'src/narration-timing.json').read_text())
mixed=sys.argv[1] if len(sys.argv)>1 else None
reports=[]
for segment in timeline['segments']:
    source=root/mixed if mixed else root/'public'/segment['file']
    command=['ffmpeg','-v','error']
    if mixed: command+=['-ss',str(segment['from']/30)]
    command+=['-i',str(source)]
    if mixed: command+=['-t',str(segment['audio_seconds']+.1)]
    command+=['-vn','-ar','16000','-ac','1','-f','f32le','-']
    samples=np.frombuffer(subprocess.run(command,check=True,capture_output=True).stdout,dtype='<f4')
    stream=recognizer.create_stream();stream.accept_waveform(16000,samples)
    recognizer.decode_stream(stream)
    row={'id':segment['id'],'source':source.name,'expected':segment['text'],'recognized':stream.result.text}
    reports.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
report={'method':'Independent multilingual Whisper base / sherpa-onnx 1.13.8; no prompt or expected text passed to recognizer',
        'subjective_listening_available':False,'segments':reports}
(root/'review'/('v5-final-narration-asr.json' if mixed else 'narration-asr.json')).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
