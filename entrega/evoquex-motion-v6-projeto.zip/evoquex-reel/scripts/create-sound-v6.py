"""Original V6 electro score and synced effects; licensed GeneralUser GS instruments."""
from pathlib import Path
import ctypes as ct,ctypes.util,hashlib,json,os,shutil,subprocess,urllib.request,wave
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
timeline=json.loads((ROOT/'src/motion-v6/timeline.json').read_text())
RATE=48000;LENGTH=timeline['total_frames']/30;N=round(LENGTH*RATE)
PIN = '684543d5e5efaef08d02be50dcda8d552478fa60'
SHA = '9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe'
CACHE = Path(os.environ.get('EVOQUEX_AUDIO_CACHE', '/workspace/.cache/evoquex-audio'))
CACHE.mkdir(parents=True, exist_ok=True)
bank = CACHE / 'GeneralUser-GS.sf2'
if not bank.exists():
    local = Path('/tmp/evoquex-generaluser-gs/GeneralUser-GS.sf2')
    if local.exists():
        shutil.copyfile(local, bank)
    else:
        url = f'https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/{PIN}/GeneralUser-GS.sf2'
        with urllib.request.urlopen(url, timeout=90) as response:
            bank.write_bytes(response.read())
assert hashlib.sha256(bank.read_bytes()).hexdigest() == SHA, 'SoundFont integrity check failed'

lib = ct.CDLL(ctypes.util.find_library('fluidsynth'))
def api(name, ret, args):
    fn = getattr(lib, name); fn.restype = ret; fn.argtypes = args; return fn
ptr, integer, number, string = ct.c_void_p, ct.c_int, ct.c_double, ct.c_char_p
settings = api('new_fluid_settings', ptr, [])()
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.sample-rate', RATE)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.gain', .65)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.reverb.room-size', .34)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.reverb.level', .12)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.chorus.level', .18)
synth = api('new_fluid_synth', ptr, [ptr])(settings)
assert api('fluid_synth_sfload', integer, [ptr, string, integer])(synth, str(bank).encode(), 1) >= 0
program = api('fluid_synth_program_change', integer, [ptr, integer, integer])
control = api('fluid_synth_cc', integer, [ptr, integer, integer, integer])
on = api('fluid_synth_noteon', integer, [ptr, integer, integer, integer])
off = api('fluid_synth_noteoff', integer, [ptr, integer, integer])
write = api('fluid_synth_write_float', integer, [ptr, integer, ptr, integer, integer, ptr, integer, integer])
program(synth, 0, 4)  # electric piano
program(synth, 1, 33) # fingered bass
program(synth, 2, 89) # quiet warm pad, only sustained transitions
for channel, volume, pan in [(0, 92, 52), (1, 91, 64), (2, 29, 78), (9, 77, 64)]:
    control(synth, channel, 7, volume); control(synth, channel, 10, pan)
control(synth, 1, 91, 0); control(synth, 9, 91, 8)

program(synth,0,81);program(synth,1,38);program(synth,2,90)
for ch,vol,pan in [(0,66,48),(1,82,64),(2,24,76),(9,74,64)]:
 control(synth,ch,7,vol);control(synth,ch,10,pan)
control(synth,0,91,12);control(synth,0,93,3)
events=[]
def note(t,ch,pitch,velocity,duration):
 if 0<=t<LENGTH-.6:
  events.extend([(round(t*RATE),1,ch,pitch,velocity),(round((t+duration)*RATE),0,ch,pitch,0)])
beat=60/128
chords=[(38,[62,65,69]),(34,[62,65,69]),(41,[60,65,69]),(36,[60,64,67])]
for bar in range(int(LENGTH/(beat*4))+1):
 t=bar*beat*4;base,chord=chords[bar%4]
 for step,pitch in [(0,chord[0]+12),(.75,chord[2]+12),(1.5,chord[1]+12),(2.75,chord[2]+12),(3.5,chord[1]+12)]:
  note(t+step*beat,0,pitch,39 if step==0 else 29,.11)
 for step in [0,1.5,2.5,3.25]:note(t+step*beat,1,base if step<2 else base+12,59 if step==0 else 42,.17)
 if bar>=1:
  for step in [0,2,3.5]:note(t+step*beat,9,36,67 if step!=3.5 else 44,.08)
  for step in [1,3]:note(t+step*beat,9,39,54,.06)
  for step in range(8):note(t+step*beat/2,9,42,26 if step%2==0 else 15,.035)
 if bar%4==2:
  for pitch in chord:note(t,2,pitch+12,22,beat*2.6)
events.sort();music=np.zeros((N,2),np.float32);cursor=0
def render_to(end):
 global cursor
 end=min(end,N);n=end-cursor
 if n>0:
  l=np.zeros(n,np.float32);r=np.zeros(n,np.float32)
  assert write(synth,n,l.ctypes.data,0,1,r.ctypes.data,0,1)==0
  music[cursor:end,0]=l;music[cursor:end,1]=r;cursor=end
for sample,state,ch,pitch,vel in events:
 if sample>=N:break
 render_to(sample)
 if state:on(synth,ch,pitch,vel)
 else:off(synth,ch,pitch)
render_to(N)
api('delete_fluid_synth',None,[ptr])(synth);api('delete_fluid_settings',None,[ptr])(settings)
rng=np.random.default_rng(60014);fx=np.zeros((N,2),np.float64)
def add(t,s,gain=.1,pan=0):
 start=max(0,round(t*RATE));n=min(len(s),N-start)
 if n>0:
  fx[start:start+n,0]+=s[:n]*gain*np.sqrt((1-pan)/2)
  fx[start:start+n,1]+=s[:n]*gain*np.sqrt((1+pan)/2)
def sweep(t,g=.19,pan=0,duration=.22):
 x=np.arange(round(duration*RATE))/RATE;n=rng.standard_normal(len(x))
 low=np.convolve(n,np.ones(17)/17,'same');hi=np.convolve(n,np.ones(3)/3,'same')-low
 s=(low*.7+hi*.23)*np.sin(np.pi*x/duration)**1.7
 add(t-duration*.65,s,g,pan)
def hit(t,g=.13):
 x=np.arange(round(.3*RATE))/RATE
 s=np.sin(2*np.pi*(45*x+1.2*(1-np.exp(-x*26))))*np.exp(-x*16)*(1-np.exp(-x*1000))
 add(t,s,g)
def tick(t,g=.045):
 x=np.arange(round(.045*RATE))/RATE
 s=(np.sin(2*np.pi*1350*x)+rng.standard_normal(len(x))*.3)*np.exp(-x*130)
 add(t,s,g)
visual_events=[(0,0,'hit'),(0,33,'sweep'),(0,69,'sweep'),(1,0,'hit'),(1,22,'tick'),(1,75,'sweep'),(2,7,'tick'),(2,49,'sweep'),(3,25,'sweep'),(3,44,'hit'),(3,64,'tick'),(3,117,'sweep'),(4,23,'sweep'),(4,49,'hit'),(4,69,'tick'),(4,118,'sweep'),(5,7,'tick'),(5,58,'sweep'),(5,104,'sweep'),(6,15,'tick'),(6,50,'sweep'),(7,28,'sweep'),(7,66,'sweep'),(8,0,'hit'),(8,49,'sweep'),(8,61,'tick')]
base_lengths=[84,90,66,132,132,120,66,84,156]
log=[]
for index,frame,kind in visual_events:
 chapter=timeline['chapters'][index]
 t=(chapter['from']+frame*(chapter['frames']-1)/(base_lengths[index]-1))/30
 if kind=='sweep':sweep(t,pan=-.2 if index%2 else .2)
 elif kind=='hit':hit(t)
 else:tick(t)
 log.append({'time':round(t,4),'type':kind,'chapter':chapter['id'],'authored_frame':frame})
def wav(path,data):
 assert np.max(np.abs(data))<1,'PCM would clip'
 with wave.open(str(path),'wb') as w:
  w.setnchannels(2);w.setsampwidth(2);w.setframerate(RATE);w.writeframes((data*32767).astype('<i2').tobytes())
folder=ROOT/'public/audio-v6';folder.mkdir(exist_ok=True)
work=ROOT/'review/audio-v6';work.mkdir(exist_ok=True)
raw=work/'music-raw.wav';norm=work/'music-normalized.wav';wav(raw,music)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af','highpass=f=48,loudnorm=I=-22:TP=-5:LRA=6','-ar',str(RATE),'-c:a','pcm_s16le',str(norm)],check=True)
with wave.open(str(norm),'rb') as w:music=np.frombuffer(w.readframes(N),dtype='<i2').reshape(-1,2)/32768
voice=np.zeros((N,2),np.float64);times=np.arange(N)/RATE;duck=np.ones(N)*.68;voice_present=timeline['voice_status'].startswith('generated_elevenlabs')
if voice_present:
 for c in timeline['chapters']:
  source=ROOT/'public'/c['voice_file'];assert source.is_file()
  target=work/(c['id']+'-normalized.wav')
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-af','highpass=f=80,loudnorm=I=-18:TP=-3:LRA=6','-ar',str(RATE),'-ac','2','-c:a','pcm_s16le',str(target)],check=True)
  with wave.open(str(target),'rb') as w:v=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)/32768
  start=round(c['from']/30*RATE);n=min(len(v),N-start);voice[start:start+n]+=v[:n]
  begin=start/RATE;end=begin+n/RATE
  duck=np.minimum(duck,np.interp(times,[max(0,begin-.1),begin+.025,end,end+.22],[.68,.18,.18,.68]))
  target.unlink()
music*=duck[:,None]
combined=music+fx+voice
peak=float(np.max(np.abs(combined)));master_gain=min(1,.94/(peak+1e-12));combined*=master_gain
combined*=np.minimum(np.clip(times/.012,0,1),np.clip((LENGTH-times)/.65,0,1))[:,None]
wav(folder/'music-stem.wav',music);wav(folder/'effects-stem.wav',fx)
if voice_present:wav(folder/'voice-stem.wav',voice)
premaster=work/'premaster.wav';wav(premaster,combined)
output=folder/'direcao-mix.wav'
p=subprocess.run(['ffmpeg','-v','info','-y','-i',str(premaster),'-af','loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json','-ar',str(RATE),'-c:a','pcm_s16le',str(output)],check=True,capture_output=True,text=True)
(work/'mastering.log').write_text(p.stderr)
(ROOT/'review/v6-audio-events.json').write_text(json.dumps({'duration_seconds':LENGTH,'bpm':128,'original_ad_audio_gain':0,'rejected_voice_used':False,'real_new_narration_present':voice_present,'music_gain_during_speech':.18,'music_gain_in_gaps':.68,'premaster_gain':master_gain,'events':log},indent=2)+'\n')
for path in [raw,norm,premaster]:path.unlink()
print('V6 actual mix:',round(LENGTH,2),'s; natural narration present:',voice_present)
