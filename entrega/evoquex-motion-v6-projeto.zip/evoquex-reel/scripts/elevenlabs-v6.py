"""Generate actual, commercially authorized ElevenLabs narration; never a placeholder.

Requires ELEVENLABS_API_KEY through secure environment settings and a native
Brazilian female voice from the account/library. No secret is saved or printed.
"""
from pathlib import Path
import urllib.request,urllib.error,json,os,subprocess,math,hashlib,sys
ROOT=Path(__file__).resolve().parent.parent
key=os.environ.get('ELEVENLABS_API_KEY')
if not key:raise SystemExit('ELEVENLABS_API_KEY is missing. Add it through secure environment settings; do not paste it in chat.')
def request(route,body=None):
 req=urllib.request.Request('https://api.elevenlabs.io'+route,data=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers={'xi-api-key':key,'Content-Type':'application/json','Accept':'application/json' if body is None else 'audio/mpeg'})
 try:
  with urllib.request.urlopen(req,timeout=120) as r:return r.read()
 except urllib.error.HTTPError as e:raise SystemExit(f'ElevenLabs HTTP {e.code}; inspect account permissions, plan and endpoint access.')
 except urllib.error.URLError as e:raise SystemExit(f'ElevenLabs connection unavailable: {e.reason}')
voices=json.loads(request('/v1/voices'))['voices']
native=[]
for v in voices:
 label=' '.join(str(x) for x in v.get('labels',{}).values()).lower()
 if 'female' in label and any(x in label for x in ['brazil','brasil','pt-br']):native.append(v)
selected=os.environ.get('EVOQUEX_ELEVENLABS_VOICE_ID')
if selected:
 voice=next((v for v in voices if v['voice_id']==selected),None)
 if voice is None:raise SystemExit('Selected voice is not available in this ElevenLabs account.')
elif native:voice=native[0]
else:raise SystemExit('No native Brazilian female voice found in the account. Add a licensed voice from the ElevenLabs library and set EVOQUEX_ELEVENLABS_VOICE_ID.')
if '--check' in sys.argv:
 print('Authenticated ElevenLabs voice available:',voice['name']);sys.exit(0)
segments=[
 ('hook','Esse anúncio saiu da tela…',84),('city','e chegou a Clevelândia.',90),
 ('brand','A campanha da Danny’s Presentes',66),('reach','alcançou treze mil e sessenta e quatro pessoas.',132),
 ('impressions','E gerou vinte mil, novecentas e oitenta e uma impressões.',132),
 ('meaning','Pessoas alcançadas e exibições do anúncio: medidas diferentes.',120),
 ('proof','Resultados documentados.',66),('bridge','Um projeto da Evoquex.',84),('cta','Quer fazer algo assim para a sua empresa? Conversa com a gente.',156)]
folder=ROOT/'public/audio-v6/voice';folder.mkdir(exist_ok=True)
timing=json.loads((ROOT/'src/motion-v6/timeline.json').read_text());chapters=[];cursor=0
for index,(name,text,minimum) in enumerate(segments):
 path=folder/f'{name}.mp3'
 body={'text':text,'model_id':'eleven_multilingual_v2','language_code':'pt','voice_settings':{'stability':.4,'similarity_boost':.78,'style':.25,'use_speaker_boost':True}}
 if index:body['previous_text']=' '.join(s[1] for s in segments[:index])
 if index+1<len(segments):body['next_text']=' '.join(s[1] for s in segments[index+1:])
 data=request('/v1/text-to-speech/'+voice['voice_id']+'?output_format=mp3_44100_128',body)
 path.write_bytes(data)
 probe=json.loads(subprocess.run(['ffprobe','-v','error','-show_format','-of','json',str(path)],capture_output=True,text=True,check=True).stdout)
 duration=float(probe['format']['duration']);assert duration>0.5
 frames=max(minimum,math.ceil((duration+.15)*30))
 chapters.append({'id':name,'from':cursor,'frames':frames,'text':text,'voice_file':'audio-v6/voice/'+path.name,'audio_seconds':duration,'sha256':hashlib.sha256(data).hexdigest()});cursor+=frames
 print('Actual speech generated:',name,round(duration,2),'s',flush=True)
timing.update({'total_frames':cursor,'voice_status':'generated_elevenlabs_pending_auditory_review','voice_provider':'ElevenLabs','voice_name':voice['name'],'voice_id':voice['voice_id'],'model_id':'eleven_multilingual_v2','chapters':chapters})
(ROOT/'src/motion-v6/timeline.json').write_text(json.dumps(timing,indent=2,ensure_ascii=False)+'\n')
(ROOT/'audio-sources/elevenlabs-v6.json').write_text(json.dumps({'provider':'ElevenLabs','commercial_plan_declared_by_user':True,'real_audio_generated':True,'voice_name':voice['name'],'model_id':'eleven_multilingual_v2','subjective_audition_by_agent':False},indent=2)+'\n')
print('Voice generated; rebuild V6 mix and re-time/render using the measured timeline.')
