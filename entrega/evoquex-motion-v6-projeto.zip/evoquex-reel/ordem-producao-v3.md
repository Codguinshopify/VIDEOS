> Atualização de grafia: o nome correto é **Danny’s Presentes**. O texto recebido abaixo é preservado como histórico; o nome corrigido prevalece no projeto.

# ORDEM DE PRODUÇÃO — MOTION DESIGN PROFISSIONAL PARA EVOQUEX

## OBJETIVO

Refaça a edição do Reel da Evoquex usando o vídeo de referência anexado como **padrão obrigatório de qualidade visual, complexidade de motion design, composição, ritmo, animação e sound design**.

A edição atual está boa como montagem de vídeo, mas ainda não atingiu o nível de motion design profissional que estou buscando.

Não quero apenas melhorar a edição existente. Quero elevar significativamente a execução visual, estudando a referência e aplicando técnicas equivalentes ao projeto.

**O resultado precisa parecer uma peça publicitária produzida por um motion designer profissional, não um vídeo comum com textos animados, transições prontas e imagens sobrepostas.**

Não comece imediatamente a renderizar. Primeiro, faça uma análise técnica do projeto atual, da referência visual e dos recursos disponíveis. Depois, execute a nova versão.

---

## 1. PRIMEIRA ETAPA OBRIGATÓRIA: ANALISAR E REPRODUZIR O NÍVEL DA REFERÊNCIA

Assista ao vídeo de referência completo, mais de uma vez se necessário.

Não se limite a identificar o tema ou a estética. Analise como a peça foi construída visualmente.

Examine especificamente:

- A quantidade e a complexidade dos elementos animados em cada cena.
- A relação entre tipografia, imagens, formas geométricas e objetos gráficos.
- Como os elementos entram, saem, se transformam e se conectam.
- O uso de camadas, máscaras, recortes, profundidade e parallax.
- As técnicas de tracking, composição e integração dos elementos com as imagens.
- A movimentação de câmera, os zooms e as mudanças de escala.
- As curvas de aceleração e desaceleração das animações.
- A sincronização entre cortes, motion graphics, música e efeitos sonoros.
- O tratamento de cor, contraste, iluminação, textura e acabamento.
- A densidade visual: quantos elementos são usados, como são distribuídos e quando aparecem.
- A forma como a referência mantém o interesse visual durante todo o vídeo.

Quando possível, analise frames em diferentes momentos da referência para entender as transições e a composição de cada cena.

**A referência é o padrão de execução. Não é apenas uma inspiração vaga.**

Reproduza o mesmo nível de sofisticação e complexidade das técnicas observadas, adaptando-as à história da campanha da Dany’s Presentes. Não copie literalmente a identidade de outra marca nem elementos exclusivos que não façam sentido para a Evoquex.

Antes de editar, estabeleça uma lista objetiva das técnicas identificadas na referência e de como serão aplicadas no novo vídeo.

---

## 2. SEGUNDA ETAPA OBRIGATÓRIA: INVESTIGAR AS FERRAMENTAS E AS SKILLS DISPONÍVEIS

Trabalhe no ambiente Codex e no projeto Remotion já existente.

Antes de implementar a nova edição:

1. Inspecione o projeto, seus componentes, dependências, estrutura de animação e recursos de áudio.
2. Identifique quais ferramentas e skills estão efetivamente disponíveis no ambiente.
3. Verifique se existem skills relevantes para motion design avançado, Remotion, animação tipográfica, composição visual, sound design ou edição audiovisual.
4. Se houver acesso autorizado à instalação de skills ou dependências, pesquise recursos confiáveis e específicos que possam melhorar significativamente a execução.
5. Avalie cada recurso antes de utilizá-lo. Prefira documentação oficial, fontes confiáveis e ferramentas compatíveis com o projeto.
6. Instale ou configure apenas o que for necessário, seguro e permitido no ambiente. Não sobrescreva configurações importantes nem instale dependências aleatórias sem avaliar sua utilidade.

Priorize recursos capazes de melhorar a execução de:
- Motion graphics avançado.
- Animações baseadas em física e curvas de movimento.
- Tipografia cinética.
- SVG animado e composição vetorial.
- Máscaras, recortes e transformações.
- Composição de vídeo e efeitos visuais.
- Sound design e sincronização audiovisual.
- Renderização e controle de qualidade no Remotion.

Se uma técnica exigir uma biblioteca adicional, avalie se ela realmente oferece uma vantagem e se é compatível com o ambiente.

**Não afirme que instalou skills, bibliotecas ou ferramentas sem realmente verificar e executar a instalação.** Se algo não estiver disponível, trabalhe com a melhor alternativa viável e informe a limitação ao final.

---

## 3. DIREÇÃO VISUAL: MAIS ELEMENTOS, MAIS PROFUNDIDADE E MAIS DESIGN

A nova versão precisa apresentar uma evolução visual evidente em relação à edição atual.

Não basta adicionar mais texto, aumentar a velocidade dos cortes ou aplicar mais brilhos. Quero elementos gráficos construídos e animados como parte de um sistema visual consistente.

Crie elementos originais que complementem os materiais fornecidos, como:

- Formas geométricas animadas e composições vetoriais.
- Linhas de conexão, trajetórias e contornos que revelem informações.
- Molduras dinâmicas, recortes e máscaras animadas.
- Camadas de interface gráfica inspiradas em dados e distribuição digital, sem fingir que são capturas reais de plataformas.
- Elementos de profundidade, planos de fundo e parallax.
- Marcadores, indicadores, linhas de chamada e componentes gráficos para destacar métricas.
- Transições que transformem um elemento visual em outro.
- Tipografia cinética, com palavras que se movimentem de maneira intencional.
- Elementos tridimensionais ou com aparência de profundidade, somente quando contribuírem para a composição.
- Animações de escala, rotação, posição, opacidade e deformação, com curvas de movimento profissionais.
- Texturas, luzes e detalhes visuais coerentes com a identidade azul da Evoquex.

Esses são exemplos de recursos possíveis, não uma lista para colocar tudo simultaneamente.

Crie elementos adicionais mesmo que não existam nos arquivos fornecidos. O objetivo é desenvolver um sistema visual autoral para o vídeo, como acontece em uma produção de motion design profissional.

Cada elemento precisa ter uma função narrativa ou estética clara.

**Não utilize formas genéricas apenas para preencher espaço. Não transforme a tela em um painel futurista aleatório.**

A composição deve ter camadas, profundidade, ritmo e uma hierarquia visual cuidadosamente construída.

### Padrão de acabamento

Exija:
- Curvas de animação refinadas, sem movimentos mecânicos ou lineares por padrão.
- Entradas e saídas com timing preciso.
- Movimentos coordenados entre diferentes camadas.
- Transições personalizadas, não apenas dissoluções e slides convencionais.
- Tipografia com espaçamento, escala, alinhamento e hierarquia profissionais.
- Composição com equilíbrio entre áreas de respiro e momentos de maior densidade.
- Continuidade visual entre cenas.
- Animações sincronizadas com os eventos sonoros.
- Ausência de elementos tremendo, piscando sem propósito ou competindo pela atenção.

O resultado precisa demonstrar trabalho de design e animação, não apenas edição de timeline.

---

## 4. MATERIAIS ORIGINAIS: COMO CADA UM DEVE SER UTILIZADO

### Vídeo original da Dany’s Presentes

É a principal fonte de conteúdo e deve continuar reconhecível.

Utilize seu início para despertar reconhecimento, mas desenvolva a narrativa por meio de cortes intencionais, enquadramentos, integração com os elementos gráficos e transições de qualidade.

Não deixe o vídeo inteiro rodando sem intervenção visual quando houver oportunidades claras de integrar o motion.

Também não sacrifique a compreensão do conteúdo original apenas para exibir efeitos.

### Print dos resultados

O print é uma fonte de comprovação, não um slide.

Não coloque a imagem inteira no centro da tela e espere que isso seja suficiente.

Explore os dados visualmente:
- Aproxime a região relevante.
- Revele os indicadores com máscaras ou recortes.
- Utilize linhas de chamada para conectar os números ao documento original.
- Faça a transição dos dados documentados para composições tipográficas maiores.
- Use enquadramentos animados para orientar o olhar.
- Crie movimentos que conectem a interface real aos elementos gráficos do vídeo.

Preserve a autenticidade do documento e não invente informações que pareçam fazer parte do Gerenciador de Anúncios.

### Fotografia aérea de Clevelândia

Use a fotografia como matéria-prima para composições mais elaboradas.

Explore recortes, movimentos de câmera, escalas, camadas e profundidade. Integre elementos gráficos à fotografia de maneira coerente, se isso funcionar com a imagem disponível.

A cidade precisa ser reconhecível como contexto local. Não substitua a fotografia por uma cidade genérica.

---

## 5. STORYTELLING E ROTEIRO

O vídeo precisa ter uma progressão narrativa clara: reconhecimento, curiosidade, revelação, comprovação e conversão.

Duração de referência: 25 a 30 segundos, podendo ser ajustada se a qualidade da narrativa exigir.

### Abertura — reconhecimento

Comece com o vídeo original.

Texto:

**“Você chegou a ver esse vídeo em Clevelândia?”**

A frase deve integrar a composição de maneira sofisticada, utilizando motion typography e técnicas visuais inspiradas na referência.

A abertura precisa prender a atenção sem depender de uma tela de título estática.

### Revelação — alcance local

Introduza a informação:

**“13.064 pessoas alcançadas.”**

Faça a revelação por meio de uma sequência visual bem construída, com hierarquia, timing e movimento.

A fotografia de Clevelândia pode participar da transição, sem precisar aparecer como uma imagem isolada.

### Prova — resultado real

Destaque as métricas disponíveis:

**13.064 pessoas alcançadas**

**20 mil visualizações**

O print deve fundamentar visualmente os resultados, enquanto a animação transforma a informação em uma experiência visual mais envolvente.

O Gerenciador de Anúncios registra 20.981 impressões. Não confunda impressões, alcance e visualizações. Confirme a origem de cada métrica antes de exibi-la.

### Conexão — oportunidade

Texto:

**“Sua empresa também pode alcançar mais pessoas.”**

A frase deve nascer da narrativa e do sistema gráfico do vídeo, sem parecer um texto inserido apenas para preencher uma cena.

### CTA final

**“Vamos trabalhar a divulgação da sua empresa?”**

**“Fale com a Evoquex.”**

Crie um encerramento forte, profissional e legível, com tempo suficiente para a leitura.

Não invente logotipos nem resultados comerciais. Se houver um arquivo oficial de identidade visual no projeto, utilize-o somente se for apropriado.

---

## 6. ÁUDIO: REFAZER A TRILHA E O SOUND DESIGN

O áudio da versão anterior ficou ruim. Não o reutilize automaticamente.

Faça uma nova direção de áudio coerente com uma peça publicitária de motion design premium.

### Música

Selecione uma trilha instrumental com qualidade, dinâmica e identidade sonora adequadas à referência.

A música deve:
- Criar expectativa na abertura.
- Crescer durante a revelação das métricas.
- Acompanhar o ritmo da animação.
- Valorizar o resultado sem ficar excessivamente épica.
- Sustentar o CTA final sem competir com a mensagem.

Evite trilhas genéricas, excessivamente corporativas, melodias infantis, música de elevador ou faixas com aparência de template barato.

Utilize apenas áudio disponível legalmente ou com licença adequada para publicação comercial e anúncios.

### Sound design

Crie uma camada de efeitos sonoros intencionais, sincronizados aos eventos visuais.

Considere, quando apropriado:
- Whooshes curtos e refinados para movimentos e transições.
- Impactos sutis para revelações importantes.
- Texturas digitais discretas.
- Sons de interface apenas quando fizerem sentido.
- Acentos sonoros sincronizados com a entrada dos números.
- Transições sonoras que conectem cenas.
- Um fechamento sonoro coerente com o CTA.

Não use um efeito sonoro em cada movimento. O sound design precisa ter contraste, espaço e hierarquia.

### Mixagem

Revise os níveis de música, efeitos e eventual áudio original.

Evite clipping, picos abruptos, graves excessivos e efeitos que soem artificiais. Se houver fala relevante no vídeo original, mantenha sua inteligibilidade.

Faça uma audição integral do MP4 final antes de entregar.

---

## 7. IMPLEMENTAÇÃO TÉCNICA COM REMOTION

Implemente a nova edição no projeto Remotion disponível.

Utilize componentes reutilizáveis e uma estrutura organizada. Controle as animações por frames e use técnicas adequadas para garantir consistência temporal e renderização estável.

Se as ferramentas disponíveis permitirem, crie componentes específicos para:
- Tipografia cinética.
- Elementos vetoriais animados.
- Revelação de métricas.
- Recortes e máscaras.
- Transições personalizadas.
- Composição da fotografia.
- Sincronização audiovisual.

Use SVG, CSS, Canvas ou outras ferramentas compatíveis quando houver benefício real. Não introduza tecnologias complexas apenas para parecer sofisticado.

Verifique os caminhos dos arquivos, dependências e recursos antes da renderização.

Formato final:
- MP4.
- Vertical 9:16.
- 1080 × 1920.
- 30 fps, preferencialmente.
- Duração adequada para Reels e possível utilização em Meta Ads.

---

## 8. CONTROLE DE QUALIDADE OBRIGATÓRIO

Não avalie o sucesso apenas pela compilação do código.

Depois de renderizar:

1. Assista ao vídeo completo.
2. Examine frames da abertura, de cada transição, das métricas e do CTA.
3. Compare a complexidade visual e o acabamento com a referência.
4. Verifique se os elementos gráficos realmente fazem parte da composição ou parecem adesivos sobrepostos.
5. Confirme que os números estão corretos e legíveis.
6. Verifique o equilíbrio entre música, efeitos e áudio original.
7. Corrija movimentos mecânicos, animações genéricas, cenas vazias e transições fracas.
8. Renderize novamente após os ajustes.

Faça uma segunda avaliação específica de motion design. Pergunte se a peça apresenta uma evolução clara em relação à versão anterior e se o padrão de execução se aproxima do vídeo de referência.

Se ainda parecer uma edição comum com textos animados, revise novamente antes de entregar.

## 9. ENTREGA

Entregue:
- O MP4 final renderizado e revisado.
- O código-fonte Remotion atualizado.
- Os arquivos auxiliares necessários para reproduzir a renderização.
- Uma descrição objetiva das principais melhorias implementadas.
- A identificação de qualquer limitação técnica que tenha impedido reproduzir algum aspecto da referência.

Não entregue apenas um roteiro, um storyboard ou uma lista de sugestões.

**CRITÉRIO FINAL DE APROVAÇÃO: quero reconhecer no resultado o mesmo nível de cuidado, complexidade visual, fluidez de animação, composição gráfica e qualidade sonora do vídeo de referência. A versão anterior não atingiu esse padrão. Faça uma nova execução, não apenas pequenos retoques.**