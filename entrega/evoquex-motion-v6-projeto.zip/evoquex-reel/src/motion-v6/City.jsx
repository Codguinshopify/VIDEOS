import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {BUSINESS_NAME} from '../case';
import {Stage,P,move,fast,Word,Media,Icon,Scribe,Pattern,Pill} from './kit';
export const City=()=>{const f=useCurrentFrame();const camera=move(f,12,53);const exit=fast(f,73,89);return <Stage>
 <Pattern opacity={.13}/>
 <div style={{position:'absolute',inset:0,translate:`0 ${-exit*620}px`}}>
 <div style={{position:'absolute',left:75,top:200,rotate:`${move(f,0,22,-6,0)}deg`}}><Word at={0} size={131}>Da tela.</Word><Word at={7} size={141} color={P.blue}>À cidade.</Word></div>
 <div style={{position:'absolute',left:45+camera*10,top:670-camera*50,scale:1+camera*.04,transformOrigin:'50% 50%'}}>
  <Media city x={0} y={0} w={990} h={680} r={30} rotate={move(f,0,36,12,-3)} zoom={1.05+camera*.07}/>
  <svg width={990} height={680} style={{position:'absolute',inset:0,rotate:'-3deg'}}><g transform="translate(550 415)"><circle r={50+camera*30} stroke={P.cyan} strokeWidth={4} fill="none"/><ellipse rx={110} ry={55} fill="none" stroke="white" strokeWidth={2} strokeDasharray="8 10" strokeDashoffset={-f*2}/><circle r={10} fill={P.blue} stroke="white" strokeWidth={4}/></g></svg>
 </div>
 <Icon kind="pin" x={700-camera*40} y={500+camera*35} size={190} color={P.blue} at={4} fill={P.paper}/>
 <Scribe d="M138 1342C50 1560 400 1550 546 1210M522 1233L550 1205L554 1244" width={6} progress={move(f,15,45)}/>
 <div style={{position:'absolute',left:75,top:1490}}><Word at={21} size={89}>Clevelândia, PR.</Word><div style={{fontSize:36,color:P.muted,marginTop:28,opacity:move(f,29,41)}}>{BUSINESS_NAME}</div></div>
 </div>
 <div style={{position:'absolute',left:1080-exit*1080,top:1700-exit*760,width:1080,height:1080,background:P.blue,borderRadius:`${200*(1-exit)}px`,rotate:`${(1-exit)*-15}deg`}}><Icon kind="gift" x={400} y={280} size={280} color={P.cyan} at={73}/></div>
 </Stage>};
