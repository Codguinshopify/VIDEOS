import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {BUSINESS_SHORT} from '../case';
import {Stage,P,move,fast,Word,Media,Icon,Pattern,Scribe,Label,Evidence} from './kit';
export const Brand=()=>{const f=useCurrentFrame();const p=move(f,0,23);const exit=fast(f,48,65);return <Stage color={P.blue}>
 <Pattern color={P.white} opacity={.13} spacing={65}/>
 <div style={{position:'absolute',left:72,top:220,translate:`0 ${-exit*700}px`}}><Word at={0} size={149}>{BUSINESS_SHORT}</Word><Word at={6} size={146} color={P.cyan}>Presentes.</Word><div style={{fontSize:26,letterSpacing:4,marginTop:38,opacity:move(f,13,25)}}>UMA CAMPANHA LOCAL.</div></div>
 <div style={{position:'absolute',inset:0,scale:1+exit*.15,translate:`${exit*-400}px 0`}}>
 <Media x={74} y={790} w={540} h={840} rotate={move(f,0,25,-18,-7)} still={105} zoom={1.12} clip="polygon(0 0,100% 6%,100% 100%,0 94%)"/>
 <div style={{position:'absolute',left:600,top:1000,width:400,height:410,borderRadius:70,background:P.cyan,rotate:`${11-p*9}deg`,scale:.75+p*.25}}><Icon kind="gift" x={68} y={65} size={270} color={P.ink} at={4}/></div>
 <Scribe d="M560 845C840 720 970 840 880 1035M858 1000L880 1040L920 1008" color={P.white} progress={move(f,10,31)} width={4}/>
 <div style={{position:'absolute',left:655,top:1480,width:345,fontSize:30,fontWeight:700,color:P.cyan,rotate:'2deg',opacity:move(f,17,29)}}>O anúncio<br/>que inicia o case.</div>
 </div>
 <div style={{position:'absolute',left:1080-exit*1160,top:0,width:1160,height:1920,background:P.paper,clipPath:'polygon(13% 0,100% 0,100% 100%,0 100%)'}}><Evidence x={250} y={510} w={750} rotate={-8} at={48}/></div>
 </Stage>};
