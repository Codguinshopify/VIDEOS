import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,Icon,Scribe,Label,Evidence} from './kit';
export const Meaning=()=>{const f=useCurrentFrame();const cross=fast(f,56,75);const exit=fast(f,103,119);return <Stage color={P.cyan}>
 <div style={{position:'absolute',left:0,top:0,width:1080,height:760+cross*1160,background:P.paper}}/>
 <Label>DUAS MÉTRICAS. DOIS SIGNIFICADOS.</Label>
 <div style={{position:'absolute',left:75,top:320,translate:`${-cross*1200}px 0`}}><Icon kind="person" x={0} y={0} size={150} color={P.blue} at={0}/><div style={{position:'absolute',left:230,top:0,width:700}}><Word at={2} size={87}>13.064</Word><Word at={7} size={73}>pessoas</Word><div style={{fontSize:28,color:P.muted,marginTop:22,opacity:move(f,11,23)}}>Alcance.</div></div></div>
 <div style={{position:'absolute',left:75,top:1080,translate:`${cross*1200}px 0`}}><Icon kind="eye" x={0} y={0} size={150} color={P.ink} at={6}/><div style={{position:'absolute',left:230,top:0,width:700}}><Word at={9} size={87}>20.981</Word><Word at={13} size={73}>exibições</Word><div style={{fontSize:28,marginTop:22,opacity:move(f,16,29)}}>Impressões.</div></div></div>
 <Scribe d="M110 738H970" progress={move(f,10,28)} color={P.ink} width={2} style={{opacity:1-cross}}/>
 <div style={{position:'absolute',left:75,top:575,opacity:cross,scale:.85+.15*cross,translate:`0 ${-exit*1200}px`}}><Word at={58} size={112}>Métricas</Word><Word at={62} size={112} color={P.blue}>diferentes.</Word><div style={{fontSize:57,fontWeight:700,marginTop:72,opacity:move(f,75,86)}}>Resultados documentados.</div></div>
 <div style={{position:'absolute',left:750,top:1380,opacity:cross,rotate:`${move(f,61,88,-35,-10)}deg`,translate:`0 ${-exit*560}px`}}><Icon kind="check" size={180} color={P.blue} at={65}/></div>
 <div style={{position:'absolute',left:900-exit*625,top:1830-exit*1100,width:650,height:1050,background:P.white,borderRadius:30,rotate:`${12-exit*18}deg`,boxShadow:'0 15px 60px #11132B25',overflow:'hidden'}}><Evidence whole x={0} y={0} w={650} at={102}/></div>
 </Stage>};
