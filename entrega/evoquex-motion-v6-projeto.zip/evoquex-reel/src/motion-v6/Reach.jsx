import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,DigitValue,Evidence,Icon,Scribe,Label,Burst} from './kit';
export const Reach=()=>{const f=useCurrentFrame();const extract=move(f,15,49);const crowd=move(f,60,100);const exit=fast(f,116,131);return <Stage color={P.cyan}>
 <Label>QUEM A CAMPANHA ALCANÇOU</Label>
 <div style={{position:'absolute',left:75,top:255,translate:`0 ${move(f,20,50,0,-55)}px`}}><Word at={-8} size={104} color={P.ink}>O resultado?</Word></div>
 <div style={{position:'absolute',left:0,top:0,translate:`${-exit*1080}px 0`}}>
  <Evidence x={170-extract*100} y={510+extract*570} w={750-extract*290} rotate={-8+extract*12} at={-10}/>
  <div style={{position:'absolute',left:-50,top:425,width:1180,height:350,background:P.ink,opacity:extract,rotate:`${-5+extract*5}deg`,translate:`${(1-extract)*400}px 0`}}/>
  <div style={{position:'absolute',left:63,top:450,opacity:extract,scale:1.14-.14*extract,transformOrigin:'0 0'}}><DigitValue value="13.064" size={262} color={P.white} at={23} style={{left:0,top:0}}/></div>
  <div style={{position:'absolute',left:78,top:805,opacity:move(f,43,57)}}><Word at={40} size={84}>pessoas</Word><Word at={46} size={84} color={P.blue}>alcançadas.</Word></div>
  <Scribe d="M530 1400C700 1400 645 1070 910 1005M872 1001L918 1001L905 1044" width={4} progress={move(f,49,79)}/>
  <div style={{position:'absolute',left:72,top:1650,width:850,fontSize:24,color:P.muted,opacity:move(f,55,68)}}>Alcance · registro original da campanha</div>
  <div style={{position:'absolute',left:600,top:1110,opacity:crowd,transform:`perspective(1000px) rotateY(${-18+crowd*12}deg) rotateX(8deg)`}}>
   {Array.from({length:9},(_,i)=><div key={i} style={{position:'absolute',left:(i%3)*125,top:Math.floor(i/3)*142,translate:`0 ${(1-move(f,61+i*2,78+i*2))*110}px`,rotate:`${(1-move(f,61+i*2,78+i*2))*(i%2?30:-30)}deg`}}><Icon kind="person" size={100} color={i===4?P.blue:'#5D9CA5'} at={60+i*2} fill={i===4?P.lilac:'none'}/></div>)}
  </div>
 </div>
 <div style={{position:'absolute',left:1080-exit*1080,top:0,width:1080,height:1920,background:P.ink}}><Icon kind="eye" x={260} y={720} size={560} color={P.cyan} at={116}/></div>
 <Burst x={540} y={620} at={30} r={570} color={P.blue}/>
 </Stage>};
