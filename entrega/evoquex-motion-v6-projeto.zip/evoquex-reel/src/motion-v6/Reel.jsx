import React from 'react';
import {AbsoluteFill,Sequence,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {Hook} from './Hook';import {City} from './City';import {Brand} from './Brand';import {Reach} from './Reach';import {Impressions} from './Impressions';import {Meaning} from './Meaning';import {Proof} from './Proof';import {Bridge} from './Bridge';import {Contact} from './Contact';
import timeline from './timeline.json';
import {SceneClock,Enter} from './kit';
// Authored sequences preserve independent scene editing in Studio.
export const EvoquexRebuilt=()=>{const {fps}=useVideoConfig();return <AbsoluteFill>
 <Sequence name="01 — Hook / anúncio em faixas" from={timeline.chapters[0].from} durationInFrames={timeline.chapters[0].frames+8} premountFor={fps}><SceneClock authored={84} actual={timeline.chapters[0].frames}><Hook/></SceneClock></Sequence>
 <Sequence name="02 — Tela vira cidade" from={timeline.chapters[1].from} durationInFrames={timeline.chapters[1].frames+8} premountFor={fps}><Enter kind="circle"><SceneClock authored={90} actual={timeline.chapters[1].frames}><City/></SceneClock></Enter></Sequence>
 <Sequence name="03 — Danny’s Presentes / campanha" from={timeline.chapters[2].from} durationInFrames={timeline.chapters[2].frames+8} premountFor={fps}><Enter kind="diagonal"><SceneClock authored={66} actual={timeline.chapters[2].frames}><Brand/></SceneClock></Enter></Sequence>
 <Sequence name="04 — Documento vira alcance" from={timeline.chapters[3].from} durationInFrames={timeline.chapters[3].frames+8} premountFor={fps}><Enter kind="side"><SceneClock authored={132} actual={timeline.chapters[3].frames}><Reach/></SceneClock></Enter></Sequence>
 <Sequence name="05 — Pessoas / exibições / impressões" from={timeline.chapters[4].from} durationInFrames={timeline.chapters[4].frames+8} premountFor={fps}><Enter kind="side"><SceneClock authored={132} actual={timeline.chapters[4].frames}><Impressions/></SceneClock></Enter></Sequence>
 <Sequence name="06 — Métricas diferentes" from={timeline.chapters[5].from} durationInFrames={timeline.chapters[5].frames+8} premountFor={fps}><Enter kind="up"><SceneClock authored={120} actual={timeline.chapters[5].frames}><Meaning/></SceneClock></Enter></Sequence>
 <Sequence name="07 — Prova original" from={timeline.chapters[6].from} durationInFrames={timeline.chapters[6].frames+8} premountFor={fps}><Enter kind="diagonal"><SceneClock authored={66} actual={timeline.chapters[6].frames}><Proof/></SceneClock></Enter></Sequence>
 <Sequence name="08 — Campanha vira conversa" from={timeline.chapters[7].from} durationInFrames={timeline.chapters[7].frames+8} premountFor={fps}><Enter kind="circle"><SceneClock authored={84} actual={timeline.chapters[7].frames}><Bridge/></SceneClock></Enter></Sequence>
 <Sequence name="09 — Convite natural" from={timeline.chapters[8].from} durationInFrames={timeline.chapters[8].frames} premountFor={fps}><Enter kind="side"><SceneClock authored={156} actual={timeline.chapters[8].frames}><Contact/></SceneClock></Enter></Sequence>
 <Audio name="Trilha e efeitos V6 — locução final pendente" src={staticFile(timeline.sound_file)} premountFor={fps}/>
 </AbsoluteFill>};
