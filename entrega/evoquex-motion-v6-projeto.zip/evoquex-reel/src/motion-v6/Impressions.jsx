import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,DigitValue,Evidence,Icon,Media,Scribe,Label} from './kit';
export const Impressions=()=>{const f=useCurrentFrame();const reveal=fast(f,21,39);const settle=move(f,46,76);const exit=fast(f,117,131);return <Stage color={P.ink}>
 <div style={{position:'absolute',left:0,top:1920-reveal*1920,width:1080,height:1920,background:P.blue}}/>
 <Label light>QUANTAS VEZES O ANÚNCIO FOI EXIBIDO</Label>
 <div style={{position:'absolute',left:75,top:255,opacity:1-reveal}}><Word at={0} size={110}>E continuou</Word><Word at={5} size={110} color={P.cyan}>aparecendo.</Word></div>
 <div style={{position:'absolute',left:0,top:0,opacity:1-settle,scale:1+reveal*.8,translate:`0 ${-reveal*550}px`}}><Icon kind="eye" x={95} y={650} size={890} color={P.cyan} at={-20}/><Media x={365} y={945} w={350} h={350} r={175} zoom={1.4} still={37}/></div>
 <div style={{position:'absolute',left:0,top:0,opacity:reveal,translate:`0 ${exit*-1920}px`}}>
 <div style={{position:'absolute',left:65,top:305,opacity:move(f,29,44),color:'#6E8AFF',fontSize:258,fontWeight:800,letterSpacing:-18,translate:`${move(f,30,84,100,-30)}px ${move(f,30,84,45,-10)}px`}}>20.981</div>
 <DigitValue value="20.981" at={29} size={258} color={P.white} style={{left:63,top:365}}/>
 <div style={{position:'absolute',left:75,top:705}}><Word at={43} size={112} color={P.cyan}>impressões.</Word></div>
 <div style={{position:'absolute',left:0,top:0,opacity:move(f,49,68)}}>
 <Evidence kind="impressions" x={115} y={1005} w={590} rotate={-7+settle*4} at={48}/>
 <Media x={765-settle*15} y={1060} w={205} h={365} r={35} rotate={8} still={37}/>
 <Icon kind="eye" x={770} y={1465} size={160} color={P.cyan} at={58}/>
 <Scribe d="M660 1320C755 1280 740 1460 825 1480" color={P.cyan} progress={move(f,59,87)} width={4}/>
 <div style={{position:'absolute',left:75,top:1590,width:880,fontSize:36,color:'#D4E4FF'}}>Exibições do anúncio.</div>
 <div style={{position:'absolute',left:75,top:1675,width:880,fontSize:23,color:'#CCD6FF'}}>Comprovadas no Gerenciador de Anúncios.</div>
 </div></div>
 <div style={{position:'absolute',left:0,top:1920-exit*1920,width:1080,height:1920,background:P.cyan}}/>
 </Stage>};
