import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,Media,Icon,Scribe,Burst,Label,Morph} from './kit';
export const Hook=()=>{const f=useCurrentFrame();const flip=fast(f,31,41);const end=fast(f,66,83);return <Stage color={P.ink}>
 <div style={{position:'absolute',left:-1080+flip*1080,top:0,width:1080,height:1920,background:P.blue}}/>
 <Label light>UM CASE REAL · EVOQUEX</Label>
 <div style={{position:'absolute',left:70,top:285,translate:`${-flip*1200}px 0`,rotate:`${-4+flip*-8}deg`}}><Word at={-22} size={122}>ESSE</Word><Word at={-22} size={167} color={P.cyan}>ANÚNCIO.</Word></div>
 <div style={{position:'absolute',left:70,top:310,opacity:flip,translate:`${(1-flip)*1080}px 0`}}><Word at={33} size={156}>VOCÊ</Word><Word at={37} size={207} color={P.cyan}>VIU?</Word></div>
 <div style={{position:'absolute',inset:0,translate:`${-end*1000}px 0`}}>
  <Media x={230-move(f,0,28)*80} y={640+flip*160} w={725-flip*150} h={760-flip*140} rotate={8-flip*18} zoom={move(f,0,30,1.72,1.62)} panY={80} panX={-move(f,0,40,0,95)} clip="polygon(9% 0,100% 0,91% 100%,0 100%)"/>
  <div style={{position:'absolute',left:90,top:680,width:130,height:830,background:P.cyan,rotate:'8deg',clipPath:`inset(0 ${move(f,0,20,80,0)}% 0 0)`}}/>
  <Scribe d="M108 641L210 1635 M925 677L842 1580" color={P.cyan} width={3} progress={move(f,0,18,.3,1)}/>
 </div>
 <div style={{position:'absolute',left:760-end*350,top:1190-end*280,width:230,height:230,borderRadius:65,background:P.cyan,rotate:`${-9+flip*20}deg`,scale:1+end*3.2}}><Morph from="play" to="pin" progress={end} x={36} y={36} size={158} color={P.ink}/></div>
 <Scribe d="M120 1730C330 1660 520 1790 720 1660L820 1570M730 1565L826 1565L824 1660" color={P.cyan} progress={move(f,15,52)} width={5}/>
 <div style={{position:'absolute',left:75,top:1760,fontSize:31,color:'#CFD7EC',letterSpacing:-.8,opacity:1-end}}>O anúncio ganhou alcance local.</div>
 <Burst x={875} y={1290} r={250} at={35}/>
 </Stage>};
