import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,Icon,Media,Scribe,Burst,Label} from './kit';
export const Contact=()=>{const f=useCurrentFrame();const switcher=fast(f,48,66);const settle=move(f,78,119);return <Stage color={P.ink}>
 <div style={{position:'absolute',left:0,top:1920-switcher*1920,width:1080,height:1920,background:P.blue}}/>
 <Label light>EVOQUEX · MOTION / ESTRATÉGIA</Label>
 <div style={{position:'absolute',left:75,top:315,translate:`0 ${-switcher*1200}px`}}><Word at={-8} size={136}>Quer fazer</Word><Word at={0} size={136} color={P.cyan}>algo assim?</Word></div>
 <div style={{position:'absolute',left:75,top:310,opacity:switcher,translate:`${(1-switcher)*1100}px 0`}}><Word at={49} size={122}>Conversa</Word><Word at={54} size={108}>com a</Word></div>
 <div style={{position:'absolute',left:78,top:690+switcher*120,width:925,height:540,borderRadius:100,background:P.cyan,scale:1-settle*.06,rotate:`${move(f,0,31,-7,0)}deg`,boxShadow:'0 25px 55px #00000025'}}>
  <div style={{position:'absolute',left:78,top:177,fontSize:68,fontWeight:800,color:P.ink,letterSpacing:-3.5,opacity:1-switcher}}>Para a sua empresa.</div>
  <div style={{position:'absolute',left:125,top:150,opacity:switcher,rotate:`${move(f,61,96,-5,0)}deg`}}><Word at={63} size={178} color={P.ink}>gente.</Word></div>
  <svg width={925} height={630} style={{position:'absolute',inset:0,pointerEvents:'none'}}><path d="M740 523L675 620L647 523" fill={P.cyan}/></svg>
 </div>
 <div style={{position:'absolute',left:75,top:1450,translate:`${move(f,72,116,-50,0)}px 0`,opacity:move(f,70,90)}}>
  <div style={{fontSize:80,fontWeight:800,letterSpacing:-4,color:P.white}}>Evoquex</div>
  <div style={{fontSize:29,color:'#C1CFFE',marginTop:23}}>Uma conversa. Um novo projeto.</div>
 </div>
 <Media city x={715} y={1420} w={300} h={220} r={50} rotate={5+settle*2} opacity={move(f,73,90)}/>
 <Scribe d="M110 1390C80 1300 256 1280 285 1344" color={P.cyan} progress={move(f,76,99)} width={5}/>
 <Burst x={550} y={1090} r={440} at={60}/>
 </Stage>};
