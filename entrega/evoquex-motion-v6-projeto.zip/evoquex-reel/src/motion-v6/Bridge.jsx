import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {Stage,P,move,fast,Word,Icon,Media,Scribe,Pattern,Morph} from './kit';
export const Bridge=()=>{const f=useCurrentFrame();const shift=fast(f,28,48);const exit=fast(f,66,83);return <Stage color={P.ink}>
 <Pattern color={P.cyan} opacity={.16}/>
 <div style={{position:'absolute',left:75,top:290,translate:`${-shift*1100}px 0`}}><Word at={0} size={128}>Da campanha</Word><Word at={6} size={128} color={P.cyan}>à conversa.</Word></div>
 <div style={{position:'absolute',left:75,top:310,translate:`${(1-shift)*1100}px ${-exit*1000}px`,opacity:shift}}><Word at={29} size={132}>E para a</Word><Word at={35} size={140} color={P.cyan}>sua empresa?</Word></div>
 <div style={{position:'absolute',left:70,top:900,translate:`${-exit*1050}px 0`}}>
 <Media x={15} y={10} w={375} h={630} rotate={-7} still={37}/>
 <div style={{position:'absolute',left:610,top:90,width:300,height:350,borderRadius:65,background:P.blue,rotate:`${10-shift*8}deg`}}><Morph from="play" to="chat" progress={shift} x={35} y={45} size={230} color={P.cyan}/></div>
 <Scribe d="M370 1260C560 1120 540 1370 720 1210 M680 1230L727 1201L715 1254" color={P.cyan} progress={move(f,10,37)} width={6}/>
 </div>
 <div style={{position:'absolute',left:75,top:1640,fontSize:31,color:'#C5D3ED',opacity:1-exit}}>O próximo projeto pode ser o seu.</div>
 <div style={{position:'absolute',left:1080-exit*1080,top:1100-exit*410,width:1080,height:540,background:P.cyan,borderRadius:100,rotate:`${(1-exit)*-22}deg`}}/>
 </Stage>};
