import React from 'react';
import {useFrame as useCurrentFrame} from './kit';
import {BUSINESS_NAME} from '../case';
import {Stage,P,move,fast,Word,Evidence,Scribe,Icon,Label} from './kit';
export const Proof=()=>{const f=useCurrentFrame();const camera=move(f,0,35);const exit=fast(f,49,65);return <Stage>
 <Label>DOCUMENTO ORIGINAL DA CAMPANHA</Label>
 <Evidence whole x={275+camera*160} y={730-camera*170} w={650-camera*60} rotate={-6+camera*12} at={-8}/>
 <div style={{position:'absolute',left:70,top:335,translate:`${-exit*1150}px 0`}}><Word at={0} size={142}>É um case.</Word><Word at={5} size={167} color={P.blue}>Real.</Word></div>
 <div style={{position:'absolute',left:75,top:1010,opacity:move(f,18,31),translate:`${-exit*1100}px 0`}}><div style={{fontSize:28,fontWeight:800,color:P.blue}}>{BUSINESS_NAME}</div><div style={{fontSize:24,color:P.muted,marginTop:12}}>Gerenciador de Anúncios</div></div>
 <Scribe d="M90 1195C260 1280 255 1380 600 1410" progress={move(f,19,42)} width={4}/>
 <Icon kind="check" x={98} y={1370} size={140} color={P.blue} at={20}/>
 <div style={{position:'absolute',left:0,top:0,width:1080,height:1920,background:P.ink,clipPath:`circle(${exit*145}% at 83% 77%)`}}/>
 </Stage>};
