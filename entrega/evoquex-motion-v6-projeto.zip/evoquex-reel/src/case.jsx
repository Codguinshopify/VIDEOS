// Canonical spelling for every authored label. Original media filenames are archival.
export const BUSINESS_NAME = 'Danny’s Presentes';
export const BUSINESS_SHORT = 'Danny’s';
