import {BUSINESS_NAME} from '../case';
import React from 'react';
import {Interactive, useCurrentFrame} from 'remotion';
import {Canvas, DocumentPlane, mix, palette, Words} from './kit';

export const documentPose = (f, kind) => ({kind, x: mix(f, [0, 19], [kind === 'reach' ? 390 : -510, 130]), y: mix(f, [48, 74], [560, kind === 'reach' ? 420 : 458]), width: 820, rotate: mix(f, [0, 20, 74], [kind === 'reach' ? 13 : -15, -5, 0]), yaw: mix(f, [0, 25], [kind === 'reach' ? -24 : 23, 0]), zoom: mix(f, [48, 74], [1, 4]), blur: mix(f, [0, 18], [12, 0]), mark: mix(f, [18, 43], [0, 1])});

const Document = ({kind}) => {
  const f = useCurrentFrame();
  return <Canvas>
    <div style={{position: 'absolute', top: 235, left: 90, width: 900, textAlign: 'center', opacity: mix(f, [47, 67], [1, 0])}}><Words text={kind === 'reach' ? 'A prova está' : 'E o conteúdo'} at={0} style={{fontSize: 83}} /><Words text={kind === 'reach' ? 'no alcance.' : 'circulou.'} at={8} color={palette.blue} style={{fontSize: 98}} /></div>
    <DocumentPlane {...documentPose(f, kind)} />
    <div style={{position: 'absolute', left: 95, top: 1540, width: 890, textAlign: 'center', opacity: mix(f, [0, 22, 50, 66], [0, 1, 1, 0])}}><div style={{fontSize: 36, fontWeight: 700, letterSpacing: 1}}>RECORTE DO REGISTRO ORIGINAL</div><div style={{fontSize: 33, marginTop: 12, color: palette.muted}}>Gerenciador de Anúncios · {BUSINESS_NAME}</div></div>
  </Canvas>;
};

const Reach = () => <Document kind="reach" />;
const Impressions = () => <Document kind="impressions" />;
export const MotionReachDocument = Interactive.withSchema({Component: Reach, componentName: '<MotionReachDocument>', schema: {}, wrapInSequence: true});
export const MotionImpressionsDocument = Interactive.withSchema({Component: Impressions, componentName: '<MotionImpressionsDocument>', schema: {}, wrapInSequence: true});
