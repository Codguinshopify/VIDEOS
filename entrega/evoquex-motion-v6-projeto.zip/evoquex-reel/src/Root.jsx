import React from 'react';
import {Composition, Folder} from 'remotion';
import {EvoquexReel} from './Reel';
import {OpeningScene} from './scenes/Opening';
import {RevelationScene} from './scenes/Revelation';
import {ProofScene} from './scenes/Proof';
import {ConnectionScene} from './scenes/Connection';
import {ClosingScene} from './scenes/Closing';
import {EvoquexMotion} from './motion-v2/MotionReel';
import {MotionIntro} from './motion-v2/Intro';
import {MotionLocal} from './motion-v2/Local';
import {MotionReachDocument, MotionImpressionsDocument} from './motion-v2/Document';
import {MotionReach, MotionImpressions} from './motion-v2/Metric';
import {MotionOpportunity} from './motion-v2/Opportunity';
import {MotionStrategy} from './motion-v2/Strategy';
import {MotionContact} from './motion-v2/Contact';
import {EvoquexPremium} from './motion-v3/PremiumReel';
import {Recognition} from './motion-v3/Recognition';
import {Local} from './motion-v3/Local';
import {Reach, Impressions} from './motion-v3/Proof';
import {Opportunity} from './motion-v3/Opportunity';
import {Contact} from './motion-v3/Contact';
import narration from './narration-timing.json';

import {EvoquexRebuilt} from './motion-v6/Reel';
import v6Timeline from './motion-v6/timeline.json';
import {Hook as V6Hook} from './motion-v6/Hook';
import {City as V6City} from './motion-v6/City';
import {Brand as V6Brand} from './motion-v6/Brand';
import {Reach as V6Reach} from './motion-v6/Reach';
import {Impressions as V6Impressions} from './motion-v6/Impressions';
import {Meaning as V6Meaning} from './motion-v6/Meaning';
import {Proof as V6Proof} from './motion-v6/Proof';
import {Bridge as V6Bridge} from './motion-v6/Bridge';
import {Contact as V6Contact} from './motion-v6/Contact';

export const RemotionRoot = () => <>
  <Composition id="EvoquexRebuilt" component={EvoquexRebuilt} width={1080} height={1920} fps={30} durationInFrames={v6Timeline.total_frames}/>
  <Folder name="Motion-V6">
    <Composition id="V6-Hook" component={V6Hook} width={1080} height={1920} fps={30} durationInFrames={84}/>
    <Composition id="V6-Cidade" component={V6City} width={1080} height={1920} fps={30} durationInFrames={90}/>
    <Composition id="V6-Marca" component={V6Brand} width={1080} height={1920} fps={30} durationInFrames={66}/>
    <Composition id="V6-Alcance" component={V6Reach} width={1080} height={1920} fps={30} durationInFrames={132}/>
    <Composition id="V6-Impressoes" component={V6Impressions} width={1080} height={1920} fps={30} durationInFrames={132}/>
    <Composition id="V6-Metricas" component={V6Meaning} width={1080} height={1920} fps={30} durationInFrames={120}/>
    <Composition id="V6-Prova" component={V6Proof} width={1080} height={1920} fps={30} durationInFrames={66}/>
    <Composition id="V6-Conversa" component={V6Bridge} width={1080} height={1920} fps={30} durationInFrames={84}/>
    <Composition id="V6-Convite" component={V6Contact} width={1080} height={1920} fps={30} durationInFrames={156}/>
  </Folder>
  <Composition id="EvoquexPremium" component={EvoquexPremium} width={1080} height={1920} fps={30} durationInFrames={narration.total_frames} />
  <Folder name="Motion-V3">
    <Composition id="V3-Reconhecimento" component={Recognition} width={1080} height={1920} fps={30} durationInFrames={narration.segments[0].frames} defaultProps={{duration:narration.segments[0].frames}}/>
    <Composition id="V3-Contexto" component={Local} width={1080} height={1920} fps={30} durationInFrames={narration.segments[1].frames} defaultProps={{clipStart:narration.segments[0].frames}}/>
    <Composition id="V3-Alcance" component={Reach} width={1080} height={1920} fps={30} durationInFrames={narration.segments[2].frames}/>
    <Composition id="V3-Impressoes" component={Impressions} width={1080} height={1920} fps={30} durationInFrames={narration.segments[3].frames}/>
    <Composition id="V3-Oportunidade" component={Opportunity} width={1080} height={1920} fps={30} durationInFrames={narration.segments[4].frames} defaultProps={{duration:narration.segments[4].frames}}/>
    <Composition id="V3-Contato" component={Contact} width={1080} height={1920} fps={30} durationInFrames={narration.segments[5].frames}/>
  </Folder>
  <Composition id="EvoquexMotion" component={EvoquexMotion} width={1080} height={1920} fps={30} durationInFrames={840} />
  <Folder name="Motion-V2">
    <Composition id="Motion-Reconhecimento" component={MotionIntro} width={1080} height={1920} fps={30} durationInFrames={114} />
    <Composition id="Motion-Local" component={MotionLocal} width={1080} height={1920} fps={30} durationInFrames={72} />
    <Composition id="Motion-Documento-Alcance" component={MotionReachDocument} width={1080} height={1920} fps={30} durationInFrames={75} />
    <Composition id="Motion-Alcance" component={MotionReach} width={1080} height={1920} fps={30} durationInFrames={93} />
    <Composition id="Motion-Documento-Impressoes" component={MotionImpressionsDocument} width={1080} height={1920} fps={30} durationInFrames={72} />
    <Composition id="Motion-Impressoes" component={MotionImpressions} width={1080} height={1920} fps={30} durationInFrames={69} />
    <Composition id="Motion-Oportunidade" component={MotionOpportunity} width={1080} height={1920} fps={30} durationInFrames={129} />
    <Composition id="Motion-Estrategia" component={MotionStrategy} width={1080} height={1920} fps={30} durationInFrames={84} />
    <Composition id="Motion-Contato" component={MotionContact} width={1080} height={1920} fps={30} durationInFrames={132} />
  </Folder>
  <Composition id="EvoquexCase" component={EvoquexReel} width={1080} height={1920} fps={30} durationInFrames={840} />
  <Folder name="Cenas">
    <Composition id="Reconhecimento" component={OpeningScene} width={1080} height={1920} fps={30} durationInFrames={132} />
    <Composition id="Revelacao" component={RevelationScene} width={1080} height={1920} fps={30} durationInFrames={162} />
    <Composition id="Prova" component={ProofScene} width={1080} height={1920} fps={30} durationInFrames={252} />
    <Composition id="Conexao" component={ConnectionScene} width={1080} height={1920} fps={30} durationInFrames={192} />
    <Composition id="Convite" component={ClosingScene} width={1080} height={1920} fps={30} durationInFrames={150} />
  </Folder>
</>;
