import React from 'react';
import {AbsoluteFill, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {C, glide, tween} from './system';
import {Recognition} from './Recognition';
import {Local} from './Local';
import {Reach, Impressions} from './Proof';
import {Opportunity} from './Opportunity';
import {Contact} from './Contact';
import narration from '../narration-timing.json';

const Reveal = ({children, kind}) => {
  const f = useCurrentFrame();
  const p = tween(f, [0, kind === 'story' ? 9 : kind === 'cta' ? 12 : 10], [0, 1], glide);
  const mask = kind === 'proof' ? `circle(${p * 145}% at 60% 58%)` : kind === 'impressions' ? `ellipse(${p * 160}% ${p * 110}% at 16% 73%)` : kind === 'story' ? `polygon(0 ${100 - p * 200}%,100% ${145 - p * 200}%,100% 100%,0 100%)` : `circle(${p * 150}% at 77% 70%)`;
  return <AbsoluteFill style={{clipPath: mask}}>{children}</AbsoluteFill>;
};

export const EvoquexPremium = () => {
  const f = useCurrentFrame(), {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: C.paper}}>
    <Sequence name="Hook narrado — portal e órbitas" from={0} durationInFrames={narration.segments[0].frames} premountFor={fps}><Recognition duration={narration.segments[0].frames}/></Sequence>
    <Sequence name="Contexto narrado — Danny’s Presentes" from={narration.segments[1].from} durationInFrames={narration.segments[1].frames+10} premountFor={fps}><Local clipStart={narration.segments[0].frames}/></Sequence>
    <Sequence name="Alcance narrado — prova, lente e 13.064" from={narration.segments[2].from} durationInFrames={narration.segments[2].frames+10} premountFor={fps}><Reveal kind="proof"><Reach/></Reveal></Sequence>
    <Sequence name="Impressões narradas — 20.981" from={narration.segments[3].from} durationInFrames={narration.segments[3].frames+9} premountFor={fps}><Reveal kind="impressions"><Impressions/></Reveal></Sequence>
    <Sequence name="Oportunidade narrada — planos e distribuição" from={narration.segments[4].from} durationInFrames={narration.segments[4].frames+12} premountFor={fps}><Reveal kind="story"><Opportunity duration={narration.segments[4].frames}/></Reveal></Sequence>
    <Sequence name="Conversão narrada — Evoquex" from={narration.segments[5].from} durationInFrames={narration.segments[5].frames} premountFor={fps}><Reveal kind="cta"><Contact/></Reveal></Sequence>
    <Audio name="Mix narrado — voz feminina, música e efeitos reais" src={staticFile('assets/evoquex-narrado.wav')} premountFor={fps}/>
  </AbsoluteFill>;
};
