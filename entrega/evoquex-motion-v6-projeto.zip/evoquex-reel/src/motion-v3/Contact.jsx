import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Base, C, CityPlane, FilmPlane, MaskLine, Path, tween} from './system';
import {OrbitField} from './ParkDesign';

export const Contact = () => {
  const f = useCurrentFrame();
  const p = tween(f, [6, 33], [0, 1]);
  return <Base>
    <OrbitField x={830} y={1190} radius={570} color={C.blue} opacity={.10} progress={tween(f,[0,55],[.24,1])}/>
    <div style={{position: 'absolute', left: 96, top: 195, fontSize: 51, fontWeight: 800, color: C.blue, letterSpacing: -2, opacity: tween(f, [4, 18], [0, 1])}}>Evoquex</div>
    <div style={{position: 'absolute', left: 94, top: 407, width: 925}}><MaskLine at={7} size={91}>Vamos trabalhar</MaskLine><MaskLine at={13} size={91}>a divulgação</MaskLine><MaskLine at={19} size={91}>da sua empresa?</MaskLine></div>
    <div style={{position: 'absolute', left: 96 + 465 * (1 - p), top: 1090 + 80 * (1 - p), width: 888 - 428 * (1 - p), height: 190 + 220 * (1 - p), background: C.blue, borderRadius: 58 + 67 * (1 - p), boxShadow: `0 ${20 * p}px ${55 * p}px #1552F52B`, overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 49, top: 60, fontSize: 53, fontWeight: 800, letterSpacing: -2.1, color: '#FFF', whiteSpace: 'nowrap', opacity: tween(f, [28, 42], [0, 1]), translate: `0 ${tween(f, [28, 45], [65, 0])}px`}}>Fale com a Evoquex.</div>
      <svg width={110} height={100} viewBox="0 0 110 100" style={{position: 'absolute', right: 31, top: 43}}><path d="M18 75L76 25M32 24H77V68" fill="none" stroke="#FFF" strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - tween(f, [39, 57], [0, 1])}/></svg>
    </div>
    <Path d="M120 1070C100 955 380 1058 466 920 M431 935L470 914L479 953" progress={tween(f, [35, 58], [0, 1])} width={4} color={C.ink}/>
    <div style={{position: 'absolute', left: 96, top: 1480, color: C.muted, opacity: tween(f, [52, 69], [0, 1]), fontSize: 35, lineHeight: 1.35, letterSpacing: -1}}>Da sua empresa<br/>ao público certo.</div>
    <div style={{opacity: tween(f, [53, 74], [0, 1]), translate: `0 ${tween(f, [53, 78], [60, 0])}px`}}><CityPlane x={665} y={1455} width={310} rotate={-5 + tween(f, [75, 191], [0, 1.8])} radius={155}/><FilmPlane x={555} y={1425} width={126} height={216} radius={25} rotate={8 - tween(f, [75, 191], [0, 2])} still={48}/></div>
  </Base>;
};
