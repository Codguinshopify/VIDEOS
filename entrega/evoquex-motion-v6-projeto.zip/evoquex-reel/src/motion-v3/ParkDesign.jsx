import React from 'react';
import {Img, staticFile, useCurrentFrame} from 'remotion';
import {C, tween} from './system';

// Shared orbit motif: nested broken circles, camera parallax and measured drawing.
export const OrbitField = ({x=540,y=980,radius=510,color=C.blue,opacity=.32,phase=0,progress=1}) => {
 const f=useCurrentFrame()+phase;
 return <svg width={1080} height={1920} style={{position:'absolute',inset:0,pointerEvents:'none',overflow:'visible',opacity}}>
  <g transform={`translate(${x} ${y})`}>
   <circle r={radius*1.24} fill="none" stroke={color} strokeWidth={16} opacity={.12} strokeDasharray={`${radius*3.2} ${radius*4.6}`} transform={`rotate(${-f*.34-32})`} />
   <circle r={radius*1.1} fill="none" stroke={color} strokeWidth={3} opacity={.42} pathLength={1} strokeDasharray=".29 .04 .12 .10 .34 .11" strokeDashoffset={-f*.0015} />
   <circle r={radius} fill="none" stroke={color} strokeWidth={4} opacity={.85} pathLength={1} strokeDasharray={1} strokeDashoffset={1-progress} transform={`rotate(${f*.26+25})`} />
   <circle r={radius*.86} fill="none" stroke={color} strokeWidth={1.5} opacity={.3} strokeDasharray={`${radius*1.1} ${radius*2.5}`} transform={`rotate(${-f*.19+80})`}/>
   <circle cx={radius*1.1} r={7} fill={color} transform={`rotate(${f*.26+25})`}/>
  </g>
 </svg>;
};

// A real photographic detail, never a recreated interface or a generated number.
export const EvidenceLens = ({kind='reach',x=740,y=1090,size=238,at=24,light=false}) => {
 const f=useCurrentFrame();const p=tween(f,[at,at+18],[0,1]);
 const focus=kind==='reach'?{x:657,y:1070}:{x:279,y:974};
 const ratio=kind==='impressions'?1.15:1.45;
 return <div style={{position:'absolute',left:x,top:y,width:size,height:size,opacity:p,translate:`${(1-p)*80}px ${(1-p)*45}px`,scale:.8+.2*p,rotate:`${(1-p)*14}deg`,filter:`blur(${(1-p)*6}px)`}}>
  <div style={{position:'absolute',inset:0,borderRadius:'50%',overflow:'hidden',border:`7px solid ${light?'#DDF4FF':C.blue}`,background:'#E7E7DE',boxShadow:'0 18px 40px #081A2A30'}}>
   <Img src={staticFile('assets/resultados.jpg')} style={{position:'absolute',width:898*ratio,height:1601*ratio,maxWidth:'none',left:size/2-focus.x*ratio,top:size/2-focus.y*ratio}}/>
  </div>
  <svg width={size+55} height={size+55} style={{position:'absolute',inset:0,overflow:'visible'}}><path d={`M${size*.84} ${size*.84}L${size+35} ${size+35}`} stroke={light?'#DDF4FF':C.ink} strokeWidth={13} strokeLinecap="round"/><circle cx={size/2} cy={size/2} r={size/2+13} fill="none" stroke={light?C.cyan:C.blue} strokeWidth={2} opacity={.45}/></svg>
 </div>;
};
