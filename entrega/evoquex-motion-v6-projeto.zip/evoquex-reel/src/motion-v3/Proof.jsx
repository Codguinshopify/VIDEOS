import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Base, C, Corners, cropDimensions, Evidence, Eyebrow, FilmPlane, MaskLine, Metric, Path, PlayToken, tween} from './system';
import {EvidenceLens, OrbitField} from './ParkDesign';

export const Reach = () => {
  const f = useCurrentFrame();
  const p = tween(f, [20, 49], [0, 1]);
  const x = 100 - 28 * p, y = 575 + 565 * p, w = 880 - 360 * p;
  const {cx, cy} = cropDimensions('reach', w);
  const sourceX = x + cx + 130, sourceY = y + cy + 45;
  return <Base>
    <OrbitField x={540} y={830} radius={405} opacity={.09} progress={tween(f,[0,34],[.3,1])}/>
    <Eyebrow>ALCANCE · DOCUMENTADO</Eyebrow>
    <div style={{position: 'absolute', left: 94, top: 305}}><MaskLine at={2} size={91}>Pessoas reais.</MaskLine><MaskLine at={9} size={91} color={C.blue}>Alcance local.</MaskLine></div>
    <div style={{position: 'absolute', inset: 0, opacity: tween(f, [27, 46], [0, 1])}}>
      <svg width={1080} height={1920}><ellipse cx={550} cy={847} rx={450} ry={200} fill="none" stroke="#D8E2F7" strokeWidth={1.4}/><ellipse cx={550} cy={847} rx={470} ry={240} fill="none" stroke="#E6EAF1" strokeWidth={1}/><circle cx={100} cy={847} r={6} fill={C.blue}/><circle cx={1000} cy={847} r={6} fill={C.blue}/></svg>
    </div>
    <Evidence kind="reach" x={x} y={y} width={w} rotate={tween(f, [0, 19, 49], [-7, 0, 0])} yaw={tween(f, [0, 20], [-15, 0])} mark={tween(f, [8, 24], [0, 1])}/>
    <div style={{position: 'absolute', top: 650, left: 58, width: 964}}><Metric value="13.064" at={18} size={248}/></div>
    <div style={{position: 'absolute', top: 972, left: 94, width: 892, textAlign: 'center', fontSize: 51, fontWeight: 700, letterSpacing: -2, opacity: tween(f, [45, 59], [0, 1])}}>pessoas alcançadas</div>
    <Path d={`M${sourceX} ${sourceY}C${sourceX + 160} ${sourceY + 45} 690 1145 690 1057`} progress={tween(f, [43, 65], [0, 1])} width={4}/>
    <div style={{position: 'absolute', left: 78, top: 1089, opacity: tween(f, [47, 61], [0, 1]), fontSize: 19, letterSpacing: 2, fontWeight: 700, color: C.muted}}>REGISTRO ORIGINAL</div>
    <div style={{position: 'absolute', left: 78, top: 1650, opacity: tween(f, [53, 64], [0, 1]), fontSize: 22, color: C.muted}}>Gerenciador de Anúncios</div>
    <EvidenceLens kind="reach" x={727} y={1085} size={238} at={30}/>
    <div style={{position: 'absolute', left: 715, top: 1360, opacity: tween(f, [53, 68], [0, 1]), translate: `0 ${tween(f, [53, 73], [80, 0])}px`}}><FilmPlane x={0} y={0} width={235} height={305} radius={115}/><PlayToken x={146} y={242} size={80}/></div>
  </Base>;
};

export const Impressions = () => {
  const f = useCurrentFrame();
  const p = tween(f, [0, 25], [0, 1]);
  const x = 92, y = 635 + tween(f, [10, 35], [20, 0]), w = 610;
  const {cx, cy} = cropDimensions('impressions', w);
  return <Base color={C.blue}>
    <OrbitField x={560} y={1180} radius={625} color={C.cyan} opacity={.22} progress={tween(f,[0,40],[.25,1])}/>
    <Eyebrow light>IMPRESSÕES · DOCUMENTADAS</Eyebrow>
    <div style={{position: 'absolute', left: 94, top: 300}}><MaskLine at={7} size={87}>O anúncio</MaskLine><MaskLine at={16} size={87}>continuou circulando.</MaskLine></div>
    <div style={{position: 'absolute', left: 825, top: 665, width: 185, height: 410, border: '2px solid #FFFFFF35', borderRadius: 95, rotate: '12deg', opacity: tween(f, [8, 24], [0, 1]), translate: `0 ${tween(f, [10, 80], [100, -15])}px`}} />
    <div style={{position: 'absolute', left: 785, top: 710, width: 185, height: 410, border: '2px solid #FFFFFF65', borderRadius: 95, rotate: '5deg', opacity: tween(f, [10, 24], [0, 1]), translate: `0 ${tween(f, [15, 90], [120, 0])}px`}} />
    <FilmPlane x={790} y={860} width={165} height={293} radius={92} rotate={-7} opacity={tween(f, [12, 27], [0, 1])}/>
    <EvidenceLens kind="impressions" x={715} y={550} size={230} at={15} light/>
    <Evidence kind="impressions" x={x} y={y} width={w} rotate={tween(f, [0, 22], [9, -3])} yaw={tween(f, [0, 25], [19, 0])} mark={tween(f, [14, 32], [0, 1])}/>
    <div style={{position: 'absolute', left: 96, top: 1145, fontSize: 19, letterSpacing: 2, color: '#E6EEFF', opacity: tween(f, [31, 45], [0, 1])}}>REGISTRO ORIGINAL · GERENCIADOR DE ANÚNCIOS</div>
    <Path d={`M${x + cx + 130} ${y + cy + 45}C740 1080 960 1080 960 1260H930`} color={C.cyan} width={4} progress={tween(f, [27, 51], [0, 1])}/>
    <div style={{position: 'absolute', left: 60, top: 1230, width: 960}}><Metric value="20.981" at={14} size={238} color="#FFF"/></div>
    <div style={{position: 'absolute', top: 1530, width: 1080, textAlign: 'center', fontSize: 57, fontWeight: 800, letterSpacing: -2, opacity: tween(f, [52, 65], [0, 1])}}>impressões</div>
    <div style={{position: 'absolute', top: 1620, width: 1080, textAlign: 'center', fontSize: 29, color: '#D8E7FF', opacity: tween(f, [59, 72], [0, 1])}}>Exibições do anúncio.</div>
  </Base>;
};
