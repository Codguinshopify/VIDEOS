import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Base, C, CityPlane, Corners, FilmPlane, MaskLine, Path, PlayToken, tween} from './system';
import {BUSINESS_NAME} from '../case';
import {OrbitField} from './ParkDesign';

export const Recognition = ({duration=102}) => {
  const f = useCurrentFrame();
  const p = tween(f, [duration-40, duration-14], [0, 1]);
  const x = 96 * p, y = 650 * p, w = 1080 - 590 * p, h = 1920 - 1049 * p;
  const color = C.ink;
  return <Base>
    <OrbitField x={540+p*250} y={970+p*170} radius={510-p*150} progress={tween(f,[0,25],[.42,1])} opacity={.3}/>
    <div style={{position: 'absolute', width: 660, height: 660, left: 530, top: 910, borderRadius: '50%', background: '#E0E9FF', scale: tween(f, [80, 112], [.5, 1]), opacity: p}} />
    <CityPlane x={420} y={950} width={750} rotate={9} opacity={p} />
    <div style={{position:'absolute',inset:0}}>
    <FilmPlane x={x} y={y} width={w} height={h} radius={36 * p} rotate={-7 * p} yaw={-10 * p} shadow={p > .02} camera={(1-p)*tween(f,[0,16],[1.92,1.8])+p} cameraX={-(1-p)*tween(f,[10,40],[0,140])} cameraY={80*(1-p)} clipPath={`inset(${520*(1-p)}px ${90*(1-p)}px ${500*(1-p)}px ${90*(1-p)}px round ${450*(1-p)+36*p}px)`}>
      <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{position: 'absolute', inset: 0}}><path d="M45 200V85Q45 45 85 45H200 M880 45H995Q1035 45 1035 85V200 M1035 1720V1835Q1035 1875 995 1875H880 M200 1875H85Q45 1875 45 1835V1720" fill="none" stroke="#FFFFFFAA" strokeWidth={7} pathLength={1} strokeDasharray={1} strokeDashoffset={1-tween(f,[0,17],[.32,1])}/></svg>
    </FilmPlane>
    </div>
    <div style={{position: 'absolute', left: 94, top: 205 - 20 * p, color, width: 910}}>
      <div style={{scale:tween(f,[0,14],[1.18,1]),translate:`${tween(f,[0,14],[-15,0])}px 0`,transformOrigin:'0 0'}}><MaskLine size={90} at={-24}>Você chegou</MaskLine></div>
      <MaskLine size={90} at={2}>a ver esse vídeo</MaskLine>
      <MaskLine size={82} at={19} color={C.blue}>em Clevelândia?</MaskLine>
    </div>
    <Path d="M98 565C235 584 437 581 580 560" color={C.blue} width={5} progress={tween(f,[0,16],[.24,1])} opacity={tween(f,[48,62],[1,0])}/>
    <PlayToken x={490} y={1400} size={106} progress={tween(f, [duration-27, duration-11], [0, 1])} rotate={-7} />
    <Path d="M540 1450C760 1510 1000 1430 950 1200" progress={tween(f, [duration-12, duration+10], [0, 1])} width={5} />
    <div style={{position: 'absolute', left: 96, top: 1620, fontSize: 25, color: C.muted, opacity: p, letterSpacing: .5}}>{BUSINESS_NAME} · anúncio original</div>
  </Base>;
};
