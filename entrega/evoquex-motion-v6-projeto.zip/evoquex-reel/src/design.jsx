import {BUSINESS_NAME, BUSINESS_SHORT} from './case';
import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';
import assets from './assets.json';

export const C = {navy: '#061529', deep: '#020B17', cyan: '#36D6F6', white: '#F5F8FF', soft: '#A7B8CC'};
export const font = "'Open Sans', sans-serif";
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'};
export const ease = Easing.bezier(0.16, 1, 0.3, 1);

export const Stage = ({children, enter = true}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{fontFamily: font, color: C.white, background: C.navy, overflow: 'hidden', opacity: enter ? interpolate(f, [0, 12], [0, 1], clamp) : 1}}>{children}</AbsoluteFill>;
};

export const Label = ({children, style = {}}) => <div style={{fontSize: 29, fontWeight: 600, letterSpacing: 3, color: C.soft, lineHeight: 1.4, ...style}}>{children}</div>;

export const Rise = ({children, delay = 0, style = {}}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const progress = spring({frame: f - delay, fps, config: {damping: 24, stiffness: 120, mass: 1}, durationInFrames: 30});
  return <div style={{overflow: 'hidden', ...style}}><div style={{translate: `0 ${(1 - progress) * 108}%`, opacity: interpolate(f - delay, [0, 9], [0, 1], clamp)}}>{children}</div></div>;
};

export const Headline = ({children, style = {}}) => <div data-review="headline" style={{fontSize: 88, fontWeight: 700, letterSpacing: -4.3, lineHeight: 1.09, ...style}}>{children}</div>;

export const MissingMedia = ({label, style = {}}) => <AbsoluteFill style={{background: '#14233A', alignItems: 'center', justifyContent: 'center', padding: 70, textAlign: 'center', fontFamily: font, color: C.soft, ...style}}><div><Label style={{color: C.cyan, fontSize: 25}}>PRÉVIA DE MONTAGEM</Label><div style={{fontSize: 42, marginTop: 24, fontWeight: 600}}>{label}</div><div style={{fontSize: 27, marginTop: 20}}>Aguardando o arquivo original</div></div></AbsoluteFill>;

export const CampaignFilm = ({trimBefore = 0, volume = 0, style = {}}) => {
  const {fps} = useVideoConfig();
  return <AbsoluteFill style={style}>{assets.video ? <Video name={`Anúncio original da ${BUSINESS_SHORT}`} src={staticFile('assets/DANYS.mp4')} trimBefore={trimBefore} volume={volume} premountFor={fps} objectFit="cover" style={{width: '100%', height: '100%'}} /> : <MissingMedia label={`Vídeo original da ${BUSINESS_NAME}`} />}</AbsoluteFill>;
};

export const City = ({style = {}}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{overflow: 'hidden', ...style}}>{assets.city ? <Img src={staticFile('assets/clevelandia.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', scale: interpolate(f, [0, 240], [1.02, 1.075], clamp), objectPosition: '50% 48%'}} /> : <MissingMedia label="Fotografia aérea real de Clevelândia" />}</AbsoluteFill>;
};

export const OriginalResults = () => assets.results ? <Img src={staticFile('assets/resultados.jpg')} style={{width: '100%', height: 'auto', position: 'absolute', top: -650, left: 0}} /> : <MissingMedia label="Print original dos resultados" />;

export const Count = ({value, start = 0, end = 36}) => {
  const f = useCurrentFrame();
  const n = Math.round(interpolate(f, [start, end], [0, value], {...clamp, easing: ease}));
  return <>{new Intl.NumberFormat('pt-BR').format(n)}</>;
};

export const AccentLine = ({style = {}, delay = 0}) => {
  const f = useCurrentFrame();
  return <div style={{height: 4, width: 110, background: C.cyan, scale: `${interpolate(f - delay, [0, 26], [0, 1], {...clamp, easing: ease})} 1`, transformOrigin: 'left', ...style}} />;
};
