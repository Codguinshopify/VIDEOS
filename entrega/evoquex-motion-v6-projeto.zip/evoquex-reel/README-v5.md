# Evoquex — evolução narrada V5

Reel de **25,8 segundos, 1080 × 1920, 30 fps**, com narração neural feminina brasileira real. Mantém os seis componentes e a identidade Evoquex da versão aprovada; o projeto foi evoluído, preservando os materiais e a estrutura narrativa.

## Direção visual

A referência Park foi examinada em sequências de frames de toda a duração de 64,70 s, antes das alterações. A análise e as técnicas adaptadas estão em analise-referencia-park.md. A nova abertura possui tipografia cinética, recorte circular do anúncio, quatro órbitas em velocidades diferentes, traço animado e câmera que acompanha a pessoa. O portal se transforma no cartão em perspectiva e conecta a fotografia real da cidade.

Os anéis reaparecem como motivo compartilhado nas seis cenas. Os resultados ganham lentes circulares sobre os pixels do documento original, linhas de chamada, profundidade e caracteres revelados por máscaras. O trecho comercial conserva a rede vetorial conceitual, tipografia em planos e estabelecimento que se transforma no CTA. As revelações variam entre círculo, elipse e diagonal, em 9–12 frames, com sobreposição contínua. As animações usam frames, curvas e molas, sem relógio ou CSS keyframes.

Não foram copiados marca, depoimentos, gráficos financeiros nem trilha da referência. A rede de pessoas é um elemento conceitual; não representa usuários identificados ou uma base de dados real. A paleta, as fontes e os componentes aprovados permanecem.

## Case e dados

O nome canônico é **Danny’s Presentes**, em src/case.jsx. Textos, títulos de cenas e roteiro foram revisados. O nome do arquivo original DANYS.mp4 é histórico e não aparece como nome da empresa.

- **13.064 pessoas alcançadas**, coluna Alcance do comprovante.
- **20.981 impressões**, coluna Impressões do mesmo documento.

Impressões não são apresentadas como visualizações. Os três materiais originais conservam os bytes, verificados por SHA-256. O anúncio tem 5,06 s; as cenas posteriores aproveitam diferentes trechos e o último frame. A fotografia aérea tem 600 × 337 pixels, limitando ampliações. O comprovante fotografado mantém sua inclinação e textura, sem recriação de interface.

## Narração e sound design

Seis WAVs reais em public/voiceover/, gerados **antes** de determinar o timing, com Kokoro-ONNX 0.6.1 e voz feminina brasileira pf_dora. Os pesos Kokoro-82M v1.0 usam Apache-2.0; o engine, MIT. Licenças, hashes, origem e roteiro acompanham audio-sources/voice/. A entrada fonética Dânis corrige a acentuação da marca na síntese; o texto escrito permanece Danny’s Presentes. Não é um depoimento: é uma narração sintética do case e da chamada comercial.

A música autoral em 108 BPM mantém a instrumentação aprovada, renderizada com FluidSynth e GeneralUser GS, cuja licença permite criação musical privada e comercial. Whooshes, traços de papel e impactos são arquivos sonoros efetivamente produzidos, sincronizados às máscaras, ao portal e às métricas. Nenhuma música da referência foi copiada.

Automação por frase: música em .22 durante a fala e .68 nas pausas; ataque de .125 s e retorno de .22 s. O áudio de fala/ambiente do anúncio foi silenciado na composição para evitar duas vozes. A normalização final visa −16 LUFS / −1,5 dBTP, com limites conferidos no AAC exportado. O mix pronto está em public/assets/evoquex-narrado.wav; os stems de voz, música e efeitos também estão incluídos. Renderizar não exige modelo, conexão nem serviço de voz.

## Renderizar e editar

Node 24.19.0, Remotion 4.0.535, React 19.3.1, Chromium em /usr/bin/chromium e FFmpeg 7.1.5. Nenhuma dependência JavaScript adicional foi instalada nesta evolução.

```sh
export npm_config_cache=/workspace/.cache/npm
export XDG_CONFIG_HOME=/workspace/.cache/xdg-config
export XDG_CACHE_HOME=/workspace/.cache/xdg-cache
npm ci --no-audit --no-fund
npm run studio
```

No ambiente preparado, npm ci --offline --no-audit --no-fund usa o cache. Use o checkout existente; não crie worktrees. Studio é um processo que precisa reiniciar após restauração do ambiente. Em outra máquina, ajuste o caminho do Chromium e as pastas de cache.

```sh
npm run draft
npm run render
python scripts/validate-output.py out/evoquex-motion-v5.mp4
python scripts/audit-audio.py out/evoquex-motion-v5.mp4
python scripts/review-video-v3.py out/evoquex-motion-v5.mp4
python scripts/create-delivery.py --v5
```

Composição principal: EvoquexPremium. Cenas registradas individualmente na pasta Motion-V3 do Studio. O nome da pasta foi preservado para manter a continuidade do projeto. Scripts de V1/V2 e documentos das versões anteriores permanecem para comparação; a composição principal deste pacote é V5.

## Timing guiado pela voz

| Tempo | Cena |
| --- | --- |
| 0–3,4 s | Pergunta, portal circular e anúncio real |
| 3,4–6,6 s | Danny’s Presentes e Clevelândia |
| 6,6–11 s | 13.064 pessoas alcançadas, comprovante e lupa |
| 11–15,1 s | 20.981 impressões, documento e lente |
| 15,1–20,1 s | Divulgação estratégica, tipografia e distribuição |
| 20,1–25,8 s | Pergunta comercial e CTA Evoquex |

A duração é lida de src/narration-timing.json. O arquivo registra também a duração medida de cada WAV. Alterar o roteiro exige gerar/medir a voz antes de ajustar cenas e mixagem.

## Regeneração opcional do áudio

Para refazer apenas música e mixagem: Python, NumPy, FFmpeg e libfluidsynth; execute npm run audio-narrado. O script verifica o SHA-256 do banco GeneralUser GS de um commit fixo. Licença integral em audio-sources/GeneralUser-GS-LICENSE.txt. EVOQUEX_AUDIO_CACHE permite guardar o banco fora do projeto.

Para refazer a voz, opcionalmente, use um venv Python 3.12 com as versões de audio-sources/voice/requirements.lock.txt. Os modelos não estão no ZIP: não são necessários para renderizar os WAVs já produzidos. Baixe os dois arquivos oficiais, mantendo TLS e conferindo os hashes de provenance.json:

- https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/kokoro-v1.0.onnx
- https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/voices-v1.0.bin

Coloque-os em uma pasta, defina EVOQUEX_VOICE_MODELS com esse caminho, execute scripts/create-narration.py com o Python do venv e depois npm run audio-narrado. O gerador também verifica os hashes. O script de ASR é uma conferência opcional independente, usando Whisper base oficial, fora do projeto; não é dependência de renderização.

## Revisão e limitações

A prévia foi renderizada e examinada ao longo de toda a duração, nas transições e na abertura. Foram corrigidos o recorte da legenda embutida durante o portal e o último dígito na lente de impressões. A documentação da revisão final e os relatórios ficam em review/.

A interface não oferece reprodução sonora ao agente. A conferência usa sequências de imagens, decodificação integral, níveis, picos, separação de stems, correlação com o mix e reconhecimento independente de fala. Isso não substitui a avaliação auditiva humana de timbre, entonação ou pronúncia de nomes próprios. A voz é neural local; essa limitação é explicitada, sem afirmar audição subjetiva.
