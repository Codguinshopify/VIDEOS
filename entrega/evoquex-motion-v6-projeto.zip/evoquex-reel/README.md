# Evoquex — V6 / nova direção de motion graphics

**Estado desta entrega: prévia visual e sonora em Full HD, com locução natural pendente.** A voz sintética pf_dora/Kokoro rejeitada pelo usuário não é utilizada na V6. Não se apresenta a ausência de locução como uma substituição concluída.

Nova composição: **EvoquexRebuilt**, 1080 × 1920, 30 fps, 930 frames / 31 segundos na prévia. A V5 continua registrada como EvoquexPremium e seus arquivos anteriores estão preservados. O trabalho atual permite nova direção, sem limitação à sequência de seis cartões anterior.

## Direção e execução

' Da tela à cidade ': nove capítulos e estados internos de tipografia, imagem e símbolos. Abertura desde o primeiro frame com vídeo em recorte diagonal, palavras em escala, faixa gráfica, traços e play que se transforma em pin. O pin conduz à cidade real; um presente desenhado apresenta a marca. O documento migra para uma faixa numérica de alcance; silhuetas entram em profundidade. O olho representa exibições e dá lugar à composição de impressões. Um split separa as definições; o comprovante assume o primeiro plano. Play vira balão e a palavra 'gente' entra na própria forma do CTA.

Tipografia por palavra e por dígito, curvas rápidas e molas, desenho de caminhos SVG, morph com vértices correspondentes, máscaras circulares/diagonais/laterais/verticais, overlap de oito frames, layouts claros/azuis/ciano/escuros, câmera e parallax, fotografia e filmagem reais em planos diferentes. Pausas de leitura são mantidas nos indicadores e definições. Não são usados CSS keyframes, relógio do navegador ou bibliotecas JavaScript novas.

A nova Park de 42,61 s e as anteriores Park/Oto foram examinadas em sequências de toda a duração antes de editar. Técnicas e aplicação estão em direcao-criativa-v6.md. Os vídeos de referência não são dependências nem foram redistribuídos neste pacote.

## Informações preservadas

Danny’s Presentes, com grafia canônica em src/case.jsx. Clevelândia, PR. **13.064 pessoas alcançadas** e **20.981 impressões**, documentados nas colunas correspondentes do print real. Não são visualizações, vendas, receita, evolução temporal ou testemunhos de clientes. Silhuetas, olho, presente, caminhos e balão são símbolos autorais, não rastreamento de pessoas reais ou uma interface de plataforma.

DANYS.mp4, clevelandia.jpg e resultados.jpg mantêm os bytes originais, verificados por SHA-256. O vídeo disponível tem 5,06 segundos, com câmera em movimento e algumas partes desfocadas; foram selecionados quadros mais nítidos. A foto aérea tem 600 × 337 pixels. Esses materiais limitam ampliações e variedade de filmagem; não foram fabricadas novas cenas.

## Áudio atual e locução pendente

Música autoral nova em 128 BPM: baixo/synth, plucks, percussão e variações de arranjo. Efeitos autorais reais de impacto, deslocamento e acento, sincronizados aos eventos de composição; WAVs e stems em public/audio-v6/. Instrumentos GeneralUser GS / FluidSynth, com licença comercial para criação musical, origem e SHA-256 preservados em audio-sources/. Não são usadas músicas das referências. O áudio original da filmagem está silenciado.

A prévia tem trilha/efeitos e **não tem nova narração**. ElevenLabs com plano comercial foi escolhido pelo usuário. Falta a credencial ELEVENLABS_API_KEY no campo seguro criado nas configurações do ambiente. A tentativa de acesso a api.elevenlabs.io também recebeu bloqueio 403 do proxy; o acesso precisa ser reavaliado após aplicar a configuração. Não se contorna essa restrição mudando a política irrestrita existente ou desativando TLS.

scripts/elevenlabs-v6.py é a integração preparada: exige credencial, consulta vozes reais da conta, procura voz feminina brasileira ou respeita EVOQUEX_ELEVENLABS_VOICE_ID configurado, usa eleven_multilingual_v2 com contexto de frases, gera MP3s reais e mede suas durações. A integração autenticada ainda não foi executada. Se a conta não tiver voz nativa adequada, deve-se adicionar uma voz licenciada da biblioteca. Não existem IDs ou arquivos de voz fictícios no render atual.

Quando o acesso estiver disponível, gerar a voz, reconstruir o mix, revisar o timing e renderizar de novo é necessário. O roteiro está em src/motion-v6/timeline.json; o CTA falado deve terminar 'Quer fazer algo assim para a sua empresa? Conversa com a gente.' A edição não termina com uma chamada institucional para a Evoquex.

O mix dispõe de automação de música por frase (.18 durante a voz, .68 nas pausas), original a zero, fades e stems separados. **A automação de fala só será executada e validada quando existirem os MP3s reais.** As durações medidas atualizam a timeline; SceneClock mantém a proporção das animações e os efeitos acompanham os mesmos eventos. O timing final ainda exige revisão audiovisual.

## Trabalhar e renderizar

Node 24.19.0, Remotion 4.0.535, React 19.3.1, Chromium /usr/bin/chromium, FFmpeg 7.1.5. Dependências JavaScript iguais ao lockfile existente.

```sh
export npm_config_cache=/workspace/.cache/npm
export XDG_CONFIG_HOME=/workspace/.cache/xdg-config
export XDG_CACHE_HOME=/workspace/.cache/xdg-cache
npm ci --no-audit --no-fund
npm run studio
npm run draft
npm run render
```

npm run render exporta **out/evoquex-motion-v6-previa.mp4**, sem fingir conclusão vocal. No ambiente preparado, npm ci --offline --no-audit --no-fund usa o cache. Ajuste o caminho do Chromium em outras máquinas. Use o checkout existente; não crie worktrees para setup. Studio precisa reiniciar após restauração do ambiente; processos não sobrevivem ao snapshot.

```sh
python scripts/validate-v6.py out/evoquex-motion-v6-previa.mp4
python scripts/review-video-v6.py out/evoquex-motion-v6-previa.mp4
node scripts/review-v6.mjs 0 24 45 239 310 450 540 650 745 890
```

A pasta Motion-V6 registra nove cenas isoladas no timing de direção. A composição principal usa o JSON e retiming por SceneClock. Cada sequência foi escrita separadamente, sem gerar a timeline por um loop genérico. As versões antigas mantêm seus componentes e áudios históricos, sem serem fallback na V6.

Depois de configurar ElevenLabs com acesso real:

```sh
python scripts/elevenlabs-v6.py --check
npm run voice-v6
npm run audio-v6
npm run render-final
```

render-final bloqueia exportação definitiva enquanto não houver nova voz gerada. Gerar áudio consome créditos do serviço comercial escolhido; a credencial deve permanecer nas configurações seguras, fora de arquivos e ZIPs. Para regenerar só a música/efeitos, Python, NumPy, FFmpeg e libfluidsynth; o script verifica o banco instrumental de commit fixo antes de usar.

## Revisão

Primeira prévia em meia resolução renderizada e examinada ao longo da duração. Corrigidos contraste, largura das legendas, seleção de frames, pausa de leitura, transição sem conteúdo e integração tipográfica do CTA. A prévia corrigida em Full HD recebe decodificação integral, conferência de áudio por níveis/picos/correlação e inspeção visual por amostras a 4 fps, hook quadro a quadro, oito passagens e estados internos.

A interface não permite escuta ao agente. Não foi feita avaliação auditiva humana de voz, trilha ou efeitos, e nenhum relatório técnico substitui essa avaliação. A tarefa completa — especialmente narração natural e aprovação sonora — permanece pendente até existir locução adequada e revisão auditiva. Os relatórios em review/ registram o estado verdadeiro da entrega.
