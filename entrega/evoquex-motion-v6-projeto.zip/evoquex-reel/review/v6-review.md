# V6 — revisão da prévia reconstruída

Estado: nova direção visual e trilha/efeitos renderizados; locução natural e aprovação auditiva ainda pendentes. Não se apresenta esta prévia como versão definitiva.

Referências: nova Park (1) de 42,61 s, Park anterior de 64,71 s e Oto de 27,77 s. Sequências completas examinadas a 2 fps, além de decodificação integral de vídeo e áudio. Não há audição subjetiva disponível.

| Técnica observada | Construção efetiva no Remotion |
| --- | --- |
| Nova Park: símbolos encadeados 0–7 e 12–18 s | Play muda para pin e chat por interpolação de vértices; presentes, pessoas, olho, pin e check desenhados por comprimento |
| Nova Park: pílulas e inversões 21–25/28–33 s | Faixa numérica sobre fundo ciano, composições claras/azuis/escuras e balão que recebe palavra no CTA |
| Nova Park: substituição de palavras | Hook troca ESSE ANÚNCIO por VOCÊ VIU; definições se recompõem em Métricas diferentes; CTA transforma pergunta em conversa |
| Park anterior: documentos e foco | Recortes do print original saem do primeiro plano e fundamentam alcance/impressões; print completo retorna como prova |
| Oto: mudança de escala e planos | Documento muda posição/escala/rotação, vídeo em faixas, silhuetas em perspectiva e palavras/dígitos com blur durante deslocamento |

Nova estrutura: nove componentes, vários estados internos e oito passagens com overlap/máscaras de oito frames. Story: anúncio → Clevelândia → Danny’s Presentes → pessoas alcançadas → exibições → definições → documento → projeto → conversa. Não conserva os seis cartões da V5. Não cria vendas, gráficos de crescimento, receita, depoimentos ou interfaces fictícias.

Correções após primeira prévia: contraste de textos em ciano/creme; largura de legendas; seleção de frame 105 para brinquedos e 37 para figura humana, substituindo captura desfocada; enquadramento mais curto no hook; ampliação da leitura de definições para quatro segundos; documento presente durante a transição ao alcance e à prova; palavra gente integrada no balão. Removida frase que poderia sugerir alcance da cidade inteira, mantendo alcance local documentado.

Prévia corrigida examinada em 124 amostras da duração, 34 quadros do hook, 56 quadros das oito passagens, 28 estados internos e 6 telas de telefone. Comparação de seis momentos com V5 em v6-comparison.jpg. As cinco folhas da duração, duas de passagens, duas do hook e folha de estados foram visualmente inspecionadas.

Dados conferidos: Danny’s Presentes; 13.064 pessoas alcançadas; 20.981 impressões/exibições. Nome canônico em src/case.jsx. As três mídias originais conferem por SHA-256.

MP4: 930 frames, 1080 × 1920, 30 fps, H.264/yuv420p/BT.709 tv, AAC estéreo 48 kHz, contêiner 31.019 s. Decodificação integral passou. SHA-256: 3ab85678c36184e2dcf2652130dad179fef2b7e0117d06a82cf754131ecb1183. Som: -16.48 LUFS, pico verdadeiro -1.73 dBTP, zero clipping e correlação de 0.999806 com o mix real a atraso zero. Música autoral nova de 128 BPM e 26 eventos autorais sincronizados, com stems/licença; não copia música das referências.

Locução: usuário escolheu ElevenLabs com plano comercial. Requisito seguro ELEVENLABS_API_KEY salvo no rascunho, sem binding disponível. A API retornou bloqueio 403 do proxy antes da aplicação da configuração. A geração autenticada não ocorreu. A voz Kokoro rejeitada não é usada nem como fallback. Mix atual é instrumental/efeitos, com áudio original da filmagem silenciado. A integração para medir e ajustar timing, reconstruir o mix e renderizar com voz está preparada, ainda sem validação autenticada.

Limitações que impedem aprovação final: nova voz ausente e audição humana não disponível ao agente. A análise técnica não aprova naturalidade vocal. São necessários acesso real ao serviço e revisão auditiva da locução/mixagem; depois, nova revisão de timing e exportação definitiva. Nenhum relatório alega essas etapas como concluídas.
