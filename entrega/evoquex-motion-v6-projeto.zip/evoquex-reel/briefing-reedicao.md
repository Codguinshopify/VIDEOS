> Atualização de grafia: o nome correto é **Danny’s Presentes**. O texto recebido abaixo é preservado como histórico; o nome corrigido prevalece no projeto.

# PROMPT PROFISSIONAL — REEDIÇÃO DO REEL COM REFERÊNCIA DE MOTION DESIGN

Quero que você refaça a edição do vídeo de prova social da Evoquex, utilizando o vídeo de referência que estou anexando como **referência direta de linguagem visual, técnicas de edição, motion design, ritmo, animações, composição e acabamento profissional**.

A versão anterior ficou fraca, simples e muito próxima de uma apresentação de slides. Não quero apenas textos aparecendo sobre o vídeo, imagens entrando na tela e números animados. Quero uma peça publicitária com edição elaborada, movimento constante quando fizer sentido, composição visual criativa e acabamento de alto nível.

## 1. Analise o vídeo de referência antes de editar

Assista ao vídeo de referência inteiro e estude como ele foi produzido.

Identifique e utilize como inspiração as técnicas visuais que realmente aparecem nele, incluindo, conforme aplicável:

- Ritmo de edição e duração dos planos.
- Motion typography e animação de palavras.
- Transições entre cenas e elementos.
- Tracking, máscaras, recortes e sobreposições.
- Zooms, movimentos de câmera e mudanças de escala.
- Composição em camadas e profundidade.
- Elementos gráficos animados e integração com as imagens.
- Sincronização entre movimento, áudio e narrativa.
- Tratamento de cor, contraste, iluminação e textura.
- Técnicas de destaque visual e direcionamento do olhar.

Não se limite a descrever essas técnicas. **Reproduza, adaptando ao projeto, as habilidades de edição e motion design que tornam o vídeo de referência visualmente interessante.**

Não copie elementos que não façam sentido para o contexto. O objetivo é alcançar um nível de execução semelhante, respeitando a identidade do case e a mensagem comercial.

## 2. Entenda a função de cada arquivo

Estou fornecendo três materiais principais:

**A. Vídeo original da divulgação da Dany’s Presentes**

Este é o conteúdo principal do Reel. Utilize trechos reais, principalmente o início, para que as pessoas reconheçam a publicação que circulou em Clevelândia.

O vídeo deve continuar sendo o protagonista. Escolha os cortes, enquadramentos e momentos que melhor funcionem na narrativa.

**B. Print dos resultados da campanha**

Utilize apenas como prova documental e referência para os dados.

Não coloque o print inteiro na tela como se fosse um slide. Integre os indicadores à edição por meio de recortes, aproximações, máscaras, enquadramentos e composições animadas.

Por exemplo, a edição pode aproximar uma região específica do print, destacar o indicador relevante e fazer a transição desse elemento para um número em tipografia grande. O print deve funcionar como origem visual da informação, e não como uma imagem estática ocupando a tela inteira.

Não recrie a interface nem altere os dados do documento original.

**C. Fotografia aérea de Clevelândia**

Utilize como elemento de contextualização local, não como uma cena estática prolongada.

Explore movimentos de câmera, aproximações, profundidade, máscaras e transições integradas à composição, conforme a qualidade da imagem permitir.

A foto deve reforçar a ideia de que a campanha foi direcionada à população local. Não precisa aparecer inteira nem ocupar uma cena exclusiva.

## 3. Conceito criativo

A narrativa central é:

**“Você chegou a ver esse vídeo? Nós fizemos essa divulgação alcançar mais de 13 mil pessoas em Clevelândia.”**

O Reel deve mostrar um trabalho real, revelar o alcance conquistado e transformar essa evidência em uma oportunidade para outros empresários.

Quero uma peça que gere curiosidade, demonstre capacidade técnica e desperte o pensamento:

“Se eles fizeram isso para uma empresa local, poderiam fazer pela minha também.”

Não quero um vídeo institucional genérico sobre marketing digital. Quero uma prova social com uma história específica, imagens reais, métricas verificáveis e um CTA comercial.

## 4. Direção narrativa sugerida

Desenvolva a melhor sequência a partir do material disponível, usando a estrutura abaixo como orientação, não como uma sequência rígida de slides.

### Abertura — reconhecimento

Comece com o vídeo original da Dany’s Presentes.

Texto sugerido:

**“Você chegou a ver esse vídeo em Clevelândia?”**

A abertura precisa ter impacto nos primeiros segundos. Use técnicas de edição e motion inspiradas na referência para integrar a frase ao próprio vídeo, com boa hierarquia tipográfica e animação precisa.

Evite uma tela de título antes de mostrar o conteúdo real.

### Revelação — alcance local

Continue com o vídeo original e introduza a fotografia de Clevelândia de forma integrada, se isso ajudar a narrativa.

Texto sugerido:

**“Mais de 13 mil pessoas alcançadas na cidade.”**

A revelação deve acontecer por meio da edição, e não pela simples aparição de uma frase sobre uma foto.

### Prova — números reais

Utilize o print de forma parcial e estratégica para fundamentar os resultados.

Destaque:

**13.064 pessoas alcançadas**

**20 mil visualizações**

Use motion typography, recortes animados, transformações gráficas e transições coerentes com o vídeo de referência.

A animação pode transformar os dados documentados em elementos gráficos de maior escala, mas não deve sugerir que o print contém métricas diferentes das reais.

O Gerenciador de Anúncios registra 20.981 impressões. Não confunda impressões com visualizações. Utilize “20 mil visualizações” somente como a métrica real correspondente no material de campanha; se não houver comprovação dessa métrica nos arquivos fornecidos, não a apresente como dado confirmado pelo print.

### Conexão comercial

Faça a narrativa sair do resultado da Dany’s Presentes e chegar à realidade dos empresários de Clevelândia.

Texto sugerido:

**“Sua empresa também pode alcançar mais pessoas.”**

A frase deve surgir como parte da composição visual, não como legenda genérica sobre uma imagem parada.

### Encerramento — CTA

Finalize com:

**“Vamos trabalhar a divulgação da sua empresa?”**

**“Fale com a Evoquex.”**

Crie um encerramento visualmente forte, com boa legibilidade e tempo suficiente para a leitura.

## 5. Nível de edição esperado

Quero que a qualidade do motion seja perceptível ao assistir ao vídeo.

A edição deve demonstrar domínio de:
- Composição e hierarquia visual.
- Motion typography.
- Animação de elementos em diferentes profundidades.
- Transições personalizadas.
- Sincronização de cortes e animações.
- Manipulação de escala e enquadramento.
- Tratamento de cor consistente.
- Sound design integrado à imagem.
- Ritmo narrativo e retenção de atenção.

Use essas técnicas com intenção. Não quero efeitos aleatórios apenas para deixar o vídeo movimentado.

**O movimento deve fazer parte da narrativa.** As imagens, as palavras, os números e os elementos gráficos precisam parecer componentes de uma mesma peça publicitária.

## 6. Restrições importantes

- Não transforme o vídeo em uma apresentação de slides.
- Não coloque a fotografia aérea inteira em uma cena estática apenas para preencher tempo.
- Não mostre o print inteiro por vários segundos sem tratamento criativo.
- Não utilize templates genéricos de apresentação.
- Não substitua o material original por imagens genéricas de marketing.
- Não invente depoimentos, vendas, conversões ou resultados comerciais.
- Não distorça os dados para aumentar o impacto.
- Não sobrecarregue a tela com textos explicativos.
- Não utilize efeitos que prejudiquem a legibilidade ou a compreensão.
- Não copie literalmente o conteúdo do vídeo de referência; use suas técnicas de execução e linguagem visual adaptadas ao case.

## 7. Execução com Remotion

Utilize o Remotion para implementar a edição, com animações controladas por frames, componentes reutilizáveis e composição profissional.

Antes de editar, examine o projeto existente e identifique os arquivos corretos. Aproveite o que for útil, mas não preserve decisões visuais da versão anterior apenas por já estarem implementadas.

Assista ao vídeo de referência, planeje a nova edição, implemente as cenas e renderize o resultado final.

Depois da renderização, revise o MP4 e corrija problemas de timing, enquadramento, sobreposição, legibilidade, transições e áudio.

Entregue o vídeo final em MP4, vertical 9:16, 1080 × 1920, pronto para Instagram Reels e adequado para um possível uso em Meta Ads.

**Não encerre a tarefa com uma explicação ou apenas com código. O objetivo é entregar o vídeo final renderizado, visualmente revisado e com uma execução que realmente reflita as habilidades de edição e motion design do vídeo de referência.**