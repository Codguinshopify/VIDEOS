# Evoquex — reedição com motion design (V2)

Reel vertical de 28 segundos, 1080 × 1920, 30 fps, baseado no case real da Danny’s Presentes em Clevelândia–PR.

## Direção da reedição

A referência foi estudada ao longo de toda a duração. A versão 2 adapta a linguagem de tipografia por palavras, cartões em perspectiva, foco/desfoque, carrossel, mudanças de escala e setas desenhadas. O anúncio começa em tela cheia e recua para um cartão; a foto da cidade entra por recorte circular e movimento de câmera. Cada indicador nasce de um enquadramento do print original, com marcação que acompanha o documento, antes de se transformar em tipografia de grande escala.

O vídeo real permanece presente na abertura, nas composições das métricas, no carrossel que conecta o case ao empresário e no CTA. O encerramento usa uma chamada em formato de conversa. Não há reconstrução de interfaces, mensagens fictícias de clientes ou uso do logotipo/áudio da referência.

Os dígitos animados usam apenas os caracteres dos valores documentados, com máscaras e repetição tipográfica. Não passam por números aleatórios ou resultados maiores que os reais.

## Dados apresentados

- **13.064 pessoas alcançadas.**
- **20.981 impressões.**

Não foi fornecido um registro equivalente de visualizações, por isso a V2 não converte impressões em visualizações nem apresenta 20 mil visualizações como resultado comprovado pelo print. R$ 50 em mídia e dois dias de divulgação são informações do briefing.

## Arquivos principais

- `src/motion-v2/`: composição reconstruída, recursos de câmera/tipografia e nove sequências conectadas.
- `src/Root.jsx`: registro da composição principal `EvoquexMotion`, das cenas da V2 e das composições anteriores preservadas para comparação.
- `public/assets/DANYS.mp4`: trecho real recebido, 5,06 segundos, 1080 × 1920, 30 fps. A montagem reutiliza esse trecho em diferentes enquadramentos; o áudio original aparece na abertura.
- `public/assets/clevelandia.jpg` e `resultados.jpg`: imagens originais copiadas sem alteração dos bytes. Os recortes e marcações são feitos na composição.
- `public/assets/evoquex-motion.wav`: trilha/sound design autorais, sincronizados com os cortes, marcações do documento, dígitos e CTA.
- `briefing-reedicao.md` e `referencia-motion.md`: pedido do usuário e leitura da referência. A referência em vídeo não é uma dependência da renderização e não é incluída no pacote.
- `review/`: relatórios e amostras do MP4 final.

## Executar

Node 24.19.0 foi usado no ambiente, com Remotion 4.0.535 e React 19.3.1. Os arquivos de fonte e mídia estão incluídos; não há dependência de caminhos temporários ou serviços externos.

```sh
export npm_config_cache=/workspace/.cache/npm
export XDG_CONFIG_HOME=/workspace/.cache/xdg-config
export XDG_CACHE_HOME=/workspace/.cache/xdg-cache
npm ci --no-audit --no-fund
npm run studio
```

O Chromium desta máquina está em `/usr/bin/chromium`. Ajuste o argumento `--browser-executable` nos scripts em outras máquinas. No ambiente preparado, `npm ci --offline --no-audit --no-fund` também utiliza o cache já instalado.

```sh
npm run draft
npm run render
python3 scripts/validate-output.py out/evoquex-motion-v2.mp4
python3 scripts/create-delivery.py --v2
```

`draft` exporta a composição em 540 × 960 para revisão temporal. `render` exporta o MP4 definitivo em 1080 × 1920, H.264, YUV420p/BT.709 e áudio AAC estéreo. `render-v1` preserva o comando da versão anterior.

A trilha pronta está incluída. Para regenerá-la, use `python3 scripts/create-sound-v2.py`; esse comando requer Python, NumPy e FFmpeg.

## Narrativa e duração

| Trecho | Composição |
| --- | --- |
| 0–3,8 s | Anúncio real, frase por palavras e transformação em cartão vertical |
| 3,8–6,2 s | Cartão sai em profundidade e cidade entra como contexto local |
| 6,2–8,7 s | Recorte do alcance no documento, marcação e aproximação |
| 8,7–11,8 s | 13.064 em tipografia cinética, com anúncio e cidade integrados |
| 11,8–14,2 s | Recorte e aproximação das impressões no documento |
| 14,2–16,5 s | 20.981 impressões em destaque |
| 16,5–20,8 s | Carrossel e conexão do case com o empresário |
| 20,8–23,6 s | Mudança de contraste: publicar e fazer chegar |
| 23,6–28 s | Convite e CTA em composição de conversa |

## Validação

O script confere 840 quadros, 1080 × 1920, 30 fps, H.264, YUV420p, BT.709 e áudio AAC estéreo, além de decodificar integralmente as trilhas de imagem e som. A revisão visual usa amostras de toda a duração e as telas de métrica/CTA em tamanho de celular. A origem dos três materiais é preservada e conferida por SHA-256.

A exportação definitiva da V2 passou por essas verificações. Foram revistas 56 amostras distribuídas pelo MP4, além das telas de métrica e CTA em 360 × 640. O áudio final mediu −18,51 LUFS e pico verdadeiro de −1,95 dBTP, sem clipping. A imagem tem exatamente 28 segundos; o contêiner registra 28,011 segundos incluindo o encerramento do AAC.
