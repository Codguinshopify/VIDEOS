import React from 'react';
import {Composition, Folder} from 'remotion';
import {EvoquexReel} from './Reel';
import {OpeningScene} from './scenes/Opening';
import {RevelationScene} from './scenes/Revelation';
import {ProofScene} from './scenes/Proof';
import {ConnectionScene} from './scenes/Connection';
import {ClosingScene} from './scenes/Closing';

export const RemotionRoot = () => <>
  <Composition id="EvoquexCase" component={EvoquexReel} width={1080} height={1920} fps={30} durationInFrames={840} />
  <Folder name="Cenas">
    <Composition id="Reconhecimento" component={OpeningScene} width={1080} height={1920} fps={30} durationInFrames={132} />
    <Composition id="Revelacao" component={RevelationScene} width={1080} height={1920} fps={30} durationInFrames={162} />
    <Composition id="Prova" component={ProofScene} width={1080} height={1920} fps={30} durationInFrames={252} />
    <Composition id="Conexao" component={ConnectionScene} width={1080} height={1920} fps={30} durationInFrames={192} />
    <Composition id="Convite" component={ClosingScene} width={1080} height={1920} fps={30} durationInFrames={150} />
  </Folder>
</>;
