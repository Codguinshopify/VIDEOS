"""Package the Remotion source and original media without dependency/build caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
output = root / 'out/evoquex-source.zip'
files = [root / name for name in ['package.json', 'package-lock.json', 'README.md', 'briefing.md', '.gitignore']]
for folder in ['src', 'public', 'scripts']:
    files.extend(path for path in (root / folder).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
for name in ['final-validation.json', 'original-media-integrity.json', 'media-metadata.json', 'audio-analysis.json', 'final-video-contact-sheet.jpg', 'final-phone-proof.png', 'final-phone-cta.png']:
    path = root / 'review' / name
    if path.exists():
        files.append(path)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        archive.write(path, 'evoquex-reel/' + path.relative_to(root).as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None
    for name in ['DANYS.mp4', 'clevelandia.jpg', 'resultados.jpg']:
        assert archive.read('evoquex-reel/public/assets/' + name) == (root / 'public/assets' / name).read_bytes()
print(f'Source package verified: {output.name} — {output.stat().st_size} bytes')
