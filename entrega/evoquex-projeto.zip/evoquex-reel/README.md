# Evoquex — case Dany’s Presentes / Clevelândia

Reel de 28 segundos, 1080 × 1920, 30 fps, desenvolvido com os três materiais originais fornecidos pelo usuário.

## Entrega validada

- Vídeo: `out/evoquex-clevelandia.mp4` — 28 segundos de imagem (28,011 s no contêiner, incluindo o encerramento do AAC), 840 quadros, H.264, 1080 × 1920, 30 fps, YUV 4:2:0 e cores BT.709.
- Áudio: AAC estéreo, 48 kHz, com áudio original na abertura e trilha/sound design autorais. A medição final registrou −20,75 LUFS e pico verdadeiro de −4,30 dBTP, sem clipping.
- As trilhas completas de vídeo e áudio foram decodificadas com sucesso. Quatorze amostras do MP4 foram revistas, além das telas de métricas e CTA em 360 × 640. Não há avisos de materiais pendentes na peça final.
- Os três arquivos de mídia originais foram copiados sem alterar seus bytes, conferidos por SHA-256. O print preserva 20.981 impressões e 13.064 de alcance; ≈20 mil visualizações é identificado separadamente como resultado informado da campanha.
- Relatórios e amostras de revisão acompanham o código-fonte na pasta `review/`.

Para repetir a validação e gerar o pacote de fonte:

```sh
python3 scripts/validate-output.py
python3 scripts/create-delivery.py
```

## Materiais

Coloque os arquivos originais em `public/assets/`, preservando o conteúdo:

- `DANYS.mp4`: trecho original recebido como `Video.mp4`, com 5,06 segundos, 1080 × 1920 e 30 fps. Os cortes aproveitam os primeiros cinco segundos: abertura de 0–4 s e trecho final com transição até 5 s. A pergunta ocupa o topo para preservar a apresentadora e as legendas originais. O áudio original aparece na abertura, com saída suave antes da revelação.
- `clevelandia.jpg`: a fotografia aérea fornecida pelo usuário; não substituir por outra cidade.
- `resultados.jpg`: o print original fornecido pelo usuário; não reconstruir a interface.
- `evoquex-original.wav`: trilha e sound design autorais gerados pelo script incluso, sem samples externos.

As duas imagens foram extraídas do arquivo fornecido pelo usuário e copiadas sem alteração dos bytes. A foto mostra Clevelândia; o print é a fotografia original do Gerenciador de Anúncios. O enquadramento do print destaca as colunas de impressões e alcance, preservando o conteúdo original. O vídeo foi recebido e inspecionado antes de selecionar os cortes.

## Desenvolvimento

```sh
export npm_config_cache=/workspace/.cache/npm
export XDG_CONFIG_HOME=/workspace/.cache/xdg-config
export XDG_CACHE_HOME=/workspace/.cache/xdg-cache
npm ci --offline --no-audit --no-fund
python3 scripts/create-sound.py
node scripts/verify-assets.mjs --allow-missing
npm run studio
```

Para instalar fora da máquina preparada, retire `--offline`. As dependências Remotion estão fixadas em 4.0.535 e React em 19.3.1. O Chromium usado nesta máquina está em `/usr/bin/chromium`; ajuste o argumento `--browser-executable` em outras máquinas.

```sh
npm run compositions
npm run render
```

O script de render verifica os materiais antes de exportar. Os avisos visuais de material pendente são recursos da prévia de montagem e não devem ser exportados como vídeo final.

## Estrutura

| Trecho | Narrativa |
| --- | --- |
| 0–4 s | Vídeo real da Dany’s e pergunta de reconhecimento |
| 4–9 s | Vídeo, foto da cidade e revelação de 13.064 pessoas alcançadas |
| 9–17 s | Print original, 13.064 de alcance, 20.981 impressões e ≈20 mil visualizações |
| 17–23 s | Foto da cidade e convite ao empresário local |
| 23–28 s | CTA limpo: “Fale com a Evoquex.” |

As visualizações são um resultado informado no briefing, separado das impressões documentadas. Não há promessa de vendas, logotipo inventado ou alteração do print. O nome Evoquex é apresentado como texto.

Cada cena é registrada também como composição conectada no Studio. Entradas, contagens e câmera são controladas por frames, sem animações CSS.

## Revisão antes de entregar

1. Assistir ao anúncio, confirmar os cortes e decidir sobre seu áudio original.
2. Conferir o enquadramento da foto e do print em tela de celular.
3. Inspecionar as cinco cenas e suas transições após renderizar.
4. Confirmar H.264, 1080 × 1920, 30 fps, 840 quadros e áudio estéreo AAC.
5. Conferir métricas, legibilidade, safe area, CTA e ausência de avisos de materiais pendentes.

O briefing integral do usuário está em `briefing.md`.
