import React from 'react';
import {Composition, Folder} from 'remotion';
import {EvoquexReel} from './Reel';
import {OpeningScene} from './scenes/Opening';
import {RevelationScene} from './scenes/Revelation';
import {ProofScene} from './scenes/Proof';
import {ConnectionScene} from './scenes/Connection';
import {ClosingScene} from './scenes/Closing';
import {EvoquexMotion} from './motion-v2/MotionReel';
import {MotionIntro} from './motion-v2/Intro';
import {MotionLocal} from './motion-v2/Local';
import {MotionReachDocument, MotionImpressionsDocument} from './motion-v2/Document';
import {MotionReach, MotionImpressions} from './motion-v2/Metric';
import {MotionOpportunity} from './motion-v2/Opportunity';
import {MotionStrategy} from './motion-v2/Strategy';
import {MotionContact} from './motion-v2/Contact';

export const RemotionRoot = () => <>
  <Composition id="EvoquexMotion" component={EvoquexMotion} width={1080} height={1920} fps={30} durationInFrames={840} />
  <Folder name="Motion-V2">
    <Composition id="Motion-Reconhecimento" component={MotionIntro} width={1080} height={1920} fps={30} durationInFrames={114} />
    <Composition id="Motion-Local" component={MotionLocal} width={1080} height={1920} fps={30} durationInFrames={72} />
    <Composition id="Motion-Documento-Alcance" component={MotionReachDocument} width={1080} height={1920} fps={30} durationInFrames={75} />
    <Composition id="Motion-Alcance" component={MotionReach} width={1080} height={1920} fps={30} durationInFrames={93} />
    <Composition id="Motion-Documento-Impressoes" component={MotionImpressionsDocument} width={1080} height={1920} fps={30} durationInFrames={72} />
    <Composition id="Motion-Impressoes" component={MotionImpressions} width={1080} height={1920} fps={30} durationInFrames={69} />
    <Composition id="Motion-Oportunidade" component={MotionOpportunity} width={1080} height={1920} fps={30} durationInFrames={129} />
    <Composition id="Motion-Estrategia" component={MotionStrategy} width={1080} height={1920} fps={30} durationInFrames={84} />
    <Composition id="Motion-Contato" component={MotionContact} width={1080} height={1920} fps={30} durationInFrames={132} />
  </Folder>
  <Composition id="EvoquexCase" component={EvoquexReel} width={1080} height={1920} fps={30} durationInFrames={840} />
  <Folder name="Cenas">
    <Composition id="Reconhecimento" component={OpeningScene} width={1080} height={1920} fps={30} durationInFrames={132} />
    <Composition id="Revelacao" component={RevelationScene} width={1080} height={1920} fps={30} durationInFrames={162} />
    <Composition id="Prova" component={ProofScene} width={1080} height={1920} fps={30} durationInFrames={252} />
    <Composition id="Conexao" component={ConnectionScene} width={1080} height={1920} fps={30} durationInFrames={192} />
    <Composition id="Convite" component={ClosingScene} width={1080} height={1920} fps={30} durationInFrames={150} />
  </Folder>
</>;
