# Evoquex — V9 / catálogo em cena

## Concept
O conteúdo sai do vídeo e ganha a cidade. Same verified case, new visual construction.
This is a deliberate creative replacement for the V7/V8 layouts, not an engine port.
Six scenes remain 0–4.5–10.5–15.5–22.5–28.5–34.5 seconds to keep factual content
and existing music/impact timing comparable. No new narration or purchases.

## Palette and typography
#2449FF Evoquex blue, #11132B ink, #F7F6F1 paper, #8BF0E9 cyan, #FFFFFF white.
Local Manrope 400–800, 110–230px primary words, 48–65px explanations, 26px metadata.
No gradients, decorative dashboards, fake chats or invented charts.

## Frame direction
1. Blue typographic poster, oversized VIDEO photographic glyphs, rolling perspective
   company/service strip, clip on a bold circular canvas; no floating card stack.
2. Torn-paper collage transition into a wide horizontal filmstrip with production
   labels and a connected distribution band; no two-column video-and-cards layout.
3. City photograph in a large circular nucleus; satellites Instagram/Facebook/Público
   local orbit and settle around it. No street marker or map implying exact geodata.
4. Cyan evidence field, reach then impressions on a vertically traveling typographic
   rail, original capture inset; both values remain readable at the held end state.
5. Dark typographic two-question construction, words push previous words sideways
   to center; no repeated question cards. Scope: company/service, not only shop.
6. Blue tile-wave reveals Evoquex wordmark; human CTA locks large under it with
   a small original campaign contact strip. No messenger UI or sales promise.

## Motion and hierarchy
Native catalog mechanics drive the layouts: svg-mask-reveal, perspective-marquee,
paper-collage-reveal, locked-nucleus-orbit, kinetic-center-build, wordmark-tiles,
zoom-through-transition. Preserve recognizable algorithms, cite each implementation.
One synchronous paused GSAP root; 0.35–0.6s transitions; no random runtime, CDN, RAF
or CSS loop. Motion from first frame. Each scene enters; outgoing frame stays present
until covered. Clean hero layouts first, intentional decorative overlaps only.

## Truth and limitations
Danny’s Presentes. Produced by Evoquex. Ads Instagram/Facebook, only Clevelândia.
13.064 people reached; 20.981 impressions. No sales, ROI, views or non-follower claims.
Source footage and city photo resolution remain unchanged. Never reuse rejected voice.
