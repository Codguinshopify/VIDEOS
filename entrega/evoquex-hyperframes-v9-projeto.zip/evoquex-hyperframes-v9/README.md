# Evoquex / Danny’s Presentes — HyperFrames V9

Esta versão usa sete recursos diferentes do catálogo HyperFrames para construir cenas
novas. Consulte resources/CATALOG-USAGE.md para conferir cada origem, algoritmo e trecho.
O vídeo anterior não é usado como filmagem. Motor nativo HyperFrames 0.8.162 e GSAP 3.14.2.

34,5 s, 1080×1920, 30 fps. Fontes, imagens, vídeos e som são locais.

## Abrir e renderizar

```sh
npm ci
npm run dev
npm run check
npm run render
```

A prévia persistente abre no Studio: http://localhost:3002/#project/evoquex-hyperframes-v9.
Use a porta efetivamente indicada no terminal, caso diferente. Para encerrar:
`node scripts/hf.mjs preview --stop`. Chromium do sistema é usado se disponível;
FFmpeg e Node 22+ devem estar instalados. npm ci usa o lockfile fixado. node_modules,
caches, credenciais e MP4 de outras versões não estão no pacote.

## Recursos e conteúdo

Abertura com palavra fotográfica e faixa em perspectiva; filme em colagem de papel;
cidade como núcleo de um sistema orbital; evidência em composição ciano; perguntas
construídas por palavras que deslocam as anteriores; encerramento em mosaico da marca.

Métricas: 13.064 pessoas alcançadas e 20.981 impressões. Produção Evoquex, anúncios
Instagram/Facebook apenas em Clevelândia. Nenhuma afirmação sobre vendas, retorno
financeiro, visualizações ou público fora dos seguidores.

## Limites

Sem nova locução, preservando a mesma faixa de música/efeitos da V7 e V8. A voz rejeitada
não foi reutilizada. Não houve compras, mudanças de plano ou geração paga de voz.
A verificação sonora é técnica; esta interface não permite escuta subjetiva. O vídeo de
origem tem cerca de 5 s e a imagem da cidade tem 600×337 pixels. Nenhum projeto AEP foi
executado. Só os recursos já extraídos e úteis do pack do usuário foram preservados.

Os originais do catálogo e suas licenças estão em resources/catalog-originals. A cópia
via Git foi usada porque o add remoto não alcançou o host HTTP. A licença individual
MIT de kinetic-center-build está declarada no manifest original de Remocn. Não se
presume compatibilidade automática de todo o catálogo com qualquer motor.

## Preferência de entrega do usuário

Entregar somente o vídeo editado. Não criar comparativos, montagens lado a lado ou
links adicionais de comparação nas próximas versões. Manter fontes e validação no
projeto para continuidade, sem sobrecarregar a entrega.
