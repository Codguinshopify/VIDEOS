"""Package the native V9 sources, all local assets and selected validation reports."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
out=ROOT/'renders/evoquex-hyperframes-v9-projeto.zip'
files=set()
for name in ['index.html','style.css','catalog-motion.js','motion.js','DESIGN.md','README.md','AGENTS.md','package.json','package-lock.json','hyperframes.json','meta.json','.gitignore']:files.add(ROOT/name)
for folder in ['assets','vendor','scripts','resources']:
 files.update(f for f in (ROOT/folder).rglob('*') if f.is_file() and '__pycache__' not in f.parts)
for pattern in ['output-validation.json','hf-v9-sampling.json','catalog-verification.json','final-check.json','motion-review.json','final-review.md','source-reproduction.json','hf-v9-full-*.jpg','hf-v9-hook-*.jpg','hf-v9-cuts-*.jpg','hf-v9-phone-*.png']:
 files.update((ROOT/'review').glob(pattern))
files.add(ROOT/'review/animation-map/animation-map.json')
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(files):
  assert not f.name.startswith('.env') and 'node_modules' not in f.parts
  z.write(f,'evoquex-hyperframes-v9/'+f.relative_to(ROOT).as_posix())
with ZipFile(out) as z:
 assert z.testzip() is None
 for n in ['index.html','style.css','catalog-motion.js','motion.js','assets/campanha.mp4','assets/mix-v7.wav','vendor/gsap.min.js','package-lock.json']:
  assert z.read('evoquex-hyperframes-v9/'+n)==(ROOT/n).read_bytes()
report={'file':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'crc_passed':True,'files':len(files),'self_contained_assets':True,'node_modules_and_secrets_excluded':True}
(ROOT/'review/package-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
