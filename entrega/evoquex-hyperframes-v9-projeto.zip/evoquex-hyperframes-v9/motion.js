const tl=window.__timelines['evoquex-hf-v9'];
const show=(selector,at,kind='slit')=>{
 tl.set(selector,{opacity:1},at);
 const from=kind==='round'?'circle(0% at 50% 50%)':kind==='up'?'inset(100% 0 0 0)':'inset(0 50% 0 50%)';
 const to=kind==='round'?'circle(150% at 50% 50%)':'inset(0 0 0 0)';
 tl.fromTo(selector,{clipPath:from},{clipPath:to,duration:.5,ease:'power4.inOut',immediateRender:false},at);
};
// New opening. Photographic word, rotating cropped footage, rolling typography.
tl.from('#hook .masthead',{x:45,duration:.4,ease:'power2.out'},0);
tl.from('.hook-intro',{y:60,rotation:-3,duration:.5,ease:'expo.out'},0);
tl.from('.mask-title',{scale:1.2,rotation:-5,duration:.65,ease:'power4.out'},0);
Catalog.photographicWord(tl,0);
tl.from('.hook-caption',{x:120,opacity:0,duration:.4,ease:'power3.out'},.18);
tl.from('.hook-disc',{scale:.6,rotation:-90,duration:.7,ease:'power3.out'},0);
tl.from('.hook-clip',{scale:.7,rotation:-12,y:90,duration:.65,ease:'power4.out'},0);
tl.to('.hook-clip',{rotation:-4,scale:1.04,duration:3.5,ease:'sine.inOut'},.7);
tl.from('.visual-label',{x:-100,opacity:0,stagger:.15,duration:.38,ease:'back.out(1.05)'},.4);
tl.from('.hook-plus',{rotation:-90,scale:.4,opacity:0,duration:.5,ease:'power3.out'},.55);
Catalog.marquee(tl,.8,3.7);
tl.from('#hook .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},.6);

// Catalog torn-paper reveal, followed by a moving full-width filmstrip.
tl.set('#action',{opacity:1},4.5);Catalog.paper(tl,4.5);tl.set('#hook',{opacity:0},5.1);
tl.from('#action .masthead',{y:25,opacity:0,duration:.4,ease:'power2.out'},4.7);
tl.from('#action .small-label',{x:70,opacity:0,duration:.4,ease:'power3.out'},4.78);
tl.from('#action h1',{x:-100,opacity:0,duration:.55,ease:'expo.out'},4.8);
tl.from('.action-copy',{y:45,opacity:0,duration:.4,ease:'power2.out'},5.08);
tl.from('.filmstrip',{x:650,rotation:4,scale:.85,duration:.7,ease:'power4.out'},4.9);
tl.to('.filmstrip',{x:-165,rotation:-3,duration:2.6,ease:'sine.inOut'},6.5);
tl.from('.distribution',{clipPath:'inset(0 100% 0 0)',duration:.5,ease:'power3.inOut'},6.15);
tl.from('.distribution-top',{x:80,opacity:0,duration:.4,ease:'power3.out'},6.4);
tl.from('.network-row>*',{y:40,opacity:0,stagger:.12,duration:.4,ease:'back.out(1.05)'},6.75);
tl.from('#action .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},5.3);

// Catalog zoom transition into the nucleus/orbit city composition.
Catalog.zoom(tl,'#action','#local',10.5);
tl.from('#local .masthead',{y:25,opacity:0,duration:.4,ease:'power2.out'},10.7);
tl.from('.local-top .small-label',{x:50,opacity:0,duration:.4,ease:'power3.out'},10.76);
tl.from('.local-top h2',{y:70,opacity:0,duration:.5,ease:'expo.out'},10.8);
tl.from('.city-nucleus',{scale:.5,rotation:-18,opacity:0,duration:.7,ease:'power4.out'},10.8);
tl.to('.city-nucleus img',{scale:1.12,rotation:2,duration:3.5,ease:'sine.inOut'},11.6);
Catalog.orbit(tl,11.1);
tl.from('.city-plaque',{y:40,opacity:0,duration:.4,ease:'back.out(1.1)'},12);
tl.from('.local-copy',{y:40,opacity:0,duration:.45,ease:'power2.out'},12.5);
tl.from('#local .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},11.2);

// Evidence occupies the frame. A traveling rail settles with BOTH metrics.
show('#proof',15.5,'up');tl.set('#local',{opacity:0},16.05);
tl.from('#proof .masthead',{x:40,opacity:0,duration:.4,ease:'power2.out'},15.7);
tl.from('#proof h2',{y:60,opacity:0,duration:.5,ease:'expo.out'},15.74);
tl.from('.proof-rail',{y:120,duration:.7,ease:'power3.out'},15.9);
tl.from('.reach-stat',{x:-120,opacity:0,duration:.45,ease:'power4.out'},16.08);
tl.from('.impressions-stat',{x:140,opacity:0,duration:.48,ease:'power3.out'},17.7);
function count(id,value,at){
 tl.set(id,{textContent:'0'},15.5);
 for(let f=0;f<=30;f++){const e=(1-Math.cos(Math.PI*f/30))/2;tl.set(id,{textContent:Math.round(value*e).toLocaleString('pt-BR')},at+f/30);}
 tl.to(id,{scale:1.025,duration:.14,ease:'power3.out'},at+1);tl.to(id,{scale:1,duration:.18,ease:'power2.out'},at+1.14);
}
count('#reach',13064,16.4);count('#impressions',20981,18);
tl.from('.evidence-thumb',{rotation:10,scale:.6,opacity:0,duration:.6,ease:'back.out(1.05)'},19.05);
tl.from('.evidence-row>div:last-child',{x:45,opacity:0,duration:.45,ease:'power2.out'},19.2);
tl.from('#proof .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},19.3);

// Actual catalog prefix layout logic; words physically displace earlier words.
show('#strategy',22.5,'slit');tl.set('#proof',{opacity:0},23.05);
tl.from('#strategy .masthead',{y:25,opacity:0,duration:.4,ease:'power2.out'},22.7);
tl.from('.strategy-lead',{y:70,opacity:0,duration:.5,ease:'expo.out'},22.72);
tl.from('.question-number',{x:70,opacity:0,stagger:1.6,duration:.4,ease:'power3.out'},23.05);
Catalog.phrase(tl,'#phrase-one',['O','que','divulgar?'],[76.11,184.98,447.5],23.16);
Catalog.phrase(tl,'#phrase-two',['Quem','alcançar?'],[290.62,467.72],24.92);
tl.from('.question-unit:not(.second) .question-underline',{scaleX:0,duration:.6,ease:'power4.inOut'},23.7);
tl.from('.question-unit.second .question-underline',{scaleX:0,duration:.6,ease:'power3.inOut'},25.25);
tl.from('.strategy-end',{y:45,opacity:0,duration:.45,ease:'power2.out'},26.2);
tl.from('#strategy .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},23);

// Catalog raster wave replaces the repeated speech-bubble ending.
Catalog.zoom(tl,'#strategy','#contact',28.5);
tl.from('#contact .masthead',{y:25,opacity:0,duration:.4,ease:'power2.out'},28.7);
Catalog.tiles(tl,28.85);
tl.from('.contact-question',{x:-90,opacity:0,duration:.5,ease:'expo.out'},29.5);
tl.from('.cta-line>span',{y:90,opacity:0,stagger:.2,duration:.5,ease:'power4.out'},30.1);
tl.from('.contact-rule',{scaleX:0,duration:.6,ease:'power3.inOut'},30.5);
tl.from('.contact-note',{y:45,opacity:0,duration:.45,ease:'power2.out'},30.85);
tl.from('.contact-strip img',{y:100,rotation:8,opacity:0,stagger:.12,duration:.55,ease:'power3.out'},31.05);
tl.from('#contact .footer',{y:25,opacity:0,duration:.4,ease:'power2.out'},31.2);
window.EVOQUEX_AUDIT={engine:'HyperFrames 0.8.162',business:'Danny’s Presentes',metrics:{reach:13064,impressions:20981},voice:false,originalAudioGain:0,catalog:['svg-mask-reveal','perspective-marquee','paper-collage-reveal','locked-nucleus-orbit','kinetic-center-build','wordmark-tiles','zoom-through-transition']};
tl.seek(0);
