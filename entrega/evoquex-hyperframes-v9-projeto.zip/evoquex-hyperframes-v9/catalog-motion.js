/* Adapted from the seven pinned HyperFrames catalog sources in resources/.
 * Original algorithms retained below; local palette, Manrope, media, timing,
 * one root timeline and pt-BR content replace the standalone demos.
 */
const Catalog={
 // svg-mask-reveal: a vector word silhouette intersects a traveling sweep.
 photographicWord(tl,at){
  tl.fromTo('#word-sweep',{attr:{width:95}},{attr:{width:1000},duration:.75,ease:'power2.out'},at);
 },
 // perspective-marquee: duplicated pills, tilted plane, one seekable offset.
 marquee(tl,at,duration){
  tl.from('.marquee',{rotationX:45,y:80,opacity:0,duration:.45,ease:'power3.out'},at);
  tl.fromTo('.marquee-strip',{'--hf-marquee-x':'0px'},{'--hf-marquee-x':'-780px',duration,ease:'none'},at);
 },
 // paper-collage-reveal: original fixed-seed LCG, deckled polygons, outward
 // travel and perpendicular arc. Timing compressed for a 0.6s ad transition.
 paper(tl,at){
  const host=document.querySelector('#paper-transition');let state=0x2c6b8f19;
  const next=()=>{state=(Math.imul(1664525,state)+1013904223)>>>0;return state/4294967296;};
  const range=(a,b)=>a+next()*(b-a),sides=[[0,0,100,0,0,1],[100,0,100,100,-1,0],[100,100,0,100,0,-1],[0,100,0,0,1,0]];
  const torn=(w,h)=>{const pts=[];sides.forEach(s=>{for(let k=0;k<6;k++){const t=(k===0?0:k+range(-.3,.3))/6,d=range(-1.1,1.1);pts.push(`${(s[0]+(s[2]-s[0])*t+s[4]*d*100/w).toFixed(2)}% ${(s[1]+(s[3]-s[1])*t+s[5]*d*100/h).toFixed(2)}%`);}});return `polygon(${pts.join(',')})`;};
  const labels=['UM','VÍDEO.','UM','CASE','REAL.','LOCAL.'];
  for(let i=0;i<6;i++){
   const col=i%2,row=Math.floor(i/2),w=56.4,h=39.73,x=col*50-3.2,y=row*33.33-3.2;
   const el=document.createElement('div'),arc=document.createElement('div'),fill=document.createElement('div');
   el.className='pcr-panel';arc.className='pcr-panel-arc';fill.className='pcr-panel-fill';
   Object.assign(el.style,{left:x+'%',top:y+'%',width:w+'%',height:h+'%',zIndex:String(6-i)});
   fill.style.clipPath=torn(w,h);fill.textContent=labels[i];arc.append(fill);el.append(arc);host.append(el);
   const angle=Math.atan2(y+h/2-50,x+w/2-50),ux=Math.cos(angle),uy=Math.sin(angle),amp=ux>0?-9:9,rot=range(8,15)*(next()<.5?-1:1),start=at+i*.023;
   tl.fromTo(el,{x:0,y:0,rotation:0},{x:ux*1600,y:uy*2400,rotation:rot,duration:.44,ease:'power2.in',force3D:false,immediateRender:false},start);
   tl.fromTo(arc,{x:0,y:0},{x:-uy*amp*10.8,y:ux*amp*10.8,duration:.44,ease:'power1.out',force3D:false,immediateRender:false},start);
  }
  tl.set(host,{opacity:1},at);tl.set(host,{opacity:0},at+.59);
 },
 // locked-nucleus-orbit: rotating zero-size arms + counterrotating chips.
 // The city is a fixed photographic nucleus, not a claimed targeting map.
 orbit(tl,at){
  const labels=['Instagram','Público local','Facebook'],radii=[405,414,405],host=document.querySelector('#satellites');
  labels.forEach((label,i)=>{
   const arm=document.createElement('div'),anchor=document.createElement('div'),chip=document.createElement('div');
   arm.className='lno-arm';anchor.className='lno-anchor';chip.className='lno-chip';anchor.style.setProperty('--radius',radii[i]+'px');
   chip.innerHTML='<span class="lno-marker"></span>'+label;anchor.append(chip);arm.append(anchor);host.append(arm);
   const end=-90+i*120,start=end-210-(i%3)*70;
   tl.fromTo(arm,{rotation:start},{rotation:end,duration:2.2,ease:'power2.out',immediateRender:false},at);
   tl.fromTo(chip,{rotation:-start,opacity:0,scale:.82},{rotation:-end,opacity:1,scale:1,duration:2.2,ease:'power2.out',immediateRender:false},at);
  });
  tl.from('.orbit-ring',{scale:.86,opacity:0,stagger:.09,duration:.6,ease:'power3.out'},at);
 },
 // kinetic-center-build: all prefix layouts centered; arriving words push
 // prior words to their new positions. Premeasured local 800-weight font
 // avoids dependence on async font readiness during timeline construction.
 phrase(tl,id,words,widths,at){
  const stage=document.querySelector(id);stage.replaceChildren();const gap=30,positions=[];
  for(let count=1;count<=words.length;count++){
   let cursor=-(widths.slice(0,count).reduce((a,b)=>a+b,0)+gap*(count-1))/2;const row=[];
   for(let k=0;k<count;k++){row.push(cursor+widths[k]/2);cursor+=widths[k]+gap;}positions.push(row);
  }
  const els=words.map((word,i)=>{const e=document.createElement('span');e.className='phrase-word';e.textContent=word;stage.append(e);return e;});
  els.forEach((el,i)=>{
   const start=at+i*.32,target=positions[i][i];
   tl.fromTo(el,{x:target+(i?105:0),y:i?0:6,xPercent:-50,yPercent:-50,scale:.992,opacity:0,'--kcb-blur':'3.5px'},{x:target,y:0,scale:1,opacity:1,'--kcb-blur':'0px',duration:.4,ease:'power3.out',immediateRender:false},start);
   for(let j=0;j<i;j++){
    tl.to(els[j],{x:positions[i][j],duration:.4,ease:'power3.out'},start);
    tl.to(els[j],{'--kcb-blur':'0.8px',duration:.2,ease:'none'},start);
    tl.to(els[j],{'--kcb-blur':'0px',duration:.2,ease:'none'},start+.2);
   }
  });
 },
 // wordmark-tiles: exact deterministic noise LCG and spatial sine rank.
 // Each cell crops the SAME wordmark surface at its matching grid offset.
 tiles(tl,at){
  const grid=document.querySelector('#tile-grid'),tiles=[];let seed=0x57a7c1e;
  const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const tones=['#8BF0E9','#F7F6F1','#11132B'];
  for(let i=0;i<60;i++){
   const row=Math.floor(i/12),col=i%12,tile=document.createElement('span'),resolved=document.createElement('span'),noise=document.createElement('span'),word=document.createElement('span');
   tile.className='wt-tile';resolved.className='wt-resolved';noise.className='wt-noise';word.className='wt-fragment';word.textContent='Evoquex';
   word.style.setProperty('--crop-x',(-948*col/12)+'px');word.style.setProperty('--crop-y',(-350*row/5)+'px');noise.style.setProperty('--noise',tones[Math.floor(next()*3)]);
   noise.dataset.startOpacity=String(.72+next()*.28);resolved.append(word);tile.append(resolved,noise);grid.append(tile);
   tiles.push({resolved,noise,rank:col+row*.68+Math.sin(row*1.7+col*.42)*2.15});
  }
  const sorted=tiles.sort((a,b)=>a.rank-b.rank),resolved=sorted.map(x=>x.resolved),noise=sorted.map(x=>x.noise);
  tl.from('#tile-stage',{y:35,opacity:0,duration:.35,ease:'power2.out'},at);
  tl.fromTo(resolved,{opacity:0,scale:.82},{opacity:1,scale:1,stagger:.019,duration:.35,ease:'power2.out',immediateRender:false},at+.14);
  tl.fromTo(noise,{opacity:(i,e)=>Number(e.dataset.startOpacity),scale:1},{opacity:0,scale:1.18,stagger:.019,duration:.35,ease:'power2.out',immediateRender:false},at+.14);
 },
 // zoom-through-transition: incoming clipped plane travels 60→0 and scales
 // 1.04→1; outgoing plane compresses/blurs while an accent streak crosses.
 zoom(tl,from,to,at){
  tl.set(to,{opacity:1},at);
  tl.fromTo(to,{clipPath:'inset(0 100% 0 0)',x:60,scale:1.04},{clipPath:'inset(0 0% 0 0)',x:0,scale:1,duration:.52,ease:'power3.inOut',immediateRender:false},at);
  tl.to(from,{x:-70,scale:.96,filter:'blur(5px)',duration:.52,ease:'power3.inOut'},at);
  tl.set('#zoom-streak',{opacity:.9},at+.09);
  tl.fromTo('#zoom-streak',{x:0},{x:2440,duration:.45,ease:'power2.inOut',immediateRender:false},at+.09);
  tl.set('#zoom-streak',{opacity:0},at+.54);tl.set(from,{opacity:0},at+.55);
 }
};
