"""Compose and mix the V3 score. No third-party songs or demo MIDI files.

Uses the system FluidSynth shared library and the pinned GeneralUser GS bank.
The delivered WAV is self-contained; running this script is optional for rendering.
"""
from pathlib import Path
import ctypes as ct
import ctypes.util
import hashlib
import json
import os
import shutil
import subprocess
import urllib.request
import wave
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RATE, LENGTH = 48000, 28
PIN = '684543d5e5efaef08d02be50dcda8d552478fa60'
SHA = '9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe'
CACHE = Path(os.environ.get('EVOQUEX_AUDIO_CACHE', '/workspace/.cache/evoquex-audio'))
CACHE.mkdir(parents=True, exist_ok=True)
bank = CACHE / 'GeneralUser-GS.sf2'
if not bank.exists():
    local = Path('/tmp/evoquex-generaluser-gs/GeneralUser-GS.sf2')
    if local.exists():
        shutil.copyfile(local, bank)
    else:
        url = f'https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/{PIN}/GeneralUser-GS.sf2'
        with urllib.request.urlopen(url, timeout=90) as response:
            bank.write_bytes(response.read())
assert hashlib.sha256(bank.read_bytes()).hexdigest() == SHA, 'SoundFont integrity check failed'

lib = ct.CDLL(ctypes.util.find_library('fluidsynth'))
def api(name, ret, args):
    fn = getattr(lib, name); fn.restype = ret; fn.argtypes = args; return fn
ptr, integer, number, string = ct.c_void_p, ct.c_int, ct.c_double, ct.c_char_p
settings = api('new_fluid_settings', ptr, [])()
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.sample-rate', RATE)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.gain', .65)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.reverb.room-size', .34)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.reverb.level', .12)
api('fluid_settings_setnum', integer, [ptr, string, number])(settings, b'synth.chorus.level', .18)
synth = api('new_fluid_synth', ptr, [ptr])(settings)
assert api('fluid_synth_sfload', integer, [ptr, string, integer])(synth, str(bank).encode(), 1) >= 0
program = api('fluid_synth_program_change', integer, [ptr, integer, integer])
control = api('fluid_synth_cc', integer, [ptr, integer, integer, integer])
on = api('fluid_synth_noteon', integer, [ptr, integer, integer, integer])
off = api('fluid_synth_noteoff', integer, [ptr, integer, integer])
write = api('fluid_synth_write_float', integer, [ptr, integer, ptr, integer, integer, ptr, integer, integer])
program(synth, 0, 4)  # electric piano
program(synth, 1, 33) # fingered bass
program(synth, 2, 89) # quiet warm pad, only sustained transitions
for channel, volume, pan in [(0, 92, 52), (1, 91, 64), (2, 29, 78), (9, 77, 64)]:
    control(synth, channel, 7, volume); control(synth, channel, 10, pan)
control(synth, 1, 91, 0); control(synth, 9, 91, 8)

events = []
def note(t, channel, pitch, velocity, duration):
    if t < LENGTH - .7:
        events.extend([(round(t * RATE), 1, channel, pitch, velocity), (round((t + duration) * RATE), 0, channel, pitch, 0)])

beat = 60 / 108
chords = [(38, [60, 65, 69, 76]), (34, [57, 62, 65, 72]), (41, [60, 64, 67, 74]), (36, [58, 62, 67, 72])]
for bar in range(13):
    t = bar * beat * 4
    root, voicing = chords[bar % 4]
    for index, pitch in enumerate(voicing):
        note(t + index * .012, 0, pitch, 49 + index * 2, beat * 2.3)
        if bar >= 2:
            note(t + beat * 2.75 + index * .008, 0, pitch, 33 + index * 2, beat * .85)
    if bar in [2, 4, 7, 10]:
        for pitch in voicing[:3]: note(t + .03, 2, pitch, 28, beat * 3.1)
    if bar >= 1:
        for step, pitch, vel, dur in [(0, root, 71, .82), (1.75, root + 12, 48, .2), (2.5, root, 60, .5), (3.5, root + 7, 39, .18)]:
            note(t + beat * step + .008, 1, pitch, vel, dur)
    if bar >= 2 and t < 24.5:
        for step, vel in [(0, 78), (1.5, 49), (2.5, 66)]: note(t + beat * step, 9, 36, vel, .09)
        for step in [1, 3]: note(t + beat * step + .012, 9, 37, 62, .07)
        for eighth in range(8):
            note(t + beat * eighth / 2 + (.018 if eighth % 2 else 0), 9, 42, 33 if eighth % 2 == 0 else 21, .045)
    elif bar == 1:
        for step in [0, 2]: note(t + beat * step, 9, 42, 23, .045)

events.sort()
music = np.zeros((RATE * LENGTH, 2), dtype=np.float32)
cursor = 0
def render_until(end):
    global cursor
    end = min(end, len(music))
    n = end - cursor
    if n > 0:
        left = np.zeros(n, dtype=np.float32); right = np.zeros(n, dtype=np.float32)
        assert write(synth, n, left.ctypes.data, 0, 1, right.ctypes.data, 0, 1) == 0
        music[cursor:end, 0] = left; music[cursor:end, 1] = right
        cursor = end
for sample, is_on, channel, pitch, velocity in events:
    if sample >= len(music): break
    render_until(sample)
    if is_on: on(synth, channel, pitch, velocity)
    else: off(synth, channel, pitch)
render_until(len(music))
api('delete_fluid_synth', None, [ptr])(synth)
api('delete_fluid_settings', None, [ptr])(settings)

rng = np.random.default_rng(20261015)
fx = np.zeros_like(music, dtype=np.float64)
def add(t, signal, gain=1, pan=0):
    sample = max(0, round(t * RATE)); signal = signal[:len(fx) - sample]
    if sample >= len(fx): return
    fx[sample:sample + len(signal), 0] += signal * gain * np.sqrt((1 - pan) / 2)
    fx[sample:sample + len(signal), 1] += signal * gain * np.sqrt((1 + pan) / 2)
def swish(t, duration=.34, gain=.11, pan=0):
    x = np.arange(round(duration * RATE)) / RATE
    noise = rng.standard_normal(len(x))
    low = np.convolve(noise, np.ones(26) / 26, mode='same')
    high = np.convolve(noise, np.ones(3) / 3, mode='same') - low
    signal = (.8 * low + .13 * high) * np.sin(np.pi * x / duration) ** 2
    add(t - duration * .7, signal, gain, pan)
def soft_impact(t, gain=.08):
    x = np.arange(round(.26 * RATE)) / RATE
    signal = np.sin(2 * np.pi * (74 * x + .6 * (1 - np.exp(-x * 30)))) * np.exp(-x * 22) * (1 - np.exp(-x * 900))
    add(t, signal, gain)
for t, g, pan in [(2.55,.08,-.2),(5.85,.10,.2),(6.6,.12,-.15),(10.6,.13,.15),(14.6,.15,-.2),(18.5,.06,.15),(20.8,.12,.1)]:
    swish(t, gain=g, pan=pan)
for t in [8.45,12.68,22.76]: soft_impact(t, .08 if t < 20 else .055)
# A short dry paper stroke follows the actual underline, no UI notification chimes.
for t in [7.18,11.48]:
    n = round(.13 * RATE); noise = rng.standard_normal(n)
    stroke = np.convolve(noise, np.ones(7)/7, mode='same') * np.sin(np.linspace(0,np.pi,n))**2
    add(t, stroke, .023, -.15)

def write_wav(path, data):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(RATE)
        w.writeframes((np.clip(data, -.99, .99) * 32767).astype('<i2').tobytes())

work = ROOT/'review/audio-v3'; work.mkdir(exist_ok=True)
raw_music = work/'music-raw.wav'; norm_music = work/'music.wav'
write_wav(raw_music, music)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw_music),'-af','highpass=f=42,loudnorm=I=-21:TP=-5:LRA=6','-ar',str(RATE),'-c:a','pcm_s16le',str(norm_music)],check=True)
with wave.open(str(norm_music),'rb') as w: music = np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2).astype(np.float64)/32768
music = music[:RATE * LENGTH]
times = np.arange(len(music))/RATE
duck = np.interp(times,[0,2.7,3.5,4.1,20.5,21.5,26.5,28],[.19,.19,.5,1,1,.78,.78,0])
music *= duck[:,None]
voice_path = work/'original-opening.wav'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'public/assets/DANYS.mp4'),'-t','3.35','-vn','-af','highpass=f=90,loudnorm=I=-18:TP=-3:LRA=5,afade=t=out:st=2.95:d=0.4','-ar',str(RATE),'-ac','2','-c:a','pcm_s16le',str(voice_path)],check=True)
with wave.open(str(voice_path),'rb') as w: voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2).astype(np.float64)/32768
mixed = music + fx
mixed[:len(voice)] += voice
mixed *= np.clip(np.minimum(times/.025,(LENGTH-times)/.7),0,1)[:,None]
mix_raw = work/'mix-raw.wav'; write_wav(mix_raw,mixed)
output = ROOT/'public/assets/evoquex-premium.wav'
proc = subprocess.run(['ffmpeg','-v','info','-y','-i',str(mix_raw),'-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-ar',str(RATE),'-c:a','pcm_s16le',str(output)],capture_output=True,text=True,check=True)
(work/'normalization.txt').write_text(proc.stderr)
(ROOT/'audio-sources/README.md').write_text(f'''# Áudio V3\n\nComposição original criada para este projeto: arranjo em 108 BPM, piano elétrico, baixo e percussão, com efeitos originais e fala do anúncio fornecido pelo usuário. Não reutiliza as trilhas V1/V2 nem gravações ou demos de terceiros.\n\nInstrumentos: GeneralUser GS, S. Christian Collins, commit `{PIN}`. Licença integral em GeneralUser-GS-LICENSE.txt; autor permite uso em criação musical privada e comercial. SoundFont SHA-256 `{SHA}`. Origem: https://github.com/mrbumpy409/GeneralUser-GS/tree/{PIN}\n\nO WAV final já está em public/assets e basta para reproduzir o MP4. Para refazer a música: Python 3, NumPy, FFmpeg e libfluidsynth, depois `python scripts/create-sound-v3.py`. O script verifica o SHA-256 do banco antes de usá-lo. O banco pode ser mantido fora do projeto via EVOQUEX_AUDIO_CACHE.\n\nA licença e as observações do autor sobre a procedência das amostras estão preservadas sem modificações.\n''')
for p in [raw_music,norm_music,voice_path,mix_raw]: p.unlink()
print(f'New V3 soundtrack: {output.stat().st_size} bytes, 28 s, 48 kHz stereo. No old score reused.')
