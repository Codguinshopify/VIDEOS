"""Original music and sound effects synchronized to the kinetic re-edit."""
from pathlib import Path
import numpy as np
import subprocess
import wave

root = Path(__file__).resolve().parent.parent
rate = 48000
seconds = 28
audio = np.zeros((rate * seconds, 2), dtype=np.float64)
rng = np.random.default_rng(280114)

def add(start, signal, gain=1, pan=0):
    offset = max(0, round(start * rate))
    if offset >= len(audio):
        return
    signal = signal[:len(audio) - offset] * gain
    audio[offset:offset + len(signal), 0] += signal * np.sqrt((1 - pan) / 2)
    audio[offset:offset + len(signal), 1] += signal * np.sqrt((1 + pan) / 2)

def pluck(midi, length=.45, decay=7):
    t = np.arange(round(length * rate)) / rate
    freq = 440 * 2 ** ((midi - 69) / 12)
    signal = np.sin(2 * np.pi * freq * t) + .22 * np.sin(4 * np.pi * freq * t)
    return signal * (1 - np.exp(-t * 280)) * np.exp(-t * decay)

def swipe(time, pan=0, gain=.15):
    t = np.arange(round(.35 * rate)) / rate
    noise = rng.standard_normal(len(t))
    noise = np.convolve(noise, np.ones(14) / 14, mode='same')
    envelope = np.sin(np.pi * t / .35) ** 2
    add(time - .2, noise * envelope, gain, pan)

beat = 60 / 116
chords = [(50, 65, 69, 72), (46, 62, 65, 69), (41, 60, 65, 69), (48, 64, 67, 72)]
for i in range(int(seconds / beat)):
    start = i * beat
    chord = chords[(i // 8) % len(chords)]
    t = np.arange(round(.23 * rate)) / rate
    kick = np.sin(2 * np.pi * (48 * t + 32 * (1 - np.exp(-t * 24)) / 24)) * np.exp(-t * 19)
    add(start, kick, .115 if i % 2 == 0 else .025)
    tick = rng.standard_normal(round(.025 * rate))
    tick *= np.exp(-np.arange(len(tick)) / (rate * .007))
    add(start + beat / 2, tick, .016, .25 if i % 2 else -.25)
    if i % 2 == 0:
        add(start + beat / 2, pluck(chord[1 + i % 3]), .045, .3 if i % 4 else -.3)
    if i % 4 == 0:
        add(start, pluck(chord[0] - 12, 1.4, 3), .1)

cuts = [3.8, 6.2, 8.7, 11.8, 14.2, 16.5, 20.8, 23.6]
for i, time in enumerate(cuts):
    swipe(time, .25 if i % 2 else -.25, .17)
    add(time, pluck(81 if i % 2 else 76, .35, 12), .08)

for time in [6.8, 12.5]:
    t = np.arange(round(.16 * rate)) / rate
    paper = np.convolve(rng.standard_normal(len(t)), np.ones(6) / 6, mode='same')
    add(time, paper * np.sin(np.pi * t / .16) ** 3, .055, -.1)

for time in [9.55, 15.05]:
    for i in range(4):
        add(time + .04 * i, pluck(82 + i * 2, .12, 25), .028)

add(24.55, pluck(88, .32, 11), .09, .1)
add(25.2, pluck(76, .5, 8), .065)
timeline = np.arange(len(audio)) / rate
fade = np.minimum(timeline / .12, 1) * np.minimum((seconds - timeline) / 1.0, 1)
audio = np.tanh(audio * np.maximum(fade, 0)[:, None])
raw = root / 'public/assets/evoquex-motion-raw.wav'
output = root / 'public/assets/evoquex-motion.wav'
with wave.open(str(raw), 'wb') as wav:
    wav.setnchannels(2)
    wav.setsampwidth(2)
    wav.setframerate(rate)
    wav.writeframes((audio * 32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(raw), '-af', 'loudnorm=I=-18:TP=-2:LRA=6', '-ar', str(rate), '-c:a', 'pcm_s16le', str(output)], check=True)
raw.unlink()
print('V2 soundtrack created: 28 s, stereo, 48 kHz; custom cut/number/bubble accents.')
