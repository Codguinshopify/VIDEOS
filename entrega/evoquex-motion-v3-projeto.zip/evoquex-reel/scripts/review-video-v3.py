"""Extract temporal visual checks, including exact transition neighborhoods."""
from pathlib import Path
from PIL import Image, ImageDraw
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
video = ROOT / (sys.argv[1] if len(sys.argv) > 1 else 'out/evoquex-motion-v3.mp4')
tag = 'v3-draft' if 'draft' in video.name else 'v3-final'
folder = ROOT / 'review' / tag
folder.mkdir(parents=True, exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-vf','fps=2,scale=216:384',str(folder/'sample-%03d.png')],check=True)
def sheet(items, name, columns=7, per_page=28):
    for start in range(0,len(items),per_page):
        chunk=items[start:start+per_page]; rows=(len(chunk)+columns-1)//columns
        result=Image.new('RGB',(columns*216,rows*411),'#DCE1E8');draw=ImageDraw.Draw(result)
        for index,(path,label) in enumerate(chunk):
            x=index%columns*216;y=index//columns*411
            result.paste(Image.open(path).convert('RGB').resize((216,384)),(x,y))
            draw.text((x+8,y+390),label,fill='#142136')
        result.save(ROOT/'review'/f'{tag}-{name}-{start//per_page+1:02d}.jpg',quality=93)
frames=sorted(folder.glob('sample-*.png'))
sheet([(p,f'{(i+.5)/2:.2f} s') for i,p in enumerate(frames)],'full')
transition=[]
for cut in [114,198,318,438,624]:
    for delta in [-3,0,3,6,9,12,18]:
        f=cut+delta; p=folder/f'transition-{f:04d}.png'
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(f/30),'-i',str(video),'-frames:v','1','-vf','scale=216:384',str(p)],check=True)
        transition.append((p,f'{f/30:.2f} s / f{f}'))
sheet(transition,'transitions',columns=7,per_page=21)
for name,seconds in [('reach',9.8),('impressions',13.8),('opportunity',18.8),('cta',26.5)]:
    subprocess.run(['ffmpeg','-v','error','-y','-ss',str(seconds),'-i',str(video),'-frames:v','1','-vf','scale=360:640',str(ROOT/'review'/f'{tag}-phone-{name}.png')],check=True)
print(f'{tag}: {len(frames)} duration samples, {len(transition)} transition samples, 4 phone checks.')
