"""Package the Remotion source and original media without dependency/build caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys

root = Path(__file__).resolve().parent.parent
v2 = '--v2' in sys.argv
v3 = '--v3' in sys.argv
output = root / ('out/evoquex-motion-v3-projeto.zip' if v3 else 'out/evoquex-motion-v2-projeto.zip' if v2 else 'out/evoquex-source.zip')
files = [root / name for name in ['package.json', 'package-lock.json', 'README.md', 'briefing.md', '.gitignore']]
if v2 or v3:
    files.extend(root / name for name in ['briefing-reedicao.md', 'referencia-motion.md'])
if v3:
    files.extend(root / name for name in ['ordem-producao-v3.md', 'analise-producao-v3.md', 'README-v2.md'])
    files.extend(path for path in (root / 'audio-sources').rglob('*') if path.is_file())
for folder in ['src', 'public', 'scripts']:
    files.extend(path for path in (root / folder).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
review_files = ['motion-v2-validation.json', 'original-media-integrity.json', 'media-metadata.json', 'motion-v2-audio-analysis.json', 'motion-v2-final-sheet-01.jpg', 'motion-v2-final-sheet-02.jpg', 'motion-v2-phone-metric.png', 'motion-v2-phone-cta.png'] if v2 else ['final-validation.json', 'original-media-integrity.json', 'media-metadata.json', 'audio-analysis.json', 'final-video-contact-sheet.jpg', 'final-phone-proof.png', 'final-phone-cta.png']
if v3:
    review_files = ['motion-v3-validation.json','original-media-integrity.json','media-metadata.json','motion-v3-audio-analysis.json','motion-v3-audio-integrity.json','motion-v3-design-resources.json','motion-v3-review.md','v3-final-full-01.jpg','v3-final-full-02.jpg','v3-final-transitions-01.jpg','v3-final-transitions-02.jpg','v3-final-phone-reach.png','v3-final-phone-impressions.png','v3-final-phone-opportunity.png','v3-final-phone-cta.png']
for name in review_files:
    path = root / 'review' / name
    if path.exists():
        files.append(path)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        archive.write(path, 'evoquex-reel/' + path.relative_to(root).as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None
    for name in ['DANYS.mp4', 'clevelandia.jpg', 'resultados.jpg']:
        assert archive.read('evoquex-reel/public/assets/' + name) == (root / 'public/assets' / name).read_bytes()
print(f'Source package verified: {output.name} — {output.stat().st_size} bytes')
