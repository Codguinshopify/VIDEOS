import path from 'node:path';
import fs from 'node:fs';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const frames = process.argv.slice(2).map(Number);
if (!frames.length) frames.push(0,35,70,95,113,114,140,175,197,210,235,265,300,320,350,380,419,447,480,530,580,615,645,680,720,780,835);
const output = path.resolve('review/v3-stills');
fs.mkdirSync(output,{recursive:true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.jsx')});
const browser = await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
  const composition = await selectComposition({serveUrl,id:'EvoquexPremium',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
  for (const frame of frames) {
    await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,scale:.5,imageFormat:'png',output:path.join(output,`${String(frame).padStart(4,'0')}.png`)});
    console.log(`Reviewed frame ${frame}`);
  }
} finally { await browser.close({silent:true}); }
