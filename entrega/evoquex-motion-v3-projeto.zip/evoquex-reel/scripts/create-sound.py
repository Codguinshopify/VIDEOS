"""Original instrumental bed and transition accents; no samples or external music."""
from pathlib import Path
import numpy as np
import wave
import subprocess

ROOT = Path(__file__).resolve().parent.parent
RATE = 48000
DURATION = 28
audio = np.zeros((RATE * DURATION, 2), dtype=np.float64)
rng = np.random.default_rng(20261014)

def add(start, signal, gain=1.0, pan=0.0):
    index = round(start * RATE)
    if index >= len(audio):
        return
    signal = signal[:len(audio) - index] * gain
    audio[index:index + len(signal), 0] += signal * np.sqrt((1 - pan) / 2)
    audio[index:index + len(signal), 1] += signal * np.sqrt((1 + pan) / 2)

def note(midi, duration=0.65):
    t = np.arange(round(duration * RATE)) / RATE
    frequency = 440 * 2 ** ((midi - 69) / 12)
    envelope = (1 - np.exp(-t * 220)) * np.exp(-t * 5.5)
    return (np.sin(2 * np.pi * frequency * t) + 0.18 * np.sin(4 * np.pi * frequency * t)) * envelope

beat = 60 / 114
chords = [(50, 57, 65, 69), (46, 53, 62, 65), (41, 53, 60, 65), (48, 55, 64, 67)]
for step in range(int(DURATION / beat)):
    start = step * beat
    chord = chords[(step // 8) % len(chords)]
    if step % 2 == 0:
        t = np.arange(round(0.28 * RATE)) / RATE
        kick = np.sin(2 * np.pi * (48 * t + 30 * (1 - np.exp(-t * 28)) / 28)) * np.exp(-t * 20)
        add(start, kick, 0.13)
    add(start + beat / 2, note(chord[1 + step % 3] + 12), 0.055, (-1 if step % 2 else 1) * 0.25)
    if step % 4 == 0:
        t = np.arange(round(1.5 * RATE)) / RATE
        bass = np.sin(2 * np.pi * (440 * 2 ** ((chord[0] - 12 - 69) / 12)) * t)
        bass *= (1 - np.exp(-t * 70)) * np.exp(-t * 2.7)
        add(start, bass, 0.08)

for boundary in [4, 9, 17, 23]:
    duration = 0.5
    t = np.arange(round(duration * RATE)) / RATE
    noise = rng.standard_normal(len(t))
    filtered = np.convolve(noise, np.ones(24) / 24, mode='same')
    envelope = np.sin(np.pi * t / duration) ** 2
    add(boundary - 0.3, filtered * envelope, 0.14)
    add(boundary, note(81, 0.7), 0.085, 0.1)

for boundary in [7.3, 10.7, 12.0, 13.1]:
    add(boundary, note(86, 0.22), 0.035)

time = np.arange(len(audio)) / RATE
fade = np.minimum(time / 0.18, 1) * np.minimum((DURATION - time) / 0.8, 1)
audio *= np.maximum(fade, 0)[:, None]
audio = np.tanh(audio)
raw = ROOT / 'public/assets/evoquex-original-raw.wav'
output = ROOT / 'public/assets/evoquex-original.wav'
with wave.open(str(raw), 'wb') as wav:
    wav.setnchannels(2)
    wav.setsampwidth(2)
    wav.setframerate(RATE)
    wav.writeframes((audio * 32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(raw), '-af', 'loudnorm=I=-20:TP=-2:LRA=7', '-ar', str(RATE), '-c:a', 'pcm_s16le', str(output)], check=True)
raw.unlink()
print('Trilha original e sound design criados: 28 segundos, estéreo, 48 kHz.')
