# Áudio V3

Composição original criada para este projeto: arranjo em 108 BPM, piano elétrico, baixo e percussão, com efeitos originais e fala do anúncio fornecido pelo usuário. Não reutiliza as trilhas V1/V2 nem gravações ou demos de terceiros.

Instrumentos: GeneralUser GS, S. Christian Collins, commit `684543d5e5efaef08d02be50dcda8d552478fa60`. Licença integral em GeneralUser-GS-LICENSE.txt; autor permite uso em criação musical privada e comercial. SoundFont SHA-256 `9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe`. Origem: https://github.com/mrbumpy409/GeneralUser-GS/tree/684543d5e5efaef08d02be50dcda8d552478fa60

O WAV final já está em public/assets e basta para reproduzir o MP4. Para refazer a música: Python 3, NumPy, FFmpeg e libfluidsynth, depois `python scripts/create-sound-v3.py`. O script verifica o SHA-256 do banco antes de usá-lo. O banco pode ser mantido fora do projeto via EVOQUEX_AUDIO_CACHE.

A licença e as observações do autor sobre a procedência das amostras estão preservadas sem modificações.
