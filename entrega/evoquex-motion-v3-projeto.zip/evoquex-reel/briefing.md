# BRIEFING PROFISSIONAL — EDIÇÃO DE REEL COM MOTION DESIGN PARA EVOQUEX

## 1. Seu papel

Atue como um editor de vídeo sênior, diretor criativo e motion designer especializado em publicidade digital, storytelling, vídeos de performance e criativos para Instagram Reels e Meta Ads.

Utilize o Remotion disponível neste ambiente para desenvolver e renderizar um vídeo publicitário profissional, com animações personalizadas, tipografia, transições, composição visual, tratamento de imagem e sound design.

**Não quero apenas um planejamento, um storyboard ou um código de exemplo. Quero que você execute o projeto, produza o vídeo final e verifique o resultado renderizado.**

Antes de começar, examine todos os arquivos anexados e identifique o vídeo original, o print das métricas e a fotografia aérea de Clevelândia, Paraná.

## 2. Contexto da campanha

Realizamos uma divulgação local para a empresa Dany’s Presentes, em Clevelândia–PR.

O vídeo original foi divulgado durante dois dias por meio de anúncios no Instagram e Facebook, com investimento de mídia de R$ 50.

Os resultados registrados foram:

- **13.064 pessoas alcançadas**
- **20.981 impressões no Gerenciador de Anúncios**
- Aproximadamente **20 mil visualizações**, conforme o resultado informado da campanha.

O objetivo agora é transformar essa campanha real em um vídeo de prova social para a Evoquex, mostrando a empresários locais o potencial de uma divulgação profissional.

O vídeo precisa demonstrar o que fizemos na prática, gerar curiosidade e despertar interesse comercial, sem parecer uma propaganda genérica de agência.

## 3. Direção criativa

Crie um Reel com storytelling publicitário, ritmo dinâmico e motion design profissional.

A ideia central é:

**“Você chegou a ver esse vídeo? Nós fizemos essa divulgação chegar a mais de 13 mil pessoas em Clevelândia.”**

A narrativa deve partir do vídeo real, revelar os resultados progressivamente e terminar mostrando que outras empresas também podem trabalhar sua divulgação de forma estratégica.

O vídeo precisa transmitir:
- Resultado real e verificável.
- Conhecimento de divulgação digital local.
- Profissionalismo e domínio técnico.
- Proximidade com o comércio de Clevelândia.
- Potencial comercial, sem promessas irreais.

Não apresente a campanha como garantia de vendas. O resultado comprovado é o alcance e a distribuição do conteúdo.

## 4. Roteiro e estrutura do vídeo

Duração desejada: 25 a 30 segundos.

Formato: vertical 9:16, resolução 1080 × 1920, preparado para Instagram Reels e também utilizável como anúncio.

### CENA 1 — RECONHECIMENTO E CURIOSIDADE
**Tempo aproximado: 0–4 segundos**

Use o início do vídeo original da Dany’s Presentes para que quem já o viu consiga reconhecê-lo.

Não substitua esse trecho por uma introdução genérica. Preserve o conteúdo real e escolha o melhor ponto de entrada.

Adicione motion design discreto e intencional: entrada de texto sincronizada, leve aproximação de câmera digital quando adequada, máscara animada ou destaque visual que valorize o próprio vídeo.

Texto na tela:

**“Você chegou a ver esse vídeo em Clevelândia?”**

A frase precisa entrar de forma impactante e legível, sem esconder o conteúdo importante do vídeo original.

### CENA 2 — REVELAÇÃO
**Tempo aproximado: 4–9 segundos**

Continue utilizando trechos reais do vídeo da divulgação, sem alterar o sentido do material.

Faça uma transição elegante entre o vídeo original e a fotografia aérea de Clevelândia fornecida como anexo.

Use a foto como elemento narrativo, com movimento de câmera sutil, parallax ou aproximação controlada, caso seja tecnicamente viável.

Texto na tela:

**“Nós fizemos essa divulgação chegar muito mais longe.”**

Em seguida, destaque:

**“13.064 pessoas alcançadas em Clevelândia.”**

A animação dos números deve ser precisa, elegante e bem sincronizada com a narrativa.

### CENA 3 — PROVA REAL
**Tempo aproximado: 9–17 segundos**

Apresente o print original dos resultados fornecido como anexo.

Não recrie a interface do Gerenciador de Anúncios. Utilize o print real, preservando sua autenticidade e os dados.

Crie uma composição de motion design com:
- Entrada animada do print.
- Recorte ou enquadramento que destaque os indicadores relevantes.
- Movimento de câmera controlado.
- Linhas, máscaras, contornos ou elementos gráficos sutis para direcionar o olhar.
- Destaque visual progressivo para os números.

Métricas principais:

**13.064 pessoas alcançadas**

**20 mil visualizações**

As duas métricas devem ser legíveis em uma tela de celular. Não deixe a animação prejudicar a leitura.

Se utilizar o número exato de impressões do print, identifique-o corretamente como **20.981 impressões**, sem confundi-lo com visualizações.

A prova social deve parecer um resultado documentado, não uma estatística inventada para fins publicitários.

### CENA 4 — CONEXÃO COM O EMPRESÁRIO
**Tempo aproximado: 17–23 segundos**

Volte a utilizar a fotografia aérea de Clevelândia e, se fizer sentido, um trecho curto do vídeo original.

Construa uma transição visual que conecte o resultado à realidade dos empresários da cidade.

Texto sugerido:

**“Sua empresa também pode ser vista por muito mais pessoas.”**

Dê ênfase à ideia de que não basta publicar conteúdo: é importante fazer a divulgação chegar ao público certo.

Não use gráficos falsos, resultados de vendas inexistentes ou depoimentos que não foram fornecidos.

### CENA 5 — CTA COMERCIAL
**Tempo aproximado: 23–30 segundos**

Finalize com uma composição forte, limpa e profissional, coerente com a identidade visual da Evoquex.

Texto principal:

**“Vamos trabalhar a divulgação da sua empresa?”**

Texto complementar:

**“Fale com a Evoquex.”**

A chamada deve ser clara, natural e comercialmente eficaz. Ela precisa incentivar o empresário a iniciar uma conversa, sem tom agressivo ou promessa exagerada.

Use uma animação final memorável, com tipografia bem trabalhada e movimento sutil. Não invente logotipos ou elementos de identidade visual que não tenham sido fornecidos.

## 5. Identidade visual e motion design

Use como direção visual uma estética de publicidade digital premium, contemporânea e tecnológica.

Paleta sugerida:
- Azul-marinho profundo.
- Azul elétrico ou ciano para pontos de atenção.
- Branco para títulos e informações.
- Tons naturais da fotografia de Clevelândia.

A fotografia real da cidade deve ajudar a contextualizar o case. Não substitua Clevelândia por uma cidade genérica nem utilize imagens urbanas aleatórias como se fossem locais.

Utilize tipografia sans-serif moderna, com hierarquia consistente, pesos bem escolhidos e excelente legibilidade.

### Recursos de motion desejados

- Animações tipográficas com entradas precisas e boa composição.
- Máscaras e transições personalizadas.
- Zooms sutis e movimentos de câmera controlados.
- Animação de números com contagem crescente, desde que o número final seja exato.
- Destaques gráficos para os indicadores.
- Parallax sutil na fotografia aérea, se apropriado.
- Transições motivadas pela narrativa, evitando efeitos aleatórios.
- Sound design discreto, com impactos, whooshes e acentos sonoros sincronizados.
- Trilha instrumental moderna, se houver um recurso de áudio apropriado e legalmente utilizável.

O motion deve parecer criado por um profissional, com timing, curvas de aceleração, desaceleração, profundidade e composição intencionais.

**Evite:** templates genéricos, excesso de efeitos, transições em todas as cenas, textos pulando sem propósito, glow exagerado, elementos decorativos aleatórios e animações que dificultem a leitura.

## 6. Edição do material original

O vídeo original é a principal referência para a abertura e para a conexão com a campanha real.

Examine o material antes de escolher os cortes. Preserve os trechos que melhor identificam a divulgação e utilize cortes adicionais apenas quando contribuírem para o storytelling.

Não invente cenas, não atribua falas inexistentes à empresa e não simule resultados comerciais que não foram comprovados.

O vídeo final deve funcionar mesmo para alguém que nunca viu a publicação original, mas deve gerar reconhecimento em quem já a viu.

## 7. Áudio e ritmo

A edição deve ter ritmo crescente:
1. Curiosidade.
2. Reconhecimento.
3. Revelação do resultado.
4. Prova.
5. Convite comercial.

Sincronize os movimentos com o áudio. Dê espaço para a compreensão dos números e das frases importantes.

Se o vídeo original tiver áudio relevante, avalie se vale a pena preservar partes dele. Caso não contribua para a narrativa, utilize uma trilha e um sound design compatíveis com o material.

Não utilize músicas protegidas sem autorização ou licença adequada.

## 8. Implementação com Remotion

Antes de codificar:
1. Inspecione o projeto Remotion existente e suas dependências.
2. Identifique os arquivos anexados e seus formatos.
3. Confira a duração, a proporção e a qualidade do vídeo original.
4. Planeje a composição, a duração de cada cena e as transições.
5. Reutilize a estrutura existente quando apropriado, sem sobrescrever arquivos ou configurações importantes desnecessariamente.

Implemente as cenas em uma composição Remotion organizada, com componentes reutilizáveis, animações controladas por frames e código legível.

Renderize o resultado final em MP4, com resolução vertical de 1080 × 1920 e uma taxa de quadros apropriada para Reels, preferencialmente 30 fps.

Garanta que os arquivos de mídia sejam carregados corretamente e que o projeto não dependa de caminhos temporários que impeçam a renderização.

## 9. Revisão obrigatória

Após renderizar:
- Assista ao vídeo completo ou inspecione amostras suficientes de todas as cenas.
- Verifique a composição em tamanho de celular.
- Corrija textos cortados, sobreposições, erros de português, transições bruscas e problemas de sincronização.
- Confirme que as métricas estão corretas e legíveis.
- Confira se o print é o original e se os números não foram alterados.
- Verifique se o CTA final permanece tempo suficiente na tela.
- Confirme que o vídeo começa com o material original da campanha.
- Renderize novamente caso encontre problemas.

Não considere o projeto concluído apenas porque o código compilou. O resultado precisa ser visualmente revisado.

## 10. Entrega

Entregue:
1. O vídeo final renderizado em MP4, pronto para publicar no Instagram Reels.
2. O código-fonte Remotion utilizado.
3. Uma breve descrição da estrutura narrativa e das decisões de edição.
4. A confirmação da duração, resolução e taxa de quadros do arquivo final.

Se alguma ferramenta, arquivo ou recurso necessário estiver indisponível, informe exatamente qual é a limitação e implemente a melhor alternativa possível.

**Prioridade máxima:** criar um vídeo de prova social que pareça uma peça publicitária profissional de uma agência de marketing, usando um resultado real de Clevelândia para despertar o interesse de outros empresários e gerar conversas comerciais para a Evoquex.