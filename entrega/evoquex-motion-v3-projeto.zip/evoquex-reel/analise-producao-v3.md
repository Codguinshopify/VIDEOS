# Análise de produção — Evoquex V3

## Auditoria antes da implementação

A V2 tem nove blocos, mas repete a mesma distribuição de título, cartão e imagem circular. Há pausas visuais longas entre as entradas. A ligação do documento ao número depende sobretudo de zoom e desfoque; falta uma relação gráfica persistente. O carrossel muda objetos de posição, sem desenvolver um sistema visual próprio. O áudio usa osciladores, ruído e plucks simples, com pouca variação de instrumentação.

Projeto verificado: React 19.3.1, Remotion e @remotion/media 4.0.535, Chromium 154, FFmpeg 7.1.5. Studio responde HTTP 200 na porta 3001. Os três materiais originais estão disponíveis. A nova referência tem o mesmo SHA-256 da referência anterior: 39bc21037a522d3088630fcf79b9da61cc759c31b5386c39759e074283395a8c.

## Referência: observações e aplicação concreta

A referência de 27,77 s foi decodificada integralmente e examinada em sequências de frames ao longo de toda a duração. Essa inspeção permite avaliar composição e evolução temporal; não equivale a uma sessão humana de reprodução audiovisual. A interface não fornece um player com escuta ao agente.

| Trecho aproximado | Construção observada | Aplicação na V3 |
| --- | --- | --- |
| 0–3 s | Palavra, símbolo e documento assumem o foco em sequência; os demais planos perdem contraste | O anúncio permanece reconhecível; a frase é revelada por máscaras, e seus cantos definem o recorte que sai da tela cheia |
| 3–6 s | Contraste escuro, mudança de escala e foco; câmera atravessa objetos | O recorte do anúncio abre espaço para a cidade; a mesma linha azul liga a origem da campanha à praça fotografada |
| 6–10 s | Documentos verticais com planos de profundidade e troca coordenada do primeiro plano | Documento real em perspectiva; linha de chamada parte do indicador fotografado e conduz à métrica tipográfica |
| 10–14 s | Controles vetoriais, ondas e palavras compartilham o mesmo ritmo | Máscaras de dígitos e trajetórias de distribuição; impressões mantêm nomenclatura correta e comprovação própria |
| 14–18 s | Repetições tipográficas, escala e foco produzem profundidade | A palavra “alcançar” tem ecos recortados em planos; uma trajetória une o anúncio a um estabelecimento vetorial conceitual |
| 18–23 s | Objetos pequenos, poucas palavras e pausas alternam com cenas mais densas | A trajetória se expande em composição de oportunidade; o conteúdo mantém hierarquia e tempo de leitura |
| 23–28 s | CTA simples após a aceleração, com símbolo e marca sustentados | A forma do estabelecimento dá origem ao botão; pergunta e chamada permanecem legíveis, com Evoquex em texto, sem logotipo inventado |

Técnicas previstas: máscaras de palavras e de imagem; vetores traçados por comprimento; recortes da fotografia; projeção da anotação no mesmo plano da imagem; parallax; troca de foco; câmera por escala/posição; morph de moldura retangular para abertura curva; continuidade de trajetória entre blocos; antecipação e acomodação por curvas bezier e molas. As marcações são gráficos autorais, sem recriar o Gerenciador de Anúncios.

## Recursos avaliados

Skills efetivamente lidas: cloud-environment-onboarding:setup; remotion-best-practices; remotion-create; remotion-markup, incluindo video-editing; remotion-render. Não foram instaladas skills novas. As técnicas visuais podem ser realizadas com SVG/CSS e os recursos já instalados; nenhuma biblioteca JavaScript adicional é necessária.

Fontes oficiais Manrope e OFL obtidas do repositório google/fonts. FluidSynth já está instalado como biblioteca compartilhada. GeneralUser GS foi obtido do repositório do autor, commit 684543d5e5efaef08d02be50dcda8d552478fa60. Sua licença permite criação musical privada ou comercial. O arquivo de licença é preservado. A composição musical será nova, com instrumentos amostrados, arranjo e mixagem próprios; nenhum demo MIDI ou gravação de terceiros será reutilizado. Sites de catálogo de música e a documentação web consultada responderam bloqueio de rede; isso não impede usar os recursos locais e os repositórios acessíveis.

## Métricas e limitações materiais

13.064 é alcance; 20.981 são impressões. Não foi fornecido documento que comprove 20 mil visualizações. A peça exibirá somente os indicadores documentados. Não se apresentará a distribuição vetorial como mapa de usuários reais ou dado geográfico da plataforma.

O vídeo disponível tem 5,06 s, e a fotografia da cidade tem 600 × 337 px. O anúncio será recortado e retomado em momentos específicos, sem inventar nova filmagem. A fotografia terá escala limitada para evitar ampliação excessiva. Não existe logotipo oficial fornecido; a marca será escrita como texto.

## Direção de som e revisão

Nova composição instrumental: piano elétrico, baixo e bateria com dinâmica, sem melodia de sinos nem reaproveitamento da trilha V2. Efeitos separados por função: mudança de plano, extração da prova, revelação numérica e fechamento. O áudio original será preservado na abertura e a música será atenuada nessa passagem. Mixagem final com folga de pico e análise de loudness, clipping, continuidade e decodificação integral.

A revisão visual inclui frames de toda a duração e amostras mais densas nas transições, além de leitura em resolução de telefone. A revisão sonora disponível é técnica; não será alegada uma audição subjetiva que a interface não oferece.
