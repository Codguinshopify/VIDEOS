# Revisão da V3

## Processo e correções

A auditoria do projeto e a análise técnica da referência precederam a implementação. A primeira passagem por stills detectou flashes vazios nas transições e uma composição de oportunidade que parava cedo. As máscaras foram trocadas por revelações da próxima cena sobre a anterior, mantendo imagem durante toda a passagem. A composição de oportunidade recebeu uma rede vetorial em etapas, movimento entre planos e mudança de foco para o estabelecimento que origina o CTA. A palavra “alcançar” foi refeita com transformação e acomodação por letra. A música foi composta novamente, com outra instrumentação e arranjo.

O draft foi renderizado e revisado; as correções foram incorporadas antes de renderizar o MP4 final. A V2 foi preservada.

## Revisão visual do MP4 final

Foram examinadas 56 amostras de toda a duração, 35 quadros nas vizinhanças das cinco mudanças de cena e quatro telas em 360 × 640 (alcance, impressões, oportunidade e CTA). A revisão verificou composição, leitura, recortes, trajetórias e continuidade temporal. Não é alegada reprodução audiovisual humana da referência ou do resultado.

A abertura mantém a pessoa e as legendas originais reconhecíveis. A fotografia continua sendo a de Clevelândia e a marcação acompanha o mesmo plano da praça. O print aparece por regiões: Alcance e Impressões. As linhas de chamada saem das regiões documentadas e conduzem à tipografia, sem reconstrução de interface. Os valores finais são 13.064 pessoas alcançadas e 20.981 impressões; não há visualizações sem comprovação. Os gráficos de pessoas são conceituais, não dados de localização de usuários.

O CTA mantém a pergunta inteira e a chamada legíveis após a acomodação. Não foram observados cortes dos números ou colisões com os textos de leitura nas quatro telas de telefone. Os quadros com letras parcialmente reveladas nas pranchas pertencem ao movimento das máscaras, antes da acomodação.

## Avaliação específica de motion design

Comparação com a V2: a cidade passa de um recorte circular isolado para um plano com anotação projetada; a prova passa a ter ligação gráfica persistente com o número; a sequência das impressões tem composição própria em azul; a conexão comercial é construída por uma rede vetorial em etapas; a palavra central usa movimentos por letra em profundidade; a forma do estabelecimento conduz ao botão do CTA. Há alternância entre maior densidade de elementos e espaços de leitura, sem apresentar dados inventados como UI real.

Comparação com a referência: foram aplicados planos com perspectiva, máscaras, hierarquia de foco, tipografia com movimento coordenado, objetos documentais, vetores traçados e contraste entre passagens claras/escuras. A Evoquex conserva materiais e identidade próprios. Equivalência de qualidade estética é um julgamento subjetivo; esta revisão descreve o que foi executado e observado, sem afirmar aprovação pelo usuário.

## Verificação técnica integral

- Imagem: 840 frames, 1080 × 1920, 30 fps, h264, yuv420p, BT.709 e faixa de vídeo.
- Duração: 28 s de imagem; contêiner 28.011 s incluindo término do AAC.
- Som: AAC estéreo 48 kHz; -17.4 LUFS, -1.5 dBTP; 0 amostras clipadas.
- Correlação do áudio exportado com a mixagem V3 no mesmo instante: 0.999938. A trilha antiga não é usada na composição principal.
- Decodificação completa de imagem e som: concluída sem erros.
- Os três arquivos originais mantêm seus SHA-256 e bytes.
- SHA-256 do MP4: 202feb74c963d3e57371b8c08411e19a7ae0038d349bcb85bcb2a2f4c40d70f0.

## Limitações

A interface não permite escuta ao agente: a revisão sonora é técnica e não substitui audição subjetiva. A referência foi examinada por sequências de frames e decodificação, sem avaliação auditiva. A fotografia original tem 600 × 337 pixels e o vídeo disponível tem 5,06 segundos; não foram inventadas tomadas, alta definição da cidade ou métricas adicionais. A licença dos instrumentos e as observações do autor estão preservadas em audio-sources/.

## Reprodução do pacote

O ZIP foi extraído em uma pasta limpa. npm ci --offline instalou 253 pacotes a partir do cache, o preflight confirmou todos os materiais e o Chromium renderizou os frames 270 e 795 da composição EvoquexPremium. Os 49 arquivos de código, mídia e dependências do pacote foram comparados byte a byte com o projeto validado. O ZIP foi refeito após acrescentar este registro, sem alteração desses arquivos.
