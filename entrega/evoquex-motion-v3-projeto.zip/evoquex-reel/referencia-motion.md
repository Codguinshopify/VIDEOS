# Leitura da referência e aplicação ao case

A referência fornecida tem 27,77 segundos e foi examinada ao longo de toda a duração, com amostragem visual a cada meio segundo e decodificação integral.

## Linguagem observada

- Fundo predominantemente claro, com uma passagem escura para contraste.
- Frases curtas compostas por palavras que entram, saem e mudam de escala.
- Objetos/documentos em camadas, com sombra e desfoque nos deslocamentos.
- Deslocamento de câmera entre grupos gráficos, com entrada e saída pelo eixo de profundidade.
- Carrossel de cartões verticais, realçando um objeto enquanto os demais perdem foco.
- Elementos que se transformam em outros por continuidade de escala e posição.
- Contornos, setas curvas e pequenos acentos que dirigem o olhar.
- Fecho comercial com composição legível, depois de um percurso visual mais rápido.

## Adaptação

A reedição usa apenas os materiais reais do case. O anúncio começa em tela cheia e se transforma em um cartão vertical; o contexto local entra como recorte da fotografia. O documento original é enquadrado por indicador e dá origem, por transições de escala/posição, à tipografia das métricas. O carrossel reúne anúncio, documento e cidade para levar a narrativa ao empresário. O encerramento usa uma chamada em formato de conversa, sem reconstruir aplicativos ou inventar mensagens de clientes.

A paleta combina branco, azul-marinho e ciano. O desfoque acontece durante o deslocamento e nas camadas de fundo; os elementos importantes permanecem nítidos no tempo de leitura. As animações são calculadas por frame, incluindo máscaras, deslocamentos, rolagem de dígitos, foco, sombras e câmera em perspectiva.

Não são reutilizados o logotipo, os textos, o áudio ou os elementos comerciais da referência. A trilha e os efeitos são originais e seguem os pontos de corte da reedição.

## Precisão dos resultados

O documento comprova 13.064 pessoas alcançadas e 20.981 impressões. Não foi fornecido um registro equivalente de visualizações; a versão 2 apresenta os dois indicadores documentados, sem converter impressões em visualizações.
