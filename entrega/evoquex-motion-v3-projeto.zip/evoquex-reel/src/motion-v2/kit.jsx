import React from 'react';
import {AbsoluteFill, Easing, Freeze, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';

export const palette = {paper: '#F6F7F5', ink: '#081B2C', blue: '#09B8DE', pale: '#D9F4FA', muted: '#687C89', night: '#071422'};
export const family = "'Open Sans', sans-serif";
const bounds = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'};
export const curve = Easing.bezier(.16, 1, .3, 1);
export const mix = (f, range, values, easing = curve) => interpolate(f, range, values, {...bounds, easing});
export const settle = (f, delay = 0, duration = 30) => spring({frame: f - delay, fps: 30, durationInFrames: duration, config: {damping: 21, stiffness: 130, mass: .85}});

export const Canvas = ({children, dark = false}) => <AbsoluteFill style={{background: dark ? palette.night : palette.paper, color: dark ? '#FFF' : palette.ink, fontFamily: family, overflow: 'hidden', perspective: 1500}}>{children}</AbsoluteFill>;

export const Word = ({children, at = 0, direction = 1, color, style = {}}) => {
  const f = useCurrentFrame();
  const p = settle(f, at, 27);
  return <span style={{display: 'inline-block', translate: `${(1 - p) * direction * 75}px ${(1 - p) * 38}px`, rotate: `${(1 - p) * direction * 7}deg`, opacity: mix(f - at, [0, 9], [0, 1]), filter: `blur(${(1 - p) * 9}px)`, color, ...style}}>{children}</span>;
};

export const Words = ({text, at = 0, color, style = {}}) => <div style={{fontSize: 86, fontWeight: 700, lineHeight: 1.1, letterSpacing: -4.5, ...style}}>{text.split(' ').map((word, index) => <React.Fragment key={index}><Word at={at + index * 3} direction={index % 2 ? -1 : 1} color={color}>{word}</Word>{index < text.split(' ').length - 1 ? ' ' : ''}</React.Fragment>)}</div>;

export const Film = ({trimBefore = 0, poster = null, volume = 0}) => {
  const {fps} = useVideoConfig();
  const video = <Video name="Vídeo real da Dany’s Presentes" src={staticFile('assets/DANYS.mp4')} trimBefore={trimBefore} premountFor={fps} volume={volume} objectFit="cover" style={{width: '100%', height: '100%'}} />;
  return poster === null ? <Sequence from={0} durationInFrames={150 - trimBefore} premountFor={fps}>{video}</Sequence> : <Freeze frame={poster}>{video}</Freeze>;
};

export const Phone = ({x = 220, y = 440, width = 540, rotate = 0, yaw = 0, scale = 1, opacity = 1, blur = 0, trimBefore = 0, poster = null, volume = 0, full = false}) => <div style={{position: 'absolute', left: x, top: y, width, height: width * 1920 / 1080, opacity, filter: `blur(${blur}px)`, transform: `perspective(1400px) rotateY(${yaw}deg) rotateZ(${rotate}deg) scale(${scale})`, transformOrigin: '50% 50%', borderRadius: full ? 0 : 48, border: full ? '0' : '10px solid #0C2030', background: palette.ink, boxShadow: full ? 'none' : '0 35px 85px rgba(8,27,44,.2),0 5px 14px rgba(8,27,44,.12)', overflow: 'hidden'}}>
  <Film trimBefore={trimBefore} poster={poster} volume={volume} />
  {!full ? <div style={{position: 'absolute', top: 10, left: '39%', width: '22%', height: 10, borderRadius: 8, background: '#05111F', opacity: .8}} /> : null}
</div>;

export const CityOrb = ({x = 550, y = 1050, size = 590, rotate = 0, blur = 0, opacity = 1, scale = 1, label = true}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: x, top: y, width: size, opacity, filter: `blur(${blur}px)`, transform: `rotate(${rotate}deg) scale(${scale})`}}>
    <div style={{height: size, borderRadius: '50%', border: '10px solid #FFF', overflow: 'hidden', boxShadow: '0 22px 55px rgba(8,27,44,.16)'}}><Img src={staticFile('assets/clevelandia.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: '49% 55%', scale: mix(f, [0, 180], [1.04, 1.11]), translate: `${mix(f, [0, 180], [-8, 6])}px 0`}} /></div>
    {label ? <div style={{textAlign: 'center', fontSize: 38, color: palette.muted, marginTop: 25, fontWeight: 600, letterSpacing: -1}}>Clevelândia, PR</div> : null}
  </div>;
};

export const roiReach = {x: 420, y: 840, width: 460, height: 430, focusX: 657, focusY: 1070};
export const roiImpressions = {x: 30, y: 735, width: 520, height: 405, focusX: 279, focusY: 974};

export const DocumentPlane = ({kind = 'reach', x = 130, y = 560, width = 820, zoom = 1, rotate = -6, yaw = -8, blur = 0, opacity = 1, mark = 1}) => {
  const roi = kind === 'reach' ? roiReach : roiImpressions;
  const ratio = width / roi.width;
  const height = roi.height * ratio;
  const cx = (roi.focusX - roi.x) * ratio;
  const cy = (roi.focusY - roi.y) * ratio;
  return <div style={{position: 'absolute', left: x, top: y, width, height, opacity, filter: `blur(${blur}px)`, transform: `perspective(1400px) rotateY(${yaw}deg) rotateZ(${rotate}deg) scale(${zoom})`, transformOrigin: `${cx}px ${cy}px`, borderRadius: 26, border: '8px solid #FFF', boxShadow: '0 30px 65px rgba(8,27,44,.14),0 4px 12px rgba(8,27,44,.08)', overflow: 'hidden', background: '#DFE1DD'}}>
    <Img src={staticFile('assets/resultados.jpg')} style={{position: 'absolute', width: 898 * ratio, height: 1601 * ratio, maxWidth: 'none', left: -roi.x * ratio, top: -roi.y * ratio}} />
    <svg width={width} height={height} style={{position: 'absolute', inset: 0, overflow: 'visible'}}><ellipse cx={cx} cy={cy} rx={137} ry={49} transform={`rotate(14 ${cx} ${cy})`} fill="none" stroke={palette.blue} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - mark} /></svg>
  </div>;
};

export const StrokeArrow = ({x = 100, y = 100, width = 700, height = 400, progress = 1, color = palette.ink, rotate = 0}) => <svg width={width} height={height} viewBox="0 0 700 400" style={{position: 'absolute', left: x, top: y, overflow: 'visible', rotate: `${rotate}deg`}}><path d="M65 320 C90 80,390 345,595 110 M540 105L603 104L590 168" fill="none" stroke={color} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1 - progress} /></svg>;

export const RollingNumber = ({value, at = 0, size = 244}) => {
  const f = useCurrentFrame();
  const text = new Intl.NumberFormat('pt-BR').format(value);
  const line = size * 1.16;
  return <div data-review="metric" style={{display: 'flex', justifyContent: 'center', height: line, fontWeight: 700, fontSize: size, lineHeight: `${line}px`, fontVariantNumeric: 'tabular-nums', letterSpacing: -9}}>
    {[...text].map((char, index) => char === '.' ? <div key={index} style={{width: size * .2, color: palette.blue, alignSelf: 'center'}}>.</div> : <div key={index} style={{position: 'relative', width: size * .6, height: line, overflow: 'hidden'}}><div style={{translate: `0 ${mix(f - at - index * 2, [0, 28], [-2 * line, 0])}px`, filter: `blur(${mix(f - at - index * 2, [0, 8, 28], [7, 7, 0])}px)`}}>{[0, 1, 2].map((n) => <div key={n} style={{height: line, textAlign: 'center'}}>{char}</div>)}</div></div>)}
  </div>;
};

export const Capsule = ({children, color = palette.blue, style = {}}) => <div style={{display: 'inline-flex', alignItems: 'center', borderRadius: 22, padding: '18px 30px', background: color, color: palette.ink, fontSize: 39, fontWeight: 700, letterSpacing: -1, ...style}}>{children}</div>;
