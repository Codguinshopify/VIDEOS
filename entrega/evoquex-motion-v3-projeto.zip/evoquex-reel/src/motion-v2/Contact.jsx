import React from 'react';
import {Interactive, useCurrentFrame} from 'remotion';
import {Canvas, mix, palette, Phone, settle, StrokeArrow, Words} from './kit';

const Contact = () => {
  const f = useCurrentFrame();
  const pop = settle(f, 28, 35);
  return <Canvas>
    <div style={{position: 'absolute', left: 90, top: 205, width: 900, fontSize: 49, fontWeight: 700, letterSpacing: 4, textAlign: 'center', opacity: mix(f, [0, 17], [0, 1])}}>EVOQUEX</div>
    <div style={{position: 'absolute', left: 90, top: 335, width: 900, textAlign: 'center'}}><Words text="Vamos trabalhar" at={3} style={{fontSize: 86}} /><Words text="a divulgação da" at={10} style={{fontSize: 84, marginTop: 6}} /><Words text="sua empresa?" at={18} color={palette.blue} style={{fontSize: 99, marginTop: 6}} /></div>
    <Phone x={mix(f, [0, 37], [-260, 110])} y={mix(f, [0, 37], [1020, 860])} width={345} rotate={mix(f, [0, 37], [-19, -7])} yaw={-12} blur={mix(f, [0, 25], [8, 0])} />
    <div style={{position: 'absolute', left: 465, top: 1000, width: 525, height: 202, transform: `translateY(${(1 - pop) * 65}px) scale(${.78 + pop * .22})`, opacity: mix(f, [28, 42], [0, 1]), transformOrigin: '12% 85%'}}>
      <svg width="525" height="220" viewBox="0 0 525 220" style={{position: 'absolute', inset: 0}}><path d="M45 8H481Q517 8 517 47V158Q517 197 479 197H92L49 218L55 197H45Q8 197 8 158V47Q8 8 45 8Z" fill={palette.blue} /></svg>
      <div data-review="cta" style={{position: 'absolute', left: 46, top: 48, fontSize: 58, lineHeight: 1.12, fontWeight: 700, letterSpacing: -2}}>Fale com<br />a Evoquex.</div>
    </div>
    <StrokeArrow x={320} y={1190} width={510} height={320} progress={mix(f, [49, 84], [0, 1])} rotate={-24} />
    <div style={{position: 'absolute', left: 420, top: 1540, width: 540, color: palette.muted, fontSize: 36, opacity: mix(f, [65, 88], [0, 1])}}>Sua empresa.<br /><span style={{color: palette.ink, fontWeight: 600}}>O público certo.</span></div>
  </Canvas>;
};

export const MotionContact = Interactive.withSchema({Component: Contact, componentName: '<MotionContact>', schema: {}, wrapInSequence: true});
