import React from 'react';
import {AbsoluteFill, Interactive, useCurrentFrame} from 'remotion';
import {Canvas, mix, palette, Phone, Word, Words} from './kit';

const Intro = () => {
  const f = useCurrentFrame();
  const pull = mix(f, [70, 106], [0, 1]);
  return <Canvas>
    <Phone x={170 * pull} y={440 * pull} width={1080 - 560 * pull} rotate={-6 * pull} yaw={-9 * pull} full={pull < .01} volume={mix(f, [93, 108], [.82, 0])} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg,rgba(0,9,19,.52),rgba(0,9,19,.24) 32%,transparent 49%)', opacity: 1 - pull}} />
    <div style={{position: 'absolute', left: 85, top: 190, opacity: mix(f, [68, 94], [1, 0]), color: '#FFF', fontSize: 33, fontWeight: 600, letterSpacing: 1.5}}>DANY’S PRESENTES</div>
    <div style={{position: 'absolute', left: 85, top: mix(f, [72, 105], [325, 215]), width: 910, transform: `scale(${mix(f, [72, 105], [1, .83])})`, transformOrigin: 'left top', color: pull > .72 ? palette.ink : '#FFF', textShadow: pull > .72 ? 'none' : '0 4px 28px rgba(0,0,0,.45)'}}>
      <Words text="Você chegou" at={3} style={{fontSize: 91}} />
      <Words text="a ver esse vídeo?" at={10} style={{fontSize: 95}} />
    </div>
    <div style={{position: 'absolute', left: 710, top: 750, width: 330, opacity: mix(f, [80, 95], [0, 1]), rotate: '-5deg'}}><Words text="em" at={75} style={{fontSize: 58, letterSpacing: -2}} /><Words text="Clevelândia?" at={79} color={palette.blue} style={{fontSize: 55, letterSpacing: -3}} /></div>
    <div style={{position: 'absolute', left: 110, top: 1570, opacity: pull, color: palette.muted, fontSize: 40}}><Word at={83}>Um vídeo real.</Word><br /><Word at={88} color={palette.ink}>Uma divulgação local.</Word></div>
  </Canvas>;
};

export const MotionIntro = Interactive.withSchema({Component: Intro, componentName: '<MotionIntro>', schema: {}, wrapInSequence: true});
