import React from 'react';
import {Interactive, useCurrentFrame, useVideoConfig} from 'remotion';
import {Canvas, CityOrb, mix, palette, Phone, StrokeArrow, Words} from './kit';

const Local = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <Canvas>
    <Phone x={mix(f, [10, 36], [170, -620])} y={mix(f, [10, 36], [440, 570])} width={520} rotate={mix(f, [10, 36], [-6, -18])} yaw={-9} blur={mix(f, [10, 30], [0, 9])} opacity={mix(f, [28, 37], [1, 0])} trimBefore={3.8 * fps} />
    <CityOrb x={mix(f, [0, 55], [760, 198])} y={mix(f, [0, 55], [1060, 890])} size={mix(f, [0, 55], [360, 730])} rotate={mix(f, [0, 30], [16, -4])} blur={mix(f, [0, 25], [10, 0])} label={false} />
    <div style={{position: 'absolute', left: 90, top: 265, width: 900}}><Words text="Nós fizemos essa" at={1} style={{fontSize: 74}} /><Words text="divulgação chegar" at={5} style={{fontSize: 83}} /><Words text="mais longe." at={13} color={palette.blue} style={{fontSize: 119, marginTop: 12}} /></div>
    <StrokeArrow x={140} y={575} width={690} height={395} progress={mix(f, [15, 46], [0, 1])} rotate={-8} />
    <div style={{position: 'absolute', left: 285, top: 1660, fontSize: 43, color: palette.muted, opacity: mix(f, [28, 43], [0, 1])}}>Aqui. Em Clevelândia.</div>
  </Canvas>;
};

export const MotionLocal = Interactive.withSchema({Component: Local, componentName: '<MotionLocal>', schema: {}, wrapInSequence: true});
