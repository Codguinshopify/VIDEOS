import React from 'react';
import {Interactive, useCurrentFrame} from 'remotion';
import {Canvas, mix, palette, Phone, StrokeArrow, Words} from './kit';

const Strategy = () => {
  const f = useCurrentFrame();
  return <Canvas dark>
    <Phone x={mix(f, [0, 38], [-290, 85])} y={1160} width={330} rotate={-8} yaw={-12} poster={50} opacity={.78} />
    <div style={{position: 'absolute', left: 100, top: 620, width: 880, textAlign: 'center', opacity: mix(f, [26, 40], [1, 0]), scale: mix(f, [0, 34], [.92, 1.08])}}><Words text="Publicar" at={0} style={{fontSize: 140, color: '#FFF'}} /><Words text="é o início." at={8} style={{fontSize: 87, color: '#FFF'}} /></div>
    <div style={{position: 'absolute', left: 80, top: 500, width: 920, textAlign: 'center', opacity: mix(f, [28, 42], [0, 1])}}><Words text="Fazer chegar" at={28} color={palette.blue} style={{fontSize: 109}} /><Words text="é estratégia." at={36} style={{fontSize: 91, color: '#FFF', marginTop: 12}} /></div>
    <StrokeArrow x={250} y={915} width={620} height={390} progress={mix(f, [37, 68], [0, 1])} color={palette.blue} rotate={-24} />
  </Canvas>;
};

export const MotionStrategy = Interactive.withSchema({Component: Strategy, componentName: '<MotionStrategy>', schema: {}, wrapInSequence: true});
