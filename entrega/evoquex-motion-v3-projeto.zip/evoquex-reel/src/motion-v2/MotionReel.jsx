import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig, staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {mix, palette} from './kit';
import {MotionIntro} from './Intro';
import {MotionLocal} from './Local';
import {MotionReachDocument, MotionImpressionsDocument} from './Document';
import {MotionReach, MotionImpressions} from './Metric';
import {MotionOpportunity} from './Opportunity';
import {MotionStrategy} from './Strategy';
import {MotionContact} from './Contact';

export const EvoquexMotion = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const darkCut = mix(f, [615, 624, 633], [0, 1, 0]);
  const lightCut = mix(f, [700, 708, 716], [0, 1, 0]);
  return <AbsoluteFill style={{background: palette.paper}}>
    <MotionIntro name="Reconhecimento — vídeo vira cartão" from={0} durationInFrames={114} premountFor={fps} />
    <MotionLocal name="Contexto — cidade em profundidade" from={3.8 * fps} durationInFrames={72} premountFor={fps} />
    <MotionReachDocument name="Origem — foco no alcance do documento" from={6.2 * fps} durationInFrames={75} premountFor={fps} />
    <MotionReach name="Revelação — 13.064 pessoas" from={8.7 * fps} durationInFrames={93} premountFor={fps} />
    <MotionImpressionsDocument name="Origem — foco nas impressões" from={11.8 * fps} durationInFrames={72} premountFor={fps} />
    <MotionImpressions name="Distribuição — 20.981 impressões" from={14.2 * fps} durationInFrames={69} premountFor={fps} />
    <MotionOpportunity name="Conexão — carrossel do case ao empresário" from={16.5 * fps} durationInFrames={129} premountFor={fps} />
    <MotionStrategy name="Estratégia — contraste e tipografia" from={20.8 * fps} durationInFrames={84} premountFor={fps} />
    <MotionContact name="Convite — composição de conversa" from={23.6 * fps} durationInFrames={132} premountFor={fps} />
    <Audio name="Sound design original da reedição" src={staticFile('assets/evoquex-motion.wav')} premountFor={fps} volume={mix(f, [0, 95, 125], [.18, .18, 1])} />
    <div style={{position: 'absolute', inset: 0, background: palette.night, clipPath: `circle(${darkCut * 130}% at 90% 70%)`, pointerEvents: 'none'}} />
    <div style={{position: 'absolute', inset: 0, background: palette.paper, clipPath: `circle(${lightCut * 130}% at 15% 60%)`, pointerEvents: 'none'}} />
  </AbsoluteFill>;
};
