import React from 'react';
import {Interactive, useCurrentFrame} from 'remotion';
import {Canvas, Capsule, CityOrb, DocumentPlane, mix, palette, Phone, RollingNumber, Words} from './kit';
import {documentPose} from './Document';

const Metric = ({kind}) => {
  const f = useCurrentFrame();
  const reach = kind === 'reach';
  return <Canvas>
    <div style={{position: 'absolute', left: 100, top: 270, width: 880, textAlign: 'center', opacity: mix(f, [6, 22], [0, 1])}}><Words text={reach ? 'Mais de 13 mil.' : 'O conteúdo circulou.'} at={7} style={{fontSize: 79}} /></div>
    <div style={{position: 'absolute', left: 90, top: 585, width: 900, textAlign: 'center', opacity: mix(f, [5, 21], [0, 1])}}><Capsule color={palette.pale}>{reach ? 'ALCANCE LOCAL' : 'DISTRIBUIÇÃO DO CONTEÚDO'}</Capsule></div>
    <div style={{position: 'absolute', left: 75, top: 690, width: 930, transform: `scale(${mix(f, [0, 32], [.88, 1])})`, opacity: mix(f, [0, 12], [0, 1])}}><RollingNumber value={reach ? 13064 : 20981} at={0} /></div>
    <div style={{position: 'absolute', left: 90, top: 1000, width: 900, textAlign: 'center'}}><Words text={reach ? 'pessoas alcançadas' : 'impressões'} at={19} style={{fontSize: 65, letterSpacing: -2.7}} /></div>
    <Phone x={mix(f, [0, 32], [-240, 65])} y={mix(f, [0, 32], [1210, 1180])} width={340} rotate={mix(f, [0, 32], [18, -6])} yaw={-12} blur={mix(f, [0, 27], [8, 0])} trimBefore={reach ? 0 : 60} />
    <CityOrb x={mix(f, [0, 38], [940, 610])} y={mix(f, [0, 38], [1290, 1210])} size={500} rotate={mix(f, [0, 38], [-15, 4])} blur={mix(f, [0, 31], [11, 0])} label={false} />
    <div style={{position: 'absolute', left: 90, top: 1110, width: 900, textAlign: 'center', opacity: mix(f, [26, 42], [0, 1]), color: palette.muted, fontSize: 37}}>{reach ? 'Clevelândia, PR' : 'R$ 50 em mídia · 2 dias'}</div>
    <DocumentPlane {...documentPose(74, kind)} opacity={mix(f, [0, 13], [1, 0])} blur={mix(f, [0, 13], [0, 13])} mark={0} />
  </Canvas>;
};

const Reach = () => <Metric kind="reach" />;
const Impressions = () => <Metric kind="impressions" />;
export const MotionReach = Interactive.withSchema({Component: Reach, componentName: '<MotionReach>', schema: {}, wrapInSequence: true});
export const MotionImpressions = Interactive.withSchema({Component: Impressions, componentName: '<MotionImpressions>', schema: {}, wrapInSequence: true});
