import React from 'react';
import {Interactive, useCurrentFrame} from 'remotion';
import {Canvas, CityOrb, DocumentPlane, mix, palette, Phone, Word, Words} from './kit';

const Opportunity = () => {
  const f = useCurrentFrame();
  const pan = mix(f, [0, 48], [0, 1]);
  return <Canvas>
    <DocumentPlane kind="reach" x={mix(f, [0, 48], [-530, -240])} y={mix(f, [0, 48], [520, 1140])} width={550} zoom={1} rotate={-10} yaw={25} opacity={.23} blur={8} mark={0} />
    <CityOrb x={mix(f, [0, 48], [1050, 740])} y={mix(f, [0, 48], [610, 1210])} size={530} rotate={7} blur={6} opacity={.7} label={false} />
    <Phone x={mix(f, [0, 48], [300, 130])} y={mix(f, [0, 48], [530, 1160])} width={mix(f, [0, 48], [480, 340])} rotate={mix(f, [0, 48], [5, -7])} yaw={mix(f, [0, 48], [-15, -6])} />
    <div style={{position: 'absolute', left: 90, top: 265, width: 900, textAlign: 'center', opacity: mix(f, [0, 30], [1, 0]), transform: `translateX(${pan * -90}px)`}}><Words text="Um case real." at={0} style={{fontSize: 90}} /></div>
    <div style={{position: 'absolute', left: 90, top: 365, width: 900, textAlign: 'center', opacity: mix(f, [25, 44], [0, 1])}}>
      <Words text="Sua empresa" at={25} style={{fontSize: 95}} />
      <Words text="também pode" at={34} style={{fontSize: 93, marginTop: 9}} />
      <Words text="alcançar" at={42} style={{fontSize: 105, marginTop: 9}} />
      <div style={{position: 'relative', marginTop: 15}}>
        <div style={{position: 'absolute', left: 0, top: 24, width: '100%', fontSize: 102, fontWeight: 700, letterSpacing: -5, opacity: mix(f, [49, 72, 118], [.05, .15, 0]), color: palette.blue, filter: 'blur(2px)'}}>mais pessoas.</div>
        <Words text="mais pessoas." at={49} color={palette.blue} style={{fontSize: 102}} />
      </div>
    </div>
    <div style={{position: 'absolute', left: 550, top: 1665, color: palette.muted, fontSize: 38, opacity: mix(f, [62, 83], [0, 1])}}><Word at={60}>Com divulgação</Word><br /><Word at={66}>estratégica.</Word></div>
  </Canvas>;
};

export const MotionOpportunity = Interactive.withSchema({Component: Opportunity, componentName: '<MotionOpportunity>', schema: {}, wrapInSequence: true});
