import React from 'react';
import {AbsoluteFill, Interactive, interpolate, Sequence, useCurrentFrame, useVideoConfig} from 'remotion';
import {AccentLine, CampaignFilm, C, City, clamp, Count, ease, Headline, Label, Rise, Stage} from '../design';

const Revelation = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <Stage>
    <Sequence from={0} durationInFrames={30} premountFor={fps}><div style={{position: 'absolute', inset: 0, opacity: interpolate(f, [18, 30], [1, 0], clamp)}}>
      <CampaignFilm trimBefore={4 * fps} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg,rgba(2,11,23,.87),rgba(2,11,23,.42) 75%,#061529)'}} />
    </div></Sequence>
    <div style={{position: 'absolute', left: 0, top: 850, width: 1080, height: 650, clipPath: `inset(0 ${interpolate(f, [18, 34], [100, 0], {...clamp, easing: ease})}% 0 0)`}}><City /></div>
    <div style={{position: 'absolute', left: 90, top: 245, width: 900, opacity: interpolate(f, [48, 62], [1, 0], clamp)}}>
      <Label>DA PUBLICAÇÃO AO PÚBLICO CERTO</Label>
      <Headline style={{marginTop: 46, fontSize: 82}}><Rise delay={4}>Nós fizemos essa</Rise><Rise delay={9}>divulgação chegar</Rise><Rise delay={14} style={{color: C.cyan}}>muito mais longe.</Rise></Headline>
    </div>
    <div style={{position: 'absolute', left: 88, top: 275, opacity: interpolate(f, [62, 76], [0, 1], clamp)}}>
      <Label style={{color: C.cyan}}>RESULTADO DA CAMPANHA</Label>
      <div data-review="reach" style={{fontSize: 182, lineHeight: 1.1, fontWeight: 700, letterSpacing: -11, marginTop: 30, fontVariantNumeric: 'tabular-nums'}}><Count value={13064} start={64} end={100} /></div>
      <Headline style={{fontSize: 68, letterSpacing: -2, marginTop: 22}}>pessoas alcançadas<br />em Clevelândia.</Headline>
      <AccentLine delay={78} style={{marginTop: 45}} />
    </div>
    <div style={{position: 'absolute', left: 90, top: 1570, opacity: interpolate(f, [82, 100], [0, 1], clamp)}}><Label>CLEVELÂNDIA · PARANÁ</Label></div>
  </Stage>;
};

export const RevelationScene = Interactive.withSchema({Component: Revelation, componentName: '<RevelationScene>', schema: {}, wrapInSequence: true});
