import React from 'react';
import {Interactive, interpolate, useCurrentFrame} from 'remotion';
import {AccentLine, C, City, clamp, ease, Headline, Label, Rise, Stage} from '../design';

const Connection = () => {
  const f = useCurrentFrame();
  return <Stage>
    <div style={{position: 'absolute', top: 860, left: 0, width: 1080, height: 600, clipPath: `inset(0 0 ${interpolate(f, [0, 30], [100, 0], {...clamp, easing: ease})}% 0)`}}><City /></div>
    <div style={{position: 'absolute', left: 90, top: 205, width: 900}}>
      <Label>PARA QUEM EMPREENDE AQUI</Label>
      <Headline style={{fontSize: 82, marginTop: 40}}>
        <Rise delay={5}>Sua empresa</Rise>
        <Rise delay={10}>também pode ser</Rise>
        <Rise delay={15}>vista por</Rise>
        <Rise delay={20} style={{color: C.cyan}}>muito mais pessoas.</Rise>
      </Headline>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1510, width: 890}}>
      <AccentLine delay={28} style={{marginBottom: 30}} />
      <Rise delay={35} style={{fontSize: 46, lineHeight: 1.25, fontWeight: 600}}>Mais do que publicar.<br /><span style={{color: C.cyan}}>Chegar ao público certo.</span></Rise>
    </div>
  </Stage>;
};

export const ConnectionScene = Interactive.withSchema({Component: Connection, componentName: '<ConnectionScene>', schema: {}, wrapInSequence: true});
