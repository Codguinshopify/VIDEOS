import React from 'react';
import {Interactive, interpolate, useCurrentFrame} from 'remotion';
import {AccentLine, C, clamp, ease, Headline, Label, Rise, Stage} from '../design';

const Closing = () => {
  const f = useCurrentFrame();
  return <Stage>
    <div style={{position: 'absolute', left: 90, top: 240}}><Rise delay={4}><Label style={{fontSize: 48, letterSpacing: 5, color: C.white}}>EVOQUEX</Label></Rise><AccentLine delay={10} style={{marginTop: 30, width: 164}} /></div>
    <div style={{position: 'absolute', left: 88, top: 565, width: 904}}>
      <Headline style={{fontSize: 94, lineHeight: 1.1}}><Rise delay={7}>Vamos trabalhar</Rise><Rise delay={12}>a divulgação</Rise><Rise delay={17}>da sua</Rise><Rise delay={22} style={{color: C.cyan}}>empresa?</Rise></Headline>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1320, width: 900, height: 142, background: C.cyan, borderRadius: 12, display: 'flex', alignItems: 'center', padding: '0 44px', justifyContent: 'space-between', opacity: interpolate(f, [33, 50], [0, 1], clamp), translate: `0 ${interpolate(f, [33, 62], [35, 0], {...clamp, easing: ease})}px`}}>
      <div data-review="cta" style={{color: C.deep, fontSize: 50, letterSpacing: -1.8, fontWeight: 700}}>Fale com a Evoquex.</div>
      <svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true"><path d="M10 28h34M29 13l15 15-15 15" stroke={C.deep} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1550, opacity: interpolate(f, [52, 72], [0, 1], clamp)}}><Label style={{fontSize: 28, letterSpacing: 1.3}}>DIVULGAÇÃO ESTRATÉGICA PARA O COMÉRCIO LOCAL</Label></div>
  </Stage>;
};

export const ClosingScene = Interactive.withSchema({Component: Closing, componentName: '<ClosingScene>', schema: {}, wrapInSequence: true});
