import React from 'react';
import {Interactive, interpolate, useCurrentFrame} from 'remotion';
import {AccentLine, C, clamp, ease, Headline, Label, OriginalResults, Rise, Stage} from '../design';

const Proof = () => {
  const f = useCurrentFrame();
  return <Stage>
    <div style={{position: 'absolute', left: 90, top: 200, width: 900}}>
      <Label>PROVA REAL · DANY’S PRESENTES</Label>
      <Headline style={{fontSize: 87, marginTop: 35}}><Rise delay={5}>Os números</Rise><Rise delay={10} style={{color: C.cyan}}>estão aqui.</Rise></Headline>
    </div>
    <div style={{position: 'absolute', left: 90, top: 510, width: 900, height: 555, borderRadius: 16, overflow: 'hidden', border: '2px solid #7890A0', boxShadow: '0 32px 80px rgba(0,0,0,.26)', translate: `0 ${interpolate(f, [6, 35], [95, 0], {...clamp, easing: ease})}px`, opacity: interpolate(f, [6, 22], [0, 1], clamp)}}>
      <div style={{position: 'absolute', inset: 0, scale: interpolate(f, [25, 230], [1, 1.035], clamp)}}><OriginalResults /></div>
      <div style={{position: 'absolute', left: 0, top: 0, height: '100%', width: 5, background: C.cyan, scale: `1 ${interpolate(f, [32, 65], [0, 1], clamp)}`, transformOrigin: 'top'}} />
    </div>
    <div style={{position: 'absolute', left: 90, top: 1084}}><Label style={{fontSize: 23, letterSpacing: 1.5}}>PRINT ORIGINAL · GERENCIADOR DE ANÚNCIOS</Label></div>
    <div style={{position: 'absolute', left: 88, top: 1160, width: 430, opacity: interpolate(f, [45, 64], [0, 1], clamp)}}>
      <div data-review="reach" style={{fontSize: 98, lineHeight: 1, fontWeight: 700, letterSpacing: -6}}>13.064</div>
      <div style={{fontSize: 40, lineHeight: 1.15, marginTop: 20, color: C.soft}}>pessoas alcançadas</div>
    </div>
    <div style={{position: 'absolute', left: 562, top: 1160, width: 430, opacity: interpolate(f, [78, 96], [0, 1], clamp)}}>
      <div data-review="impressions" style={{fontSize: 98, lineHeight: 1, fontWeight: 700, letterSpacing: -6, color: C.cyan}}>20.981</div>
      <div style={{fontSize: 40, lineHeight: 1.15, marginTop: 20, color: C.soft}}>impressões</div>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1410, width: 900, opacity: interpolate(f, [116, 133], [0, 1], clamp)}}>
      <AccentLine delay={112} style={{marginBottom: 30}} />
      <div data-review="views" style={{fontSize: 55, fontWeight: 600, letterSpacing: -2}}>≈20 mil visualizações</div>
      <div style={{fontSize: 29, marginTop: 14, color: C.soft}}>Resultado informado da campanha.</div>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1600, opacity: interpolate(f, [165, 180], [0, 1], clamp)}}><Label style={{fontSize: 28, letterSpacing: 1}}>2 DIAS DE DIVULGAÇÃO · R$ 50 EM MÍDIA</Label></div>
  </Stage>;
};

export const ProofScene = Interactive.withSchema({Component: Proof, componentName: '<ProofScene>', schema: {}, wrapInSequence: true});
