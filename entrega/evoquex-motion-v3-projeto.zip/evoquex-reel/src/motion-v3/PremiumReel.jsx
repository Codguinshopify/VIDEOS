import React from 'react';
import {AbsoluteFill, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {C, glide, tween} from './system';
import {Recognition} from './Recognition';
import {Local} from './Local';
import {Reach, Impressions} from './Proof';
import {Opportunity} from './Opportunity';
import {Contact} from './Contact';

const Reveal = ({children, kind}) => {
  const f = useCurrentFrame();
  const p = tween(f, [0, 18], [0, 1], glide);
  const mask = kind === 'proof' ? `circle(${p * 145}% at 60% 58%)` : kind === 'impressions' ? `ellipse(${p * 160}% ${p * 110}% at 16% 73%)` : kind === 'story' ? `polygon(0 ${100 - p * 200}%,100% ${145 - p * 200}%,100% 100%,0 100%)` : `circle(${p * 150}% at 77% 70%)`;
  return <AbsoluteFill style={{clipPath: mask}}>{children}</AbsoluteFill>;
};

export const EvoquexPremium = () => {
  const f = useCurrentFrame(), {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: C.paper}}>
    <Sequence name="Reconhecimento — máscara do anúncio" from={0} durationInFrames={3.8 * fps} premountFor={fps}><Recognition/></Sequence>
    <Sequence name="Contexto — fotografia e trajetória local" from={3.8 * fps} durationInFrames={2.8 * fps + 18} premountFor={fps}><Local/></Sequence>
    <Sequence name="Prova — extração de 13.064 pessoas" from={6.6 * fps} durationInFrames={4 * fps + 18} premountFor={fps}><Reveal kind="proof"><Reach/></Reveal></Sequence>
    <Sequence name="Distribuição — 20.981 impressões" from={10.6 * fps} durationInFrames={4 * fps + 18} premountFor={fps}><Reveal kind="impressions"><Impressions/></Reveal></Sequence>
    <Sequence name="Oportunidade — da campanha à empresa" from={14.6 * fps} durationInFrames={6.2 * fps + 18} premountFor={fps}><Reveal kind="story"><Opportunity/></Reveal></Sequence>
    <Sequence name="Conversão — chamada da Evoquex" from={20.8 * fps} durationInFrames={7.2 * fps} premountFor={fps}><Reveal kind="cta"><Contact/></Reveal></Sequence>
    <Audio name="Mix V3 — composição, efeitos e fala original" src={staticFile('assets/evoquex-premium.wav')} premountFor={fps}/>
  </AbsoluteFill>;
};
