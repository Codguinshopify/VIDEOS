import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Base, C, Corners, cropDimensions, Evidence, Eyebrow, FilmPlane, MaskLine, Metric, Path, PlayToken, tween} from './system';

export const Reach = () => {
  const f = useCurrentFrame();
  const p = tween(f, [24, 65], [0, 1]);
  const x = 100 - 28 * p, y = 575 + 565 * p, w = 880 - 360 * p;
  const {cx, cy} = cropDimensions('reach', w);
  const sourceX = x + cx + 130, sourceY = y + cy + 45;
  return <Base>
    <Eyebrow>ALCANCE · DOCUMENTADO</Eyebrow>
    <div style={{position: 'absolute', left: 94, top: 305}}><MaskLine at={2} size={91}>Pessoas reais.</MaskLine><MaskLine at={9} size={91} color={C.blue}>Alcance local.</MaskLine></div>
    <div style={{position: 'absolute', inset: 0, opacity: tween(f, [35, 62], [0, 1])}}>
      <svg width={1080} height={1920}><ellipse cx={550} cy={847} rx={450} ry={200} fill="none" stroke="#D8E2F7" strokeWidth={1.4}/><ellipse cx={550} cy={847} rx={470} ry={240} fill="none" stroke="#E6EAF1" strokeWidth={1}/><circle cx={100} cy={847} r={6} fill={C.blue}/><circle cx={1000} cy={847} r={6} fill={C.blue}/></svg>
    </div>
    <Evidence kind="reach" x={x} y={y} width={w} rotate={tween(f, [0, 25, 65], [-7, 0, 0])} yaw={tween(f, [0, 28], [-15, 0])} mark={tween(f, [10, 31], [0, 1])}/>
    <div style={{position: 'absolute', top: 650, left: 58, width: 964}}><Metric value="13.064" at={37} size={248}/></div>
    <div style={{position: 'absolute', top: 972, left: 94, width: 892, textAlign: 'center', fontSize: 51, fontWeight: 700, letterSpacing: -2, opacity: tween(f, [55, 72], [0, 1])}}>pessoas alcançadas</div>
    <Path d={`M${sourceX} ${sourceY}C${sourceX + 160} ${sourceY + 45} 690 1145 690 1057`} progress={tween(f, [53, 83], [0, 1])} width={4}/>
    <div style={{position: 'absolute', left: 78, top: 1089, opacity: tween(f, [58, 75], [0, 1]), fontSize: 19, letterSpacing: 2, fontWeight: 700, color: C.muted}}>REGISTRO ORIGINAL</div>
    <div style={{position: 'absolute', left: 78, top: 1650, opacity: tween(f, [65, 79], [0, 1]), fontSize: 22, color: C.muted}}>Gerenciador de Anúncios</div>
    <div style={{position: 'absolute', left: 715, top: 1275, opacity: tween(f, [65, 85], [0, 1]), translate: `0 ${tween(f, [65, 90], [80, 0])}px`}}><FilmPlane x={0} y={0} width={235} height={305} radius={115}/><PlayToken x={146} y={242} size={80}/></div>
  </Base>;
};

export const Impressions = () => {
  const f = useCurrentFrame();
  const p = tween(f, [0, 35], [0, 1]);
  const x = 92, y = 635 + tween(f, [15, 50], [20, 0]), w = 610;
  const {cx, cy} = cropDimensions('impressions', w);
  return <Base color={C.blue}>
    <Eyebrow light>IMPRESSÕES · DOCUMENTADAS</Eyebrow>
    <div style={{position: 'absolute', left: 94, top: 300}}><MaskLine at={7} size={87}>O anúncio</MaskLine><MaskLine at={16} size={87}>continuou circulando.</MaskLine></div>
    <div style={{position: 'absolute', left: 825, top: 665, width: 185, height: 410, border: '2px solid #FFFFFF35', borderRadius: 95, rotate: '12deg', opacity: tween(f, [10, 31], [0, 1]), translate: `0 ${tween(f, [10, 80], [100, -15])}px`}} />
    <div style={{position: 'absolute', left: 785, top: 710, width: 185, height: 410, border: '2px solid #FFFFFF65', borderRadius: 95, rotate: '5deg', opacity: tween(f, [15, 35], [0, 1]), translate: `0 ${tween(f, [15, 90], [120, 0])}px`}} />
    <FilmPlane x={752} y={770} width={185} height={330} radius={92} rotate={-7} opacity={tween(f, [18, 39], [0, 1])}/>
    <Evidence kind="impressions" x={x} y={y} width={w} rotate={tween(f, [0, 30], [9, -3])} yaw={tween(f, [0, 35], [19, 0])} mark={tween(f, [18, 43], [0, 1])}/>
    <div style={{position: 'absolute', left: 96, top: 1145, fontSize: 19, letterSpacing: 2, color: '#E6EEFF', opacity: tween(f, [38, 57], [0, 1])}}>REGISTRO ORIGINAL · GERENCIADOR DE ANÚNCIOS</div>
    <Path d={`M${x + cx + 130} ${y + cy + 45}C740 1080 960 1080 960 1260H930`} color={C.cyan} width={4} progress={tween(f, [34, 68], [0, 1])}/>
    <div style={{position: 'absolute', left: 60, top: 1230, width: 960}}><Metric value="20.981" at={43} size={238} color="#FFF"/></div>
    <div style={{position: 'absolute', top: 1530, width: 1080, textAlign: 'center', fontSize: 57, fontWeight: 800, letterSpacing: -2, opacity: tween(f, [62, 78], [0, 1])}}>impressões</div>
    <div style={{position: 'absolute', top: 1620, width: 1080, textAlign: 'center', fontSize: 29, color: '#D8E7FF', opacity: tween(f, [70, 87], [0, 1])}}>Exibições do anúncio.</div>
  </Base>;
};
