import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Base, C, CityPlane, FilmPlane, KineticWord, MaskLine, Path, PlayToken, Store, tween} from './system';

export const Opportunity = () => {
  const f = useCurrentFrame();
  const lift = tween(f, [105, 157], [0, -70]);
  const end = tween(f, [148, 185], [0, 1]);
  const focus = tween(f, [98, 155], [0, 1]);
  return <Base color={C.ink}>
    <div style={{position: 'absolute', width: 900, height: 900, borderRadius: '50%', left: 560, top: 1050, background: 'radial-gradient(ellipse,#1552F535,transparent 65%)', scale: tween(f, [0, 185], [.8, 1.18])}} />
    <div style={{position: 'absolute', left: 94 - focus * 13, top: 300 + lift, width: 920, scale: 1 + focus * .07, transformOrigin: '0 0'}}>
      <MaskLine at={8} size={95}>Sua empresa</MaskLine>
      <MaskLine at={20} size={95}>também pode</MaskLine>
      <div style={{position: 'relative', marginTop: 21, marginBottom: 15}}>
        <div style={{position: 'absolute', left: 10, top: 23 + tween(f, [24, 70], [100, 15]), fontSize: 145, fontWeight: 800, lineHeight: 1.1, letterSpacing: -8, color: 'transparent', WebkitTextStroke: '1px #37557D', opacity: tween(f, [30, 65], [0, .75]), scale: .95, transformOrigin: '0 0'}}>alcançar</div>
        <div style={{position: 'absolute', left: 21, top: 55 + tween(f, [30, 76], [120, 10]), fontSize: 145, fontWeight: 800, lineHeight: 1.1, letterSpacing: -8, color: 'transparent', WebkitTextStroke: '1px #1A365C', opacity: tween(f, [34, 70], [0, .7]), scale: .9, transformOrigin: '0 0'}}>alcançar</div>
        <KineticWord text="alcançar" at={34} size={145}/>
      </div>
      <MaskLine at={54} size={103}>mais pessoas.</MaskLine>
    </div>
    <AudienceNodes frame={f} focus={focus} end={end}/>
    <Path d="M340 1320C540 1120 602 1420 785 1340 M735 1320L787 1339L762 1388" color={C.cyan} progress={tween(f, [38, 93], [0, 1])} width={5} opacity={1 - end}/>
    <Path d="M362 1360C500 1500 550 1490 618 1510" color="#436B9B" progress={tween(f, [70, 110], [0, 1])} width={3} opacity={1 - end}/>
    <div style={{position: 'absolute', left: 0, top: lift * .7, opacity: 1 - end * .88}}>
      <FilmPlane x={95} y={1155} width={260} height={450} rotate={-7 + tween(f, [0, 185], [0, 3])} radius={38}/>
      <PlayToken x={272} y={1510} size={97} progress={tween(f, [24, 48], [0, 1])}/>
      <CityPlane x={450} y={1465} width={260} rotate={8} opacity={tween(f, [70, 105], [0, 1])} radius={130}/>
      <div style={{position: 'absolute', left: 99, top: 1660, fontSize: 22, color: '#A8BCD7', letterSpacing: 2, opacity: tween(f, [65, 90], [0, 1])}}>DIVULGAÇÃO</div>
    </div>
    <Store x={735 - 105 * end} y={1220 - 70 * end} size={270 + 100 * end} progress={tween(f, [53, 96], [0, 1])} scale={1 + .14 * end}/>
    <div style={{position: 'absolute', left: 750 - 105 * end, top: 1540 - 30 * end, fontSize: 23, fontWeight: 700, color: '#A8BCD7', letterSpacing: 1.2, opacity: tween(f, [86, 110], [0, 1]) * (1 - end)}}>SUA EMPRESA</div>
    <div style={{position: 'absolute', left: 96, top: 990, fontSize: 29, color: '#A8BCD7', opacity: tween(f, [108, 130], [0, 1])}}>Com divulgação estratégica.</div>
    <div style={{position: 'absolute', left: 565, top: 1125, width: 460, height: 460, border: '2px solid #68D9FF', borderRadius: 125, scale: tween(f, [150, 185], [.7, 1.3]), rotate: `${tween(f, [150, 185], [-25, 0])}deg`, opacity: tween(f, [150, 185], [0, 1])}}/>
  </Base>;
};

const AudienceNodes = ({frame: f, focus, end}) => {
  // One authored distribution motif; these are conceptual people, not platform data.
  const nodes = [{x:475,y:1125,s:82,d:64},{x:605,y:1065,s:64,d:72},{x:650,y:1195,s:95,d:80},{x:485,y:1370,s:68,d:89},{x:605,y:1595,s:85,d:98},{x:890,y:1070,s:62,d:106}];
  return <div style={{position:'absolute',inset:0,opacity:1-end,translate:`0 ${-focus * 95}px`}}>
    <Path d="M348 1305C420 1280 405 1165 520 1165M519 1165C570 1165 554 1098 637 1098M520 1165C565 1210 605 1250 695 1240M364 1360C395 1445 440 1450 520 1405M520 1405C555 1475 560 1600 645 1635" color="#315886" width={2.3} progress={tween(f,[58,116],[0,1])}/>
    {nodes.map((node,index)=>{
      const p=tween(f,[node.d,node.d+25],[0,1]);
      return <div key={index} style={{position:'absolute',left:node.x,top:node.y,width:node.s,height:node.s,borderRadius:node.s*.32,background:index===2?'#1652A0':'#122B4A',border:'1px solid #35567D',opacity:p,translate:`0 ${(1-p)*45 + focus*(index%2?17:-17)}px`,rotate:`${(1-p)*(index%2?14:-14)}deg`,scale:.75+.25*p,boxShadow:'0 12px 25px #00000030'}}><svg viewBox="0 0 100 100" width="100%" height="100%"><circle cx={50} cy={35} r={12} fill="none" stroke={C.cyan} strokeWidth={3}/><path d="M25 75C25 48 75 48 75 75" fill="none" stroke="#D7E7FF" strokeWidth={3} strokeLinecap="round"/></svg></div>;
    })}
  </div>;
};
