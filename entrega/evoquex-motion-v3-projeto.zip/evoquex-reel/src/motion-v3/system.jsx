import React from 'react';
import {AbsoluteFill, Easing, Freeze, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';

export const C = {paper: '#F5F6F8', ink: '#09192D', blue: '#1552F5', cyan: '#68D9FF', muted: '#66748A', line: '#D5DDEB'};
export const ease = Easing.bezier(.22, 1, .36, 1);
export const glide = Easing.bezier(.76, 0, .24, 1);
export const tween = (f, input, output, easing = ease) => interpolate(f, input, output, {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});
export const physical = (f, at = 0, frames = 32) => spring({frame: f - at, fps: 30, durationInFrames: frames, config: {damping: 24, stiffness: 170, mass: 1.05}});
export const Base = ({children, color = C.paper, style = {}}) => <AbsoluteFill style={{background: color, color: color === C.paper ? C.ink : '#FFF', fontFamily: "'Manrope', sans-serif", overflow: 'hidden', ...style}}>{children}</AbsoluteFill>;

export const MaskLine = ({children, at = 0, size = 92, color, style = {}}) => {
  const f = useCurrentFrame();
  const p = physical(f, at);
  return <div style={{overflow: 'hidden', padding: '10px 10px 15px 0', margin: '-10px -10px -15px 0', ...style}}><div style={{fontSize: size, fontWeight: 800, letterSpacing: -size * .058, lineHeight: 1.14, color, translate: `0 ${(1 - p) * 130}%`, rotate: `${(1 - p) * 3}deg`, transformOrigin: '0 100%', filter: `blur(${Math.max(0, (1 - p) * 6)}px)`}}>{children}</div></div>;
};

export const Eyebrow = ({children, x = 96, y = 210, light = false, style = {}}) => <div style={{position: 'absolute', left: x, top: y, fontSize: 23, fontWeight: 700, letterSpacing: 3, color: light ? '#D3E2FF' : C.muted, ...style}}>{children}</div>;

export const KineticWord = ({text, at = 0, size = 145, color = C.cyan}) => {
  const f = useCurrentFrame();
  return <div style={{height: size * 1.22, fontSize: size, fontWeight: 800, letterSpacing: -size * .058, lineHeight: 1.14, color, perspective: 900}}>{[...text].map((char,index)=>{
    const p=physical(f,at+index*1.7,30);
    return <span key={index} style={{display:'inline-block',transformOrigin:'50% 100%',transform:`translate3d(${(1-p)*16}px,${(1-p)*90}px,${(1-p)*-170}px) rotateX(${(1-p)*68}deg) rotateZ(${(1-p)*(index%2?7:-7)}deg)`,opacity:tween(f,[at+index*1.7,at+index*1.7+8],[0,1]),filter:`blur(${Math.max(0,1-p)*5}px)`}}>{char}</span>;
  })}</div>;
};

export const Movie = ({start = 0, still = null}) => {
  const {fps} = useVideoConfig();
  const clip = <Video src={staticFile('assets/DANYS.mp4')} trimBefore={start} durationInFrames={150 - start} premountFor={fps} volume={0} objectFit="cover" style={{width: '100%', height: '100%'}} />;
  return still === null ? <><Sequence from={0} durationInFrames={150 - start} premountFor={fps}>{clip}</Sequence><Sequence from={150 - start} premountFor={fps}><Freeze frame={149 - start}>{clip}</Freeze></Sequence></> : <Freeze frame={still}>{clip}</Freeze>;
};

export const FilmPlane = ({x, y, width, height = width * 1920 / 1080, radius = 32, rotate = 0, yaw = 0, opacity = 1, start = 0, still = null, shadow = true, children}) => <div style={{position: 'absolute', left: x, top: y, width, height, opacity, transform: `perspective(1600px) rotateY(${yaw}deg) rotateZ(${rotate}deg)`, borderRadius: radius, boxShadow: shadow ? '0 35px 85px #09192D26, 0 3px 8px #09192D18' : 'none', overflow: 'hidden', background: C.ink}}><Movie start={start} still={still} />{children}</div>;

export const Path = ({d, progress = 1, color = C.blue, width = 5, opacity = 1, dash, style = {}}) => <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', inset: 0, overflow: 'visible', pointerEvents: 'none', opacity, ...style}}><path d={d} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={dash || 1} strokeDashoffset={dash ? 0 : 1 - progress} /></svg>;

export const Corners = ({x, y, width, height, progress = 1, color = C.blue, radius = 28}) => <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, pointerEvents: 'none'}}><path d={`M${x} ${y + 66}V${y + radius}Q${x} ${y} ${x + radius} ${y}H${x + 66} M${x + width - 66} ${y}H${x + width - radius}Q${x + width} ${y} ${x + width} ${y + radius}V${y + 66} M${x + width} ${y + height - 66}V${y + height - radius}Q${x + width} ${y + height} ${x + width - radius} ${y + height}H${x + width - 66} M${x + 66} ${y + height}H${x + radius}Q${x} ${y + height} ${x} ${y + height - radius}V${y + height - 66}`} fill="none" stroke={color} strokeWidth={5} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress} /></svg>;

export const CityPlane = ({x, y, width, rotate = 0, yaw = 0, progress = 1, opacity = 1, radius = 32, focus = false}) => {
  const f = useCurrentFrame();
  const height = width * 337 / 600;
  return <div style={{position: 'absolute', left: x, top: y, width, height, opacity, transform: `perspective(1600px) rotateY(${yaw}deg) rotateZ(${rotate}deg)`, borderRadius: radius, overflow: 'hidden', background: '#D9E0E5', boxShadow: '0 30px 80px #09192D26'}}>
    <Img src={staticFile('assets/clevelandia.jpg')} style={{width: '100%', height: '100%', scale: focus ? tween(f, [0, 84], [1, 1.055]) : 1, transformOrigin: '55% 61%'}} />
    {focus ? <svg viewBox="0 0 600 337" width={width} height={height} style={{position: 'absolute', inset: 0}}>
      <ellipse cx={330} cy={205} rx={46 + 24 * progress} ry={22 + 12 * progress} fill="none" stroke={C.cyan} strokeWidth={2.1} opacity={progress} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress} />
      <ellipse cx={330} cy={205} rx={85 + 20 * progress} ry={40 + 10 * progress} fill="none" stroke="#FFF" strokeWidth={1} opacity={progress * .65} />
      <path d="M330 205L330 115Q330 100 345 100H460" fill="none" stroke="#FFF" strokeWidth={2} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress} />
      <circle cx={330} cy={205} r={5} fill={C.blue} stroke="#FFF" strokeWidth={2}/>
    </svg> : null}
  </div>;
};

const ROIS = {reach: {x: 420, y: 840, w: 460, h: 430, fx: 657, fy: 1070}, impressions: {x: 30, y: 735, w: 520, h: 405, fx: 279, fy: 974}};
export const cropDimensions = (kind, width) => {
  const r = ROIS[kind], s = width / r.w;
  return {height: r.h * s, cx: (r.fx - r.x) * s, cy: (r.fy - r.y) * s};
};
export const Evidence = ({kind = 'reach', x, y, width, rotate = 0, yaw = 0, opacity = 1, mark = 1}) => {
  const r = ROIS[kind], s = width / r.w;
  const {height, cx, cy} = cropDimensions(kind, width);
  return <div style={{position: 'absolute', left: x, top: y, width, height, opacity, transform: `perspective(1400px) rotateY(${yaw}deg) rotateZ(${rotate}deg)`, borderRadius: 25, border: '7px solid #FFF', background: '#E5E6DF', overflow: 'hidden', boxShadow: '0 25px 65px #09192D2B', transformOrigin: `${cx}px ${cy}px`}}>
    <Img src={staticFile('assets/resultados.jpg')} style={{position: 'absolute', left: -r.x * s, top: -r.y * s, width: 898 * s, height: 1601 * s, maxWidth: 'none'}} />
    <svg width={width} height={height} style={{position: 'absolute', inset: 0}}><path d={`M${cx - 98} ${cy + 30}Q${cx + 10} ${cy + 75} ${cx + 115} ${cy + 63}`} fill="none" stroke={C.blue} strokeWidth={5} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - mark}/><circle cx={cx + 130} cy={cy + 45} r={7} fill={C.blue} opacity={mark}/></svg>
  </div>;
};

export const Metric = ({value, at = 0, size = 245, color = C.ink, style = {}}) => {
  const f = useCurrentFrame();
  return <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size, lineHeight: 1.18, fontWeight: 800, color, letterSpacing: -size * .07, fontVariantNumeric: 'tabular-nums', ...style}}>{[...value].map((char, i) => <div key={i} style={{overflow: 'hidden', height: size * 1.2, width: size * (char === '.' ? .22 : .61)}}><div style={{translate: `0 ${(1 - physical(f, at + i * 2, 31)) * size * 1.4}px`, filter: `blur(${Math.max(0, 1 - physical(f, at + i * 2, 31)) * 5}px)`}}>{char}</div></div>)}</div>;
};

export const PlayToken = ({x, y, size = 100, color = C.blue, progress = 1, rotate = 0}) => <div style={{position: 'absolute', left: x, top: y, width: size, height: size, borderRadius: size * .32, background: color, boxShadow: '0 14px 40px #09192D26', rotate: `${rotate}deg`, scale: progress}}><svg width="100%" height="100%" viewBox="0 0 100 100"><path d="M41 30Q38 28 38 34V68Q38 72 42 70L70 53Q75 50 70 47Z" fill="#FFF"/></svg></div>;

export const Store = ({x, y, size = 260, progress = 1, scale = 1}) => <svg viewBox="0 0 300 300" width={size} height={size} style={{position: 'absolute', left: x, top: y, overflow: 'visible', scale}}>
  <rect x={35} y={42} width={230} height={215} rx={36} fill="#143B66"/>
  <path d="M68 122V224H232V122 M59 122H241L220 75H80Z M120 224V161H179V224 M97 77L87 121 M132 77L128 121 M168 77L172 121 M203 77L213 121" fill="none" stroke="#FFF" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress}/>
  <path d="M60 123Q79 142 98 123Q116 142 135 123Q151 142 170 123Q189 142 207 123Q224 142 241 123" fill="none" stroke={C.cyan} strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress}/>
</svg>;
