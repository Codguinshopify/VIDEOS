import React from 'react';
import {interpolateColors, useCurrentFrame} from 'remotion';
import {Base, C, CityPlane, Corners, FilmPlane, MaskLine, Path, PlayToken, tween} from './system';

export const Recognition = () => {
  const f = useCurrentFrame();
  const p = tween(f, [76, 113], [0, 1]);
  const x = 96 * p, y = 650 * p, w = 1080 - 590 * p, h = 1920 - 1049 * p;
  const color = interpolateColors(p, [0, 1], ['#FFFFFF', C.ink]);
  return <Base>
    <div style={{position: 'absolute', width: 660, height: 660, left: 530, top: 910, borderRadius: '50%', background: '#E0E9FF', scale: tween(f, [80, 112], [.5, 1]), opacity: p}} />
    <CityPlane x={420} y={950} width={750} rotate={9} opacity={p} />
    <FilmPlane x={x} y={y} width={w} height={h} radius={36 * p} rotate={-7 * p} yaw={-10 * p} shadow={p > .02}>
      <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(3,14,27,.72),rgba(3,14,27,0) 49%)', opacity: 1 - p}} />
      <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{position: 'absolute', inset: 0}}><path d="M45 200V85Q45 45 85 45H200 M880 45H995Q1035 45 1035 85V200 M1035 1720V1835Q1035 1875 995 1875H880 M200 1875H85Q45 1875 45 1835V1720" fill="none" stroke="#FFFFFFAA" strokeWidth={7} pathLength={1} strokeDasharray={1} strokeDashoffset={1-tween(f,[48,76],[0,1])}/></svg>
    </FilmPlane>
    <div style={{position: 'absolute', left: 94, top: 205 - 20 * p, color, width: 910}}>
      <MaskLine size={90} at={7}>Você chegou</MaskLine>
      <MaskLine size={90} at={17}>a ver esse vídeo</MaskLine>
      <MaskLine size={82} at={42} color={p > .5 ? C.blue : '#FFFFFF'}>em Clevelândia?</MaskLine>
    </div>
    <PlayToken x={490} y={1400} size={106} progress={tween(f, [91, 113], [0, 1])} rotate={-7} />
    <Path d="M540 1450C760 1510 1000 1430 950 1200" progress={tween(f, [102, 124], [0, 1])} width={5} />
    <div style={{position: 'absolute', left: 96, top: 1620, fontSize: 25, color: C.muted, opacity: p, letterSpacing: .5}}>Dany’s Presentes · anúncio original</div>
  </Base>;
};
