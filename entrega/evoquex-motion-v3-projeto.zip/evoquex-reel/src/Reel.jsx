import React from 'react';
import {AbsoluteFill, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import assets from './assets.json';
import {C, clamp} from './design';
import {OpeningScene} from './scenes/Opening';
import {RevelationScene} from './scenes/Revelation';
import {ProofScene} from './scenes/Proof';
import {ConnectionScene} from './scenes/Connection';
import {ClosingScene} from './scenes/Closing';

export const EvoquexReel = () => {
  const {fps} = useVideoConfig();
  const f = useCurrentFrame();
  return <AbsoluteFill style={{background: C.navy}}>
    <OpeningScene name="Reconhecimento — anúncio original" from={0} durationInFrames={132} premountFor={fps} />
    <RevelationScene name="Revelação — alcance local" from={4 * fps} durationInFrames={162} premountFor={fps} />
    <ProofScene name="Prova — print e métricas" from={9 * fps} durationInFrames={252} premountFor={fps} />
    <ConnectionScene name="Conexão — comércio de Clevelândia" from={17 * fps} durationInFrames={192} premountFor={fps} />
    <ClosingScene name="Convite — fale com a Evoquex" from={23 * fps} durationInFrames={150} premountFor={fps} />
    {assets.sound ? <Audio name="Trilha e sound design originais" src={staticFile('assets/evoquex-original.wav')} volume={interpolate(f, [0, 105, 150], [.2, .2, 1], clamp)} premountFor={fps} /> : null}
    <div style={{position: 'absolute', left: 0, bottom: 0, height: 4, background: C.cyan, width: `${interpolate(f, [0, 839], [0, 100], clamp)}%`}} />
  </AbsoluteFill>;
};
