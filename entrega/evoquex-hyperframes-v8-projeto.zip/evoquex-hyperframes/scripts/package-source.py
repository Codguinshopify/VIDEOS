"""Self-contained HyperFrames source and assets; no node_modules or render cache."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
ROOT=Path(__file__).resolve().parent.parent
output=ROOT/'renders/evoquex-hyperframes-v8-projeto.zip'
files=set()
for name in ['index.html','style.css','motion.js','package.json','package-lock.json','hyperframes.json','meta.json','DESIGN.md','README.md','AGENTS.md','.gitignore']:
 files.add(ROOT/name)
for folder in ['assets','vendor','scripts','resources']:
 files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for pattern in ['output-validation.json','hf-v8-sampling.json','final-check.json','final-review.md','source-reproduction.json','comparacao-remotion-hyperframes.jpg','hf-v8-*.jpg','hf-v8-phone-*.png']:
 files.update((ROOT/'review').glob(pattern))
if (ROOT/'review/animation-map/animation-map.json').exists():files.add(ROOT/'review/animation-map/animation-map.json')
with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):
  assert not p.name.startswith('.env')
  z.write(p,'evoquex-hyperframes/'+p.relative_to(ROOT).as_posix())
with ZipFile(output) as z:
 assert z.testzip() is None
 for name in ['index.html','style.css','motion.js','vendor/gsap.min.js','assets/poster-hook-end.jpg','assets/campanha.mp4','assets/mix-v7.wav','assets/ink-masks/17.png','package-lock.json']:
  assert z.read('evoquex-hyperframes/'+name)==(ROOT/name).read_bytes()
 assert not any('/node_modules/' in n or '/.env' in n for n in z.namelist())
report={'file':output.name,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'crc_verified':True,'file_count':len(files),'actual_assets_retained':True,'node_modules_and_secrets_excluded':True}
(ROOT/'review/package-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
