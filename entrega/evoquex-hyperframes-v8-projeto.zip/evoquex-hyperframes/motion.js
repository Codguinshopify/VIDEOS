/* Native HyperFrames + GSAP 3.14.2. Timeline owns every state; no React,
 * Remotion render, playback calls, clocks, CDN or asynchronous construction.
 * Native registry patterns: kinetic-type-swap, count-up, depth-stack.
 */
window.__timelines=window.__timelines||{};
const tl=window.__timelines['evoquex-hf-v8'];
const stages=[['#hook',0],['#action',4.5],['#local',10.5],['#proof',15.5],['#strategy',22.5],['#contact',28.5]];

// Every scene remains intact until the following reveal covers it.
function reveal(selector,at,kind){
 tl.set(selector,{opacity:1},at);
 if(kind==='circle')tl.fromTo(selector,{clipPath:'circle(0% at 72% 44%)'},{clipPath:'circle(150% at 72% 44%)',duration:.44,ease:'power3.inOut',immediateRender:false},at);
 else if(kind==='diagonal')tl.fromTo(selector,{clipPath:'polygon(0 0,0 0,0 100%,0 100%)'},{clipPath:'polygon(0 0,100% 0,100% 100%,0 100%)',duration:.36,ease:'power4.inOut',immediateRender:false},at);
 else if(kind==='ink'){
  tl.set(selector,{maskImage:'url("assets/ink-masks/00.png")',maskSize:'100% 100%',maskRepeat:'no-repeat'},at);
  for(let i=0;i<18;i++)tl.set(selector,{maskImage:`url("assets/ink-masks/${String(i).padStart(2,'0')}.png")`},at+i/30*.77);
  tl.set(selector,{maskImage:'none'},at+.45);
 }else tl.fromTo(selector,{clipPath:'inset(50% 0 50% 0)'},{clipPath:'inset(0% 0 0% 0)',duration:.4,ease:'expo.inOut',immediateRender:false},at);
}
reveal('#action',4.5,'slit');reveal('#local',10.5,'ink');reveal('#proof',15.5,'diagonal');reveal('#strategy',22.5,'slit');reveal('#contact',28.5,'circle');
// Cleanup only after the incoming scene completely covers the outgoing one.
// This is seekable and also keeps browser/layout audits scoped to visible art.
tl.set('#hook',{opacity:0},4.94);
tl.set('#action',{opacity:0},10.97);
tl.set('#local',{opacity:0},15.9);
tl.set('#proof',{opacity:0},22.94);
tl.set('#strategy',{opacity:0},28.97);

// Hook: visible artwork is already moving at frame zero.
tl.from('#hook .eyebrow',{x:42,duration:.45,ease:'power2.out'},0);
tl.from('.hook-heading',{x:-48,rotation:-2,duration:.6,ease:'expo.out'},0);
tl.from('.swap-slot',{y:35,duration:.5,ease:'power3.out'},0);
tl.from('.hook-brush',{scaleX:.12,duration:.52,ease:'power4.out'},0);
tl.from('.hook-center',{y:70,rotationY:-18,rotationX:9,z:-90,scale:.88,duration:.85,ease:'power3.out'},0);
tl.from('.hook-left',{x:-170,rotation:-24,duration:.8,ease:'power2.out'},0);
tl.from('.hook-right',{x:170,rotation:24,duration:.9,ease:'power4.out'},0);
tl.from('.hook-question',{y:65,opacity:0,duration:.42,ease:'power3.out'},.2);
tl.from('.caption-strip',{x:-110,opacity:0,rotation:-8,duration:.4,ease:'back.out(1.1)'},.45);
tl.from('#hook-ring',{scale:.7,opacity:.4,duration:.9,ease:'sine.out'},0);
tl.to('#hook-ring',{rotation:100,scale:1.05,duration:4.5,ease:'none'},0);
tl.set('#swap-service',{yPercent:110},0);
tl.to('#swap-company',{yPercent:-110,opacity:0,duration:.37,ease:'power3.inOut'},1.6);
tl.fromTo('#swap-service',{yPercent:110},{yPercent:0,duration:.37,ease:'power3.inOut',immediateRender:false},1.6);
tl.to('.hook-center',{rotationY:4,rotation:-1,z:30,duration:2.9,ease:'sine.inOut'},1.3);
tl.from('#hook .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},.55);

// Production and distribution. The broad photo plane resolves into a diagram.
tl.from('#action .eyebrow',{x:40,opacity:0,duration:.4,ease:'power2.out'},4.64);
tl.from('.action-heading',{y:80,opacity:0,duration:.55,ease:'expo.out'},4.66);
tl.from('.action-heading strong',{x:-65,opacity:0,duration:.45,ease:'power3.out'},4.82);
tl.from('.action-subtitle',{y:35,opacity:0,duration:.45,ease:'power2.out'},4.94);
tl.from('.action-video',{x:100,scale:1.18,rotationY:-15,opacity:0,duration:.65,ease:'power4.out'},4.65);
tl.to('.action-video',{rotationY:5,rotation:-1.5,duration:3.9,ease:'sine.inOut'},5.85);
tl.from('.action-steps .step',{x:170,opacity:0,stagger:.3,duration:.5,ease:'power3.out'},5.9);
tl.from('.network-tags span',{y:50,rotation:5,opacity:0,stagger:.14,duration:.4,ease:'back.out(1.05)'},6.65);
tl.from('.action-note',{y:35,opacity:0,duration:.4,ease:'power2.out'},6.9);
tl.from('.action-line',{scaleX:0,duration:.65,ease:'power4.inOut'},6.6);
tl.from('#action .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},5.05);

// Local targeting: camera movement preserves the real city photograph.
tl.from('#local .eyebrow',{x:40,opacity:0,duration:.38,ease:'power2.out'},10.68);
tl.from('.local-heading',{y:70,opacity:0,duration:.5,ease:'expo.out'},10.68);
tl.from('.local-heading strong',{x:100,opacity:0,duration:.52,ease:'power3.out'},10.83);
tl.from('.city-photo',{rotationY:-17,rotationX:10,y:110,scale:.86,opacity:0,duration:.75,ease:'power4.out'},10.7);
tl.to('.city-photo',{rotationY:6,rotation:2,duration:3.65,ease:'sine.inOut'},11.48);
tl.to('.city-photo>.photo',{scale:1.17,x:-14,y:7,duration:4.3,ease:'sine.inOut'},10.9);
tl.from('.city-orbit',{scale:.3,opacity:0,stagger:.12,duration:.65,ease:'power3.out'},11.2);
tl.to('.city-orbit',{rotation:22,scale:1.08,duration:3.3,ease:'sine.inOut'},11.9);
tl.from('.city-callout',{x:95,opacity:0,duration:.5,ease:'back.out(1.05)'},11.94);
tl.from('.route>*',{x:-30,opacity:0,stagger:.09,duration:.4,ease:'power3.out'},11.95);
tl.from('.local-note',{y:25,opacity:0,duration:.4,ease:'power2.out'},12.4);
tl.from('#local .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},11.05);

// Registry count-up contract: fixed rows at 30 fps make repeated/backward seeks
// land on the exact same integer; no onUpdate counters with accumulated state.
function count(selector,value,at,duration){
 for(let f=0;f<=Math.round(duration*30);f++){
  const p=f/(duration*30),e=(1-Math.cos(Math.PI*Math.min(1,p)))/2;
  tl.set(selector,{textContent:Math.round(value*e).toLocaleString('pt-BR')},at+f/30);
 }
 tl.to(selector,{scale:1.035,duration:.14,ease:'power3.out'},at+duration);
 tl.to(selector,{scale:1,duration:.18,ease:'power2.out'},at+duration+.14);
}
tl.from('#proof .eyebrow',{x:40,opacity:0,duration:.4,ease:'power2.out'},15.65);
tl.set('#reach, #impressions',{textContent:'0'},15.5);
tl.from('.proof-heading',{y:75,opacity:0,duration:.5,ease:'expo.out'},15.67);
tl.from('.proof-document',{y:100,scale:.9,rotationY:-16,opacity:0,duration:.6,ease:'power3.out'},15.64);
tl.to('.proof-document',{x:440,y:-100,scale:.83,rotation:13,opacity:.19,duration:.8,ease:'power4.inOut'},16.05);
tl.from('#reach-row',{x:-1060,opacity:0,duration:.5,ease:'power4.out'},16.1);
tl.from('#impressions-row',{x:1060,opacity:0,duration:.5,ease:'power3.out'},17.7);
count('#reach',13064,16.4,1);count('#impressions',20981,18,1);
tl.from('.proof-source',{y:30,opacity:0,duration:.45,ease:'power2.out'},19.18);
tl.from('#proof .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},16.05);

// The strategic questions are a connected composition rather than extra claims.
tl.from('#strategy .eyebrow',{x:35,opacity:0,duration:.4,ease:'power2.out'},22.65);
tl.from('.strategy-heading',{y:75,opacity:0,duration:.5,ease:'expo.out'},22.67);
tl.from('#question-one',{x:-90,rotationY:-18,rotationX:7,scale:.91,opacity:0,duration:.65,ease:'power4.out'},23.05);
tl.to('#question-one',{rotation:1,rotationY:2,duration:1.3,ease:'sine.inOut'},24.1);
tl.from('#question-two',{x:150,rotationY:20,rotationX:-8,scale:.9,opacity:0,duration:.65,ease:'power3.out'},24.7);
tl.from('.connector path',{strokeDashoffset:1,duration:.6,ease:'power2.inOut'},24.1);
tl.from('.strategy-note',{y:35,opacity:0,duration:.45,ease:'power2.out'},26);
tl.from('#strategy .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},23);

// Human invitation, same CTA and no fake messenger UI.
tl.from('#contact .eyebrow',{x:35,opacity:0,duration:.4,ease:'power2.out'},28.67);
tl.from('.contact-heading',{y:65,opacity:0,duration:.5,ease:'expo.out'},28.68);
tl.from('.contact-photo',{x:150,rotationY:20,opacity:0,duration:.7,ease:'power3.out'},28.8);
tl.from('.contact-city',{x:-150,rotationY:-20,opacity:0,duration:.65,ease:'power4.out'},28.95);
tl.from('.speech',{y:190,scale:.84,rotation:-5,opacity:0,duration:.65,ease:'back.out(1.1)'},29.28);
tl.from('.speech-text',{y:65,opacity:0,duration:.5,ease:'power3.out'},29.5);
tl.from('.contact-brand',{x:-45,opacity:0,duration:.45,ease:'power2.out'},30.3);
tl.from('.contact-brush',{scaleX:0,duration:.65,ease:'power4.inOut'},30.25);
tl.from('.contact-note',{y:25,opacity:0,duration:.4,ease:'power3.out'},30.55);
tl.to('.contact-photo',{rotation:7,y:-10,duration:3.7,ease:'sine.inOut'},30.1);
tl.to('.contact-city',{rotation:-7,y:12,duration:3.5,ease:'sine.inOut'},30.2);
tl.from('#contact .footer',{y:20,opacity:0,duration:.4,ease:'power2.out'},29);

window.__timelines['evoquex-hf-v8']=tl;
window.EVOQUEX_AUDIT={engine:'HyperFrames 0.8.162',duration:34.5,chapters:stages,metrics:{reach:13064,impressions:20981},business:'Danny’s Presentes',voice:false,originalAudioGain:0};
tl.seek(0);
