# Evoquex — HyperFrames V8

Edição nativa em **HyperFrames 0.8.162 + GSAP 3.14.2**, HTML/CSS/JavaScript.
1080 × 1920, 30 fps, 34,5 s. O motor Remotion não é usado para renderizar esta
composição e o MP4 da V7 não é usado como filmagem.

## Comparação com a V7

Mesma história, mesmas seis partes e pontos de corte (0, 4,5, 10,5, 15,5, 22,5 e
28,5 s), mesmos materiais e **o mesmo WAV de música/efeitos**, preservado por
SHA-256. A comparação isola principalmente a composição e a animação.

A edição tem entradas GSAP, palavras em um slot mascarado, câmera em perspectiva,
camadas de vídeo e fotografia, recortes orgânicos de tinta, revelação por círculo,
documento que recua para dar lugar aos contadores e convite com composição clara.
A V7 e seu projeto Remotion permanecem preservados. A filmagem do hook permanece
ativa até 4,94 s, cobrindo o overlap da primeira transição; encerrar o clipe em
4,5 s fazia o runtime exibir seu poster antes de a cena ser coberta. O hook usa
uma cópia com URL própria, com bytes idênticos ao original, para separar os dois
players de vídeo.

As métricas têm composição diferente: tipografia em azul/ciano, com o registro
real recuado em profundidade. O encerramento usa fundo claro e balão azul.
Não se afirma que trocar o motor, por si só, torne uma edição melhor.

## Informações reais

**Danny’s Presentes**, com dois N e apóstrofo. Vídeo produzido pela Evoquex,
anúncios no Instagram/Facebook direcionados somente para Clevelândia, conforme
confirmação do usuário. **13.064 pessoas alcançadas e 20.981 impressões**.
Sem alegação de vendas, retorno financeiro, visualizações ou público não seguidor.

A voz natural continua pendente. Esta versão usa música e efeitos, com o áudio
original do anúncio silenciado. Não houve geração de voz, compra, assinatura ou
reutilização da voz rejeitada. A interface não permite avaliação auditiva
subjetiva; os relatórios registram somente o que foi verificado.

## Recursos e licenças

assets/campanha.mp4, clevelandia.jpg e resultados.jpg são cópias dos originais,
verificadas por hash. Os posters foram extraídos desses próprios quadros.
assets/brush.png e ink-masks/ vêm dos recursos recuperados da primeira parte do
pack e preparados na V7; nenhum AEP foi executado. A licença comercial do pack
fornecido não foi verificada independentemente. O catálogo e sua licença
Apache-2.0 estão em resources/catalog. Padrões de word swap, count-up e perspectiva
foram adaptados para GSAP nativo. GSAP e seus avisos acompanham vendor/.
A origem/licença instrumental do mix autoral estão em resources/audio-sources.

## Executar

Node >= 22, FFmpeg/ffprobe e Chrome/Chromium são necessários. Dependências e
integridades fixadas no package-lock.json. Os assets e GSAP são locais; a
composição não precisa de CDN, conta HeyGen ou API de voz para renderizar.

```sh
npm ci --no-audit --no-fund
npm run dev
npm run check
npm run snapshots
npm run render
```

scripts/hf.mjs aponta para o Chromium do ambiente quando disponível e mantém
XDG_CACHE_HOME/XDG_STATE_HOME em diretórios graváveis. Em outra máquina, a CLI
pode localizar/instalar seu navegador suportado, ou usar HYPERFRAMES_BROWSER_PATH.
O preview precisa ser reiniciado após a restauração do ambiente; use
`node scripts/hf.mjs preview --status` e `preview --stop` para gerenciá-lo.
Não crie Git worktrees para setup; utilize o checkout existente.

O check nativo passou: estrutura, execução, layout e contraste. O movimento foi
revisado com o mapa de animações e quadros reais; a seção automática de motion
assertions ficou desativada por não haver um arquivo de especificações.
Dois avisos estáticos indicam reutilização intencional das mesmas fotografias em
cenas distintas; não há descoberta duplicada de vídeos ou sobreposição de áudio.
O recorte interno ampliado da foto da cidade é intencional.

## Revisão e artefatos

O arquivo principal é renders/evoquex-hyperframes-v8.mp4. O vídeo comparativo,
quando fornecido, é um hstack FFmpeg das duas exportações com uma única trilha;
não é o render principal HyperFrames.

review/final-check.json contém a checagem nativa. review/animation-map contém o mapa
de tweens, com o helper oficial adaptado para o pacote npm consolidado, seleção
única dos alvos e tempo local do root. As pausas nas métricas e nas perguntas são
deliberadas para leitura; colisões de camadas decorativas são intencionais.
review/output-validation.json registra imagem, áudio, duração e integridade.
review/hf-v8-*.jpg e telas phone mostram a revisão do MP4 real.

Python/Pillow/NumPy são usados apenas para inspeção e comparação, não para o
motor de animação. `python scripts/validate-output.py` verifica a exportação;
`python scripts/review-output.py` produz as folhas de inspeção. A comparação
visual automática é opcional e usa a V7 quando ela está no diretório vizinho.

Limites dos materiais: 5,06 s de filmagem, com alguns trechos desfocados, e foto
aérea de 600 × 337 px. A locução e a escuta/aprovação criativa do usuário continuam
pendentes. Esta entrega é uma prévia para comparar as edições.
