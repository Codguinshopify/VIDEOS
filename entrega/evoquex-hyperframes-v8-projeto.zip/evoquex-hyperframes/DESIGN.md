# Evoquex — HyperFrames comparison / V8

## Style Prompt
Native HTML/GSAP advertising motion for the same Danny’s Presentes case as V7.
Preserve its truthful narrative, 34.5-second duration, original media and soundtrack.
Recompose the editorial layouts and choreography with seekable masks, perspective,
kinetic type and layered photography. A Brazilian local entrepreneur should see
what Evoquex produced, where the ads ran, what the documented metrics mean and
the two questions that guide a similar project. No narration is fabricated.

## Colors
- #11132B — dark ink, high contrast text and opening/strategy canvas.
- #2449FF — Evoquex blue, local distribution and results canvas.
- #F7F6F1 — paper, action and closing canvas.
- #8BF0E9 — cyan, emphasis, brush texture, connecting shapes.
- #FFFFFF — white text and photographic borders.

## Typography
Local Manrope variable font, 300–800. Strong headlines, tight tracking, tabular
numerals. Use 90–140 px headings, 210–230 px values, 32–44 px explanation,
24 px metadata. No external fonts or network assets during capture.

## Motion
One paused registered GSAP timeline, seconds aligned to V7's six chapter starts:
0, 4.5, 10.5, 15.5, 22.5, 28.5. Scene transitions 0.33–0.47 s; content stays
present until covered. Immediate visible moving layers from frame zero override
the generic initial animation delay. Several eases, controlled stagger, short
blur during travel, deliberate holds for reading. No free-running CSS animation.

## What NOT to Do
- No invented sales, ROI, views, non-follower reach or growth chart.
- No fabricated testimonial, chat interface or platform results dashboard.
- Do not modify the old Remotion composition or reuse its rendered MP4 as footage.
- Do not add a synthetic voice as a fallback or copy audio from reference videos.
- No excessive flashing, unreadable metric labels or decorative icons without purpose.
