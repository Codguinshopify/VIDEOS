# HyperFrames V8 — revisão final

Entrega: prévia nativa HyperFrames 0.8.162 e GSAP 3.14.2, HTML/CSS/JS. O MP4 da V7
não foi utilizado como filmagem. A V7 permanece preservada. A mesma narrativa,
duração, materiais originais e WAV de música/efeitos foram mantidos para comparação.

Coreografia: entradas rápidas, slot tipográfico, planos fotográficos em perspectiva,
clip amplo que se recompõe em produção/divulgação, cidade com movimento de câmera,
registro original recuando para os contadores, perguntas conectadas e convite claro.
As mudanças mais visíveis de composição estão nos resultados azuis e no CTA claro.
As camadas continuam presentes até o próximo recorte cobri-las.

Correções reais após inspeção: removida transformação CSS cumulativa da palavra
substituta; ajustadas altura/espaçamento das métricas; números começam em zero antes
de contarem; cenas anteriores desligadas somente após a cobertura; clareado o rodapé
sobre azul. O hook tinha um retorno indevido ao poster quando sua filmagem terminava
antes do wipe. A mídia agora dura 4,94 s, cobrindo a transição de 4,5 s, e usa URL
independente com os mesmos bytes. Teste isolado de 5 s e quadro 135 do MP4 completo
confirmaram a continuidade. Nenhum áudio original compete com o mix.

O check nativo passou: zero erros de lint, runtime, layout e contraste; zero alertas
de contraste. Dois avisos de fotos repetidas são reutilização intencional em cenas
diferentes. O recorte ampliado da foto é intencional. A seção automática de motion
assertions ficou desativada; não se alega sua execução. O movimento foi revisado pelo
mapa de 72 tweens de duração relevante e pelos quadros reais. Os flags de offscreen
correspondem aos planos laterais e à entrada das impressões; colisões de decorativos
são intencionais, pulsos são curtos e drifts de câmera são longos. As pausas perto dos
resultados e das perguntas mantêm tempo para leitura.

Revisão do MP4: amostragem de toda a duração, 31 quadros iniciais, 35 amostras das
cinco passagens, 31 estados internos e seis telas pequenas. Relatório de amostragem
associa os arquivos ao SHA-256 da exportação para impedir revisão de quadros antigos.
Decodificação integral de vídeo/áudio passou. Grafia Danny’s Presentes revisada;
13.064 pessoas alcançadas e 20.981 impressões mantidos. Nenhuma alegação comercial
ou métrica adicional foi inventada.

Arquivo: 34.500000 s, 1035 frames, 1080 × 1920, 30 fps,
H.264/yuv420p/BT.709, AAC estéreo a 48 kHz. LUFS: -16.61; pico
verdadeiro: -1.65 dBTP; zero clipping. Correlação com o WAV V7:
0.999266. SHA-256: 5e7b0286f51fdccd0d0eb4f0c994529afc5f9a938d468a57ec565cef70bf5574.

Projeto extraído em pasta independente, npm ci offline próprio com o mesmo lockfile
e quatro snapshots reais do HyperFrames. Não houve symlink de node_modules ou
necessidade do projeto Remotion para esses quadros. Fontes, scripts e assets foram
conferidos por hash. O ZIP final contém os mesmos fontes testados mais os relatórios.

Limites: sem nova locução e sem escuta subjetiva nesta interface. Não se confunde
medição sonora com aprovação auditiva humana. A filmagem tem 5,06 s e a foto aérea
600 × 337 pixels; trechos originais desfocados não foram inventados ou substituídos.
Nenhum AEP foi executado, nem houve compra ou geração de voz. A preferência de voz
feminina natural permanece pendente para uma etapa futura.
